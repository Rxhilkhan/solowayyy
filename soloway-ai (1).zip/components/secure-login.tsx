"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Eye, EyeOff, Shield, Lock, AlertTriangle, CheckCircle, Smartphone, ArrowRight } from "lucide-react"
import { enhancedAuthService } from "@/lib/auth-enhanced"
import { validatePassword } from "@/lib/security"
import Link from "next/link"

interface PasswordStrength {
  score: number
  feedback: string[]
  color: string
}

export function SecureLogin() {
  const [isLogin, setIsLogin] = useState(true)
  const [formData, setFormData] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    name: "",
    mfaToken: "",
  })
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [requiresMFA, setRequiresMFA] = useState(false)
  const [passwordStrength, setPasswordStrength] = useState<PasswordStrength>({
    score: 0,
    feedback: [],
    color: "red",
  })

  const calculatePasswordStrength = (password: string): PasswordStrength => {
    const validation = validatePassword(password)
    let score = 0
    const feedback: string[] = []

    if (password.length >= 8) score += 20
    else feedback.push("At least 8 characters")

    if (/[A-Z]/.test(password)) score += 20
    else feedback.push("One uppercase letter")

    if (/[a-z]/.test(password)) score += 20
    else feedback.push("One lowercase letter")

    if (/\d/.test(password)) score += 20
    else feedback.push("One number")

    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score += 20
    else feedback.push("One special character")

    let color = "red"
    if (score >= 80) color = "green"
    else if (score >= 60) color = "yellow"
    else if (score >= 40) color = "orange"

    return { score, feedback, color }
  }

  const handlePasswordChange = (password: string) => {
    setFormData({ ...formData, password })
    if (!isLogin) {
      setPasswordStrength(calculatePasswordStrength(password))
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    setSuccess("")

    try {
      if (isLogin) {
        const result = await enhancedAuthService.signIn(
          formData.email,
          formData.password,
          formData.mfaToken || undefined,
          "127.0.0.1", // In real app, get actual IP
          navigator.userAgent,
        )

        if (result.success) {
          setSuccess("Login successful!")
          // Redirect to dashboard
          window.location.href = "/dashboard"
        } else if (result.requiresMFA) {
          setRequiresMFA(true)
          setError("Please enter your MFA code")
        } else {
          setError(result.error || "Login failed")
        }
      } else {
        // Signup validation
        if (formData.password !== formData.confirmPassword) {
          setError("Passwords do not match")
          return
        }

        const passwordValidation = validatePassword(formData.password)
        if (!passwordValidation.isValid) {
          setError(passwordValidation.errors.join(", "))
          return
        }

        const result = await enhancedAuthService.signUp(formData.email, formData.password, formData.name)

        if (result.success) {
          setSuccess("Account created successfully! Please check your email to verify your account.")
        } else {
          setError(result.error || "Signup failed")
        }
      }
    } catch (error: any) {
      setError("An unexpected error occurred")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md shadow-xl">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Shield className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold">{isLogin ? "Secure Login" : "Create Account"}</CardTitle>
          <CardDescription>
            {isLogin ? "Sign in to your SoloWay AI account" : "Join SoloWay AI and start building"}
          </CardDescription>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <div>
                <Label htmlFor="name">Full Name</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required={!isLogin}
                  className="mt-1"
                />
              </div>
            )}

            <div>
              <Label htmlFor="email">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
                className="mt-1"
              />
            </div>

            <div>
              <Label htmlFor="password">Password</Label>
              <div className="relative mt-1">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={formData.password}
                  onChange={(e) => handlePasswordChange(e.target.value)}
                  required
                  className="pr-10"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>

              {!isLogin && formData.password && (
                <div className="mt-2 space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span>Password Strength</span>
                    <Badge
                      variant={passwordStrength.score >= 80 ? "default" : "secondary"}
                      className={passwordStrength.score >= 80 ? "bg-green-500" : ""}
                    >
                      {passwordStrength.score >= 80
                        ? "Strong"
                        : passwordStrength.score >= 60
                          ? "Good"
                          : passwordStrength.score >= 40
                            ? "Fair"
                            : "Weak"}
                    </Badge>
                  </div>
                  <Progress value={passwordStrength.score} className="h-2" />
                  {passwordStrength.feedback.length > 0 && (
                    <div className="text-xs text-gray-600">Missing: {passwordStrength.feedback.join(", ")}</div>
                  )}
                </div>
              )}
            </div>

            {!isLogin && (
              <div>
                <Label htmlFor="confirmPassword">Confirm Password</Label>
                <div className="relative mt-1">
                  <Input
                    id="confirmPassword"
                    type={showConfirmPassword ? "text" : "password"}
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    required={!isLogin}
                    className="pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="absolute right-0 top-0 h-full px-3"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
                {formData.confirmPassword && formData.password !== formData.confirmPassword && (
                  <p className="text-sm text-red-600 mt-1">Passwords do not match</p>
                )}
              </div>
            )}

            {requiresMFA && (
              <div>
                <Label htmlFor="mfaToken" className="flex items-center gap-2">
                  <Smartphone className="w-4 h-4" />
                  MFA Code
                </Label>
                <Input
                  id="mfaToken"
                  type="text"
                  value={formData.mfaToken}
                  onChange={(e) => setFormData({ ...formData, mfaToken: e.target.value })}
                  placeholder="Enter 6-digit code"
                  maxLength={6}
                  className="mt-1 text-center text-lg tracking-widest"
                />
                <p className="text-xs text-gray-600 mt-1">Enter the 6-digit code from your authenticator app</p>
              </div>
            )}

            {error && (
              <Alert variant="destructive">
                <AlertTriangle className="w-4 h-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {success && (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <AlertDescription className="text-green-800">{success}</AlertDescription>
              </Alert>
            )}

            <Button
              type="submit"
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              disabled={loading}
            >
              {loading ? (
                "Processing..."
              ) : (
                <>
                  {isLogin ? "Sign In" : "Create Account"}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>

            <div className="text-center">
              <Button
                type="button"
                variant="link"
                onClick={() => {
                  setIsLogin(!isLogin)
                  setError("")
                  setSuccess("")
                  setRequiresMFA(false)
                  setFormData({
                    email: "",
                    password: "",
                    confirmPassword: "",
                    name: "",
                    mfaToken: "",
                  })
                }}
              >
                {isLogin ? "Don't have an account? Sign up" : "Already have an account? Sign in"}
              </Button>
            </div>

            {isLogin && (
              <div className="text-center">
                <Link href="/auth/forgot-password" className="text-sm text-purple-600 hover:underline">
                  Forgot your password?
                </Link>
              </div>
            )}
          </form>

          {/* Security Features */}
          <div className="mt-6 pt-6 border-t">
            <h4 className="text-sm font-medium mb-3 flex items-center gap-2">
              <Lock className="w-4 h-4" />
              Security Features
            </h4>
            <div className="grid grid-cols-2 gap-3 text-xs text-gray-600">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3 text-green-500" />
                <span>256-bit Encryption</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3 text-green-500" />
                <span>MFA Support</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3 text-green-500" />
                <span>Secure Sessions</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle className="w-3 h-3 text-green-500" />
                <span>Audit Logging</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
