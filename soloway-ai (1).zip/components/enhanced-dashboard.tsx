"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Globe,
  Palette,
  Search,
  Mail,
  Plus,
  BarChart3,
  Users,
  Eye,
  Zap,
  Settings,
  Bell,
  TrendingUp,
  Target,
  Activity,
} from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { AnimatedButton } from "@/components/animated-button"

interface DashboardStats {
  websites: number
  totalViews: number
  emailSubscribers: number
  conversionRate: number
  revenue: number
  growth: number
}

interface RecentActivity {
  id: string
  type: "website" | "logo" | "name" | "email"
  action: string
  description: string
  timestamp: string
  status: "success" | "pending" | "error"
}

interface Website {
  id: string
  name: string
  domain: string
  status: "published" | "draft" | "archived"
  views: number
  lastUpdated: string
  thumbnail?: string
}

export function EnhancedDashboard() {
  const [stats, setStats] = useState<DashboardStats>({
    websites: 2,
    totalViews: 1234,
    emailSubscribers: 89,
    conversionRate: 3.2,
    revenue: 0,
    growth: 12.5,
  })

  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([
    {
      id: "1",
      type: "website",
      action: "Published",
      description: "My Portfolio went live",
      timestamp: "2 hours ago",
      status: "success",
    },
    {
      id: "2",
      type: "logo",
      action: "Created",
      description: "New logo for Business Landing",
      timestamp: "1 day ago",
      status: "success",
    },
    {
      id: "3",
      type: "name",
      action: "Generated",
      description: "Created 5 business name ideas",
      timestamp: "2 days ago",
      status: "success",
    },
    {
      id: "4",
      type: "email",
      action: "Campaign Sent",
      description: "Welcome series to 45 subscribers",
      timestamp: "3 days ago",
      status: "success",
    },
  ])

  const [websites, setWebsites] = useState<Website[]>([
    {
      id: "1",
      name: "My Portfolio",
      domain: "myportfolio.soloway.ai",
      status: "published",
      views: 856,
      lastUpdated: "2 hours ago",
    },
    {
      id: "2",
      name: "Business Landing",
      domain: "business.soloway.ai",
      status: "draft",
      views: 0,
      lastUpdated: "1 day ago",
    },
  ])

  const [selectedTimeRange, setSelectedTimeRange] = useState<"7d" | "30d" | "90d">("30d")

  // Simulated real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => ({
        ...prev,
        totalViews: prev.totalViews + Math.floor(Math.random() * 5),
        emailSubscribers: prev.emailSubscribers + (Math.random() > 0.9 ? 1 : 0),
      }))
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const getActivityIcon = (type: RecentActivity["type"]) => {
    switch (type) {
      case "website":
        return Globe
      case "logo":
        return Palette
      case "name":
        return Zap
      case "email":
        return Mail
      default:
        return Activity
    }
  }

  const getStatusColor = (status: RecentActivity["status"]) => {
    switch (status) {
      case "success":
        return "text-green-600"
      case "pending":
        return "text-yellow-600"
      case "error":
        return "text-red-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Enhanced Header */}
      <header className="bg-white dark:bg-gray-800 border-b shadow-sm">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                SoloWay AI
              </span>
            </div>
            <Badge variant="secondary" className="hidden sm:inline-flex">
              Free Plan
            </Badge>
          </div>
          <div className="flex items-center space-x-4">
            <AnimatedButton variant="ghost" size="sm" className="relative">
              <Bell className="w-4 h-4" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full"></span>
            </AnimatedButton>
            <ThemeToggle />
            <AnimatedButton variant="ghost" size="sm">
              <Settings className="w-4 h-4" />
            </AnimatedButton>
            <div className="w-8 h-8 bg-purple-100 dark:bg-purple-900 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-purple-600 dark:text-purple-300">JD</span>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Welcome Section with Time-based Greeting */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">
            {new Date().getHours() < 12
              ? "Good morning"
              : new Date().getHours() < 18
                ? "Good afternoon"
                : "Good evening"}
            , John!
          </h1>
          <p className="text-gray-600 dark:text-gray-400">Here's what's happening with your projects today</p>
        </div>

        {/* Enhanced Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Websites</p>
                  <p className="text-2xl font-bold">{stats.websites}</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <TrendingUp className="w-3 h-3 mr-1" />+{stats.growth}% this month
                  </p>
                </div>
                <Globe className="w-8 h-8 text-purple-600" />
              </div>
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-purple-600 to-blue-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Views</p>
                  <p className="text-2xl font-bold">{stats.totalViews.toLocaleString()}</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <Eye className="w-3 h-3 mr-1" />
                    Live tracking
                  </p>
                </div>
                <Eye className="w-8 h-8 text-blue-600" />
              </div>
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 to-cyan-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Email Subscribers</p>
                  <p className="text-2xl font-bold">{stats.emailSubscribers}</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <Users className="w-3 h-3 mr-1" />
                    +8% this week
                  </p>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-green-600 to-emerald-600"></div>
            </CardContent>
          </Card>

          <Card className="relative overflow-hidden">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Conversion Rate</p>
                  <p className="text-2xl font-bold">{stats.conversionRate}%</p>
                  <p className="text-xs text-green-600 flex items-center mt-1">
                    <Target className="w-3 h-3 mr-1" />
                    Above average
                  </p>
                </div>
                <BarChart3 className="w-8 h-8 text-orange-600" />
              </div>
              <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-orange-600 to-red-600"></div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Enhanced Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Get started with these essential tools</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <AnimatedButton
                    className="h-24 flex-col space-y-2 relative group"
                    variant="outline"
                    asChild
                    animation="bounce"
                  >
                    <Link href="/builder">
                      <Globe className="w-8 h-8 group-hover:scale-110 transition-transform" />
                      <span className="font-medium">Website Builder</span>
                      <span className="text-xs text-gray-500">Create & edit websites</span>
                    </Link>
                  </AnimatedButton>

                  <AnimatedButton
                    className="h-24 flex-col space-y-2 relative group"
                    variant="outline"
                    asChild
                    animation="bounce"
                  >
                    <Link href="/name-generator">
                      <Zap className="w-8 h-8 group-hover:scale-110 transition-transform" />
                      <span className="font-medium">Name Generator</span>
                      <span className="text-xs text-gray-500">AI-powered names</span>
                    </Link>
                  </AnimatedButton>

                  <AnimatedButton
                    className="h-24 flex-col space-y-2 relative group"
                    variant="outline"
                    asChild
                    animation="bounce"
                  >
                    <Link href="/logo-maker">
                      <Palette className="w-8 h-8 group-hover:scale-110 transition-transform" />
                      <span className="font-medium">Logo Maker</span>
                      <span className="text-xs text-gray-500">Design custom logos</span>
                    </Link>
                  </AnimatedButton>

                  <AnimatedButton
                    className="h-24 flex-col space-y-2 relative group"
                    variant="outline"
                    asChild
                    animation="bounce"
                  >
                    <Link href="/seo-tools">
                      <Search className="w-8 h-8 group-hover:scale-110 transition-transform" />
                      <span className="font-medium">SEO Tools</span>
                      <span className="text-xs text-gray-500">Optimize for search</span>
                    </Link>
                  </AnimatedButton>
                </div>
              </CardContent>
            </Card>

            {/* Enhanced Websites Management */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Your Websites</CardTitle>
                  <CardDescription>Manage and monitor your websites</CardDescription>
                </div>
                <AnimatedButton size="sm" asChild animation="bounce">
                  <Link href="/builder">
                    <Plus className="w-4 h-4 mr-2" />
                    New Website
                  </Link>
                </AnimatedButton>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {websites.map((website) => (
                    <div
                      key={website.id}
                      className="flex items-center justify-between p-4 border rounded-lg hover:shadow-md transition-shadow"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-400 rounded-lg flex items-center justify-center">
                          <Globe className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h3 className="font-medium">{website.name}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{website.domain}</p>
                          <div className="flex items-center space-x-4 mt-1 text-xs text-gray-500">
                            <span className="flex items-center">
                              <Eye className="w-3 h-3 mr-1" />
                              {website.views} views
                            </span>
                            <span>Updated {website.lastUpdated}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          variant={website.status === "published" ? "default" : "secondary"}
                          className={website.status === "published" ? "bg-green-100 text-green-700" : ""}
                        >
                          {website.status}
                        </Badge>
                        <AnimatedButton size="sm" variant="outline" asChild animation="bounce">
                          <Link href={`/builder/${website.id}`}>Edit</Link>
                        </AnimatedButton>
                        <AnimatedButton size="sm" variant="outline">
                          <BarChart3 className="w-4 h-4" />
                        </AnimatedButton>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Analytics Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>Analytics Overview</span>
                  <div className="flex gap-2">
                    {(["7d", "30d", "90d"] as const).map((range) => (
                      <Button
                        key={range}
                        variant={selectedTimeRange === range ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedTimeRange(range)}
                      >
                        {range}
                      </Button>
                    ))}
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">2.4k</div>
                    <div className="text-sm text-gray-600">Page Views</div>
                    <div className="text-xs text-green-600">+15% vs last period</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">1.8k</div>
                    <div className="text-sm text-gray-600">Unique Visitors</div>
                    <div className="text-xs text-green-600">+12% vs last period</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">3m 24s</div>
                    <div className="text-sm text-gray-600">Avg. Session</div>
                    <div className="text-xs text-red-600">-5% vs last period</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Enhanced Sidebar */}
          <div className="space-y-6">
            {/* Upgrade Card with Progress */}
            <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950">
              <CardHeader>
                <CardTitle className="text-purple-700 dark:text-purple-300">Upgrade to Pro</CardTitle>
                <CardDescription>Unlock all features and remove limits</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Websites used</span>
                      <span>2/3</span>
                    </div>
                    <Progress value={66} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Email subscribers</span>
                      <span>89/100</span>
                    </div>
                    <Progress value={89} className="h-2" />
                  </div>
                  <AnimatedButton className="w-full bg-purple-600 hover:bg-purple-700" asChild animation="glow">
                    <Link href="/pricing">Upgrade Now</Link>
                  </AnimatedButton>
                </div>
              </CardContent>
            </Card>

            {/* Enhanced Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="w-5 h-5 mr-2" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity) => {
                    const Icon = getActivityIcon(activity.type)
                    return (
                      <div key={activity.id} className="flex items-start space-x-3">
                        <div
                          className={`w-8 h-8 rounded-full flex items-center justify-center ${
                            activity.status === "success"
                              ? "bg-green-100 text-green-600"
                              : activity.status === "pending"
                                ? "bg-yellow-100 text-yellow-600"
                                : "bg-red-100 text-red-600"
                          }`}
                        >
                          <Icon className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium">{activity.action}</p>
                          <p className="text-xs text-gray-600 dark:text-gray-400">{activity.description}</p>
                          <p className="text-xs text-gray-500">{activity.timestamp}</p>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Email Marketing Quick Stats */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Mail className="w-5 h-5 mr-2" />
                  Email Marketing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold">{stats.emailSubscribers}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Total Subscribers</p>
                  </div>
                  <div className="grid grid-cols-2 gap-4 text-center text-sm">
                    <div>
                      <div className="font-bold text-green-600">24.5%</div>
                      <div className="text-gray-600">Open Rate</div>
                    </div>
                    <div>
                      <div className="font-bold text-blue-600">3.2%</div>
                      <div className="text-gray-600">Click Rate</div>
                    </div>
                  </div>
                  <AnimatedButton className="w-full" variant="outline" asChild animation="bounce">
                    <Link href="/email-marketing">Create Campaign</Link>
                  </AnimatedButton>
                </div>
              </CardContent>
            </Card>

            {/* Quick Tips */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Target className="w-5 h-5 mr-2" />
                  Quick Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                    <h4 className="font-medium text-sm text-blue-700 dark:text-blue-300">SEO Tip</h4>
                    <p className="text-xs text-blue-600 dark:text-blue-400">
                      Add meta descriptions to improve search rankings
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 dark:bg-green-950 rounded-lg">
                    <h4 className="font-medium text-sm text-green-700 dark:text-green-300">Performance</h4>
                    <p className="text-xs text-green-600 dark:text-green-400">
                      Optimize images to improve page load speed
                    </p>
                  </div>
                  <div className="p-3 bg-purple-50 dark:bg-purple-950 rounded-lg">
                    <h4 className="font-medium text-sm text-purple-700 dark:text-purple-300">Growth</h4>
                    <p className="text-xs text-purple-600 dark:text-purple-400">
                      Add email signup forms to capture leads
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
