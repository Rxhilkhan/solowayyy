"use client"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Palette, Download, Undo, Redo, Type, Circle, Square, Triangle, Star, Heart, Eye, EyeOff } from "lucide-react"
import { PaywallGuard } from "@/components/paywall-guard"

interface LogoElement {
  id: string
  type: "text" | "shape" | "icon"
  content: string
  x: number
  y: number
  width: number
  height: number
  color: string
  fontSize?: number
  fontFamily?: string
  rotation: number
  opacity: number
  visible: boolean
}

interface LogoDesign {
  id: string
  name: string
  elements: LogoElement[]
  backgroundColor: string
  width: number
  height: number
}

const PRESET_COLORS = [
  "#FF6B6B",
  "#4ECDC4",
  "#45B7D1",
  "#96CEB4",
  "#FFEAA7",
  "#DDA0DD",
  "#98D8C8",
  "#F7DC6F",
  "#BB8FCE",
  "#85C1E9",
  "#F8C471",
  "#82E0AA",
  "#F1948A",
  "#85C1E9",
  "#D7BDE2",
]

const FONT_FAMILIES = [
  "Arial",
  "Helvetica",
  "Times New Roman",
  "Georgia",
  "Verdana",
  "Trebuchet MS",
  "Impact",
  "Comic Sans MS",
  "Courier New",
  "Lucida Console",
]

const SHAPE_TYPES = [
  { name: "Circle", icon: Circle, type: "circle" },
  { name: "Square", icon: Square, type: "rectangle" },
  { name: "Triangle", icon: Triangle, type: "triangle" },
  { name: "Star", icon: Star, type: "star" },
  { name: "Heart", icon: Heart, type: "heart" },
]

export function EnhancedLogoMaker() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [logoDesign, setLogoDesign] = useState<LogoDesign>({
    id: "1",
    name: "My Logo",
    elements: [],
    backgroundColor: "#FFFFFF",
    width: 400,
    height: 400,
  })

  const [selectedElement, setSelectedElement] = useState<string | null>(null)
  const [history, setHistory] = useState<LogoDesign[]>([logoDesign])
  const [historyIndex, setHistoryIndex] = useState(0)
  const [previewMode, setPreviewMode] = useState<"light" | "dark" | "transparent">("light")
  const [isExporting, setIsExporting] = useState(false)

  // Canvas drawing effect
  useEffect(() => {
    drawCanvas()
  }, [logoDesign, previewMode])

  const drawCanvas = () => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height)

    // Set background based on preview mode
    let bgColor = logoDesign.backgroundColor
    if (previewMode === "dark") bgColor = "#1a1a1a"
    if (previewMode === "transparent") bgColor = "transparent"

    if (bgColor !== "transparent") {
      ctx.fillStyle = bgColor
      ctx.fillRect(0, 0, canvas.width, canvas.height)
    }

    // Draw elements
    logoDesign.elements
      .filter((element) => element.visible)
      .forEach((element) => {
        ctx.save()

        // Apply transformations
        ctx.globalAlpha = element.opacity
        ctx.translate(element.x + element.width / 2, element.y + element.height / 2)
        ctx.rotate((element.rotation * Math.PI) / 180)
        ctx.translate(-element.width / 2, -element.height / 2)

        if (element.type === "text") {
          ctx.fillStyle = element.color
          ctx.font = `${element.fontSize || 24}px ${element.fontFamily || "Arial"}`
          ctx.textAlign = "center"
          ctx.textBaseline = "middle"
          ctx.fillText(element.content, element.width / 2, element.height / 2)
        } else if (element.type === "shape") {
          ctx.fillStyle = element.color
          drawShape(ctx, element)
        }

        ctx.restore()
      })
  }

  const drawShape = (ctx: CanvasRenderingContext2D, element: LogoElement) => {
    const { width, height } = element
    const centerX = width / 2
    const centerY = height / 2

    switch (element.content) {
      case "circle":
        ctx.beginPath()
        ctx.arc(centerX, centerY, Math.min(width, height) / 2, 0, 2 * Math.PI)
        ctx.fill()
        break
      case "rectangle":
        ctx.fillRect(0, 0, width, height)
        break
      case "triangle":
        ctx.beginPath()
        ctx.moveTo(centerX, 0)
        ctx.lineTo(0, height)
        ctx.lineTo(width, height)
        ctx.closePath()
        ctx.fill()
        break
      case "star":
        drawStar(ctx, centerX, centerY, 5, Math.min(width, height) / 2, Math.min(width, height) / 4)
        break
      case "heart":
        drawHeart(ctx, centerX, centerY, Math.min(width, height) / 2)
        break
    }
  }

  const drawStar = (
    ctx: CanvasRenderingContext2D,
    cx: number,
    cy: number,
    spikes: number,
    outerRadius: number,
    innerRadius: number,
  ) => {
    let rot = (Math.PI / 2) * 3
    let x = cx
    let y = cy
    const step = Math.PI / spikes

    ctx.beginPath()
    ctx.moveTo(cx, cy - outerRadius)

    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius
      y = cy + Math.sin(rot) * outerRadius
      ctx.lineTo(x, y)
      rot += step

      x = cx + Math.cos(rot) * innerRadius
      y = cy + Math.sin(rot) * innerRadius
      ctx.lineTo(x, y)
      rot += step
    }

    ctx.lineTo(cx, cy - outerRadius)
    ctx.closePath()
    ctx.fill()
  }

  const drawHeart = (ctx: CanvasRenderingContext2D, cx: number, cy: number, size: number) => {
    ctx.beginPath()
    const topCurveHeight = size * 0.3
    ctx.moveTo(cx, cy + topCurveHeight)
    ctx.bezierCurveTo(cx, cy, cx - size / 2, cy, cx - size / 2, cy + topCurveHeight)
    ctx.bezierCurveTo(
      cx - size / 2,
      cy + (size + topCurveHeight) / 2,
      cx,
      cy + (size + topCurveHeight) / 2,
      cx,
      cy + size,
    )
    ctx.bezierCurveTo(
      cx,
      cy + (size + topCurveHeight) / 2,
      cx + size / 2,
      cy + (size + topCurveHeight) / 2,
      cx + size / 2,
      cy + topCurveHeight,
    )
    ctx.bezierCurveTo(cx + size / 2, cy, cx, cy, cx, cy + topCurveHeight)
    ctx.closePath()
    ctx.fill()
  }

  const addTextElement = () => {
    const newElement: LogoElement = {
      id: Date.now().toString(),
      type: "text",
      content: "Your Text",
      x: 150,
      y: 180,
      width: 100,
      height: 40,
      color: "#000000",
      fontSize: 24,
      fontFamily: "Arial",
      rotation: 0,
      opacity: 1,
      visible: true,
    }

    updateDesign({
      ...logoDesign,
      elements: [...logoDesign.elements, newElement],
    })
  }

  const addShapeElement = (shapeType: string) => {
    const newElement: LogoElement = {
      id: Date.now().toString(),
      type: "shape",
      content: shapeType,
      x: 150,
      y: 150,
      width: 100,
      height: 100,
      color: "#4ECDC4",
      rotation: 0,
      opacity: 1,
      visible: true,
    }

    updateDesign({
      ...logoDesign,
      elements: [...logoDesign.elements, newElement],
    })
  }

  const updateElement = (elementId: string, updates: Partial<LogoElement>) => {
    const updatedElements = logoDesign.elements.map((element) =>
      element.id === elementId ? { ...element, ...updates } : element,
    )

    updateDesign({
      ...logoDesign,
      elements: updatedElements,
    })
  }

  const deleteElement = (elementId: string) => {
    const updatedElements = logoDesign.elements.filter((element) => element.id !== elementId)
    updateDesign({
      ...logoDesign,
      elements: updatedElements,
    })
    setSelectedElement(null)
  }

  const updateDesign = (newDesign: LogoDesign) => {
    setLogoDesign(newDesign)

    // Update history
    const newHistory = history.slice(0, historyIndex + 1)
    newHistory.push(newDesign)
    setHistory(newHistory)
    setHistoryIndex(newHistory.length - 1)
  }

  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1)
      setLogoDesign(history[historyIndex - 1])
    }
  }

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1)
      setLogoDesign(history[historyIndex + 1])
    }
  }

  const exportLogo = async (format: "png" | "svg" = "png") => {
    setIsExporting(true)

    try {
      const canvas = canvasRef.current
      if (!canvas) return

      if (format === "png") {
        const link = document.createElement("a")
        link.download = `${logoDesign.name.replace(/\s+/g, "_")}.png`
        link.href = canvas.toDataURL("image/png")
        link.click()
      }
    } catch (error) {
      console.error("Export error:", error)
    } finally {
      setIsExporting(false)
    }
  }

  const selectedElementData = selectedElement ? logoDesign.elements.find((el) => el.id === selectedElement) : null

  return (
    <PaywallGuard featureId="premium_logo_maker">
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold flex items-center gap-2">
                  <Palette className="w-8 h-8 text-purple-600" />
                  Enhanced Logo Maker
                </h1>
                <p className="text-gray-600 dark:text-gray-400">Create professional logos with advanced tools</p>
              </div>
              <div className="flex items-center gap-2">
                <Button variant="outline" onClick={undo} disabled={historyIndex === 0}>
                  <Undo className="w-4 h-4" />
                </Button>
                <Button variant="outline" onClick={redo} disabled={historyIndex === history.length - 1}>
                  <Redo className="w-4 h-4" />
                </Button>
                <Button onClick={() => exportLogo("png")} disabled={isExporting}>
                  <Download className="w-4 h-4 mr-2" />
                  {isExporting ? "Exporting..." : "Export PNG"}
                </Button>
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-4 gap-6">
            {/* Tools Panel */}
            <div className="lg:col-span-1 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Add Elements</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button onClick={addTextElement} className="w-full justify-start">
                    <Type className="w-4 h-4 mr-2" />
                    Add Text
                  </Button>

                  <div className="space-y-2">
                    <Label>Shapes</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {SHAPE_TYPES.map((shape) => (
                        <Button
                          key={shape.type}
                          variant="outline"
                          size="sm"
                          onClick={() => addShapeElement(shape.type)}
                          className="flex flex-col items-center p-2 h-auto"
                        >
                          <shape.icon className="w-4 h-4 mb-1" />
                          <span className="text-xs">{shape.name}</span>
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Canvas Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Background Color</Label>
                    <div className="flex items-center gap-2 mt-2">
                      <Input
                        type="color"
                        value={logoDesign.backgroundColor}
                        onChange={(e) =>
                          updateDesign({
                            ...logoDesign,
                            backgroundColor: e.target.value,
                          })
                        }
                        className="w-12 h-8 p-1 border rounded"
                      />
                      <Input
                        value={logoDesign.backgroundColor}
                        onChange={(e) =>
                          updateDesign({
                            ...logoDesign,
                            backgroundColor: e.target.value,
                          })
                        }
                        className="flex-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Preview Mode</Label>
                    <Select value={previewMode} onValueChange={(value: any) => setPreviewMode(value)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="light">Light Background</SelectItem>
                        <SelectItem value="dark">Dark Background</SelectItem>
                        <SelectItem value="transparent">Transparent</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Color Palette */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Color Palette</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-5 gap-2">
                    {PRESET_COLORS.map((color) => (
                      <button
                        key={color}
                        className="w-8 h-8 rounded border-2 border-gray-200 hover:border-gray-400 transition-colors"
                        style={{ backgroundColor: color }}
                        onClick={() => {
                          if (selectedElementData) {
                            updateElement(selectedElement!, { color })
                          }
                        }}
                      />
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Canvas Area */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Canvas</span>
                    <Badge variant="secondary">
                      {logoDesign.width} × {logoDesign.height}
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-center">
                    <div className="relative border-2 border-dashed border-gray-300 rounded-lg p-4">
                      <canvas
                        ref={canvasRef}
                        width={logoDesign.width}
                        height={logoDesign.height}
                        className="border border-gray-200 rounded shadow-sm cursor-crosshair"
                        onClick={(e) => {
                          const rect = canvasRef.current?.getBoundingClientRect()
                          if (!rect) return

                          const x = e.clientX - rect.left
                          const y = e.clientY - rect.top

                          // Find clicked element
                          const clickedElement = logoDesign.elements.find(
                            (element) =>
                              x >= element.x &&
                              x <= element.x + element.width &&
                              y >= element.y &&
                              y <= element.y + element.height,
                          )

                          setSelectedElement(clickedElement?.id || null)
                        }}
                      />

                      {/* Selection indicator */}
                      {selectedElementData && (
                        <div
                          className="absolute border-2 border-blue-500 pointer-events-none"
                          style={{
                            left: selectedElementData.x + 16,
                            top: selectedElementData.y + 16,
                            width: selectedElementData.width,
                            height: selectedElementData.height,
                          }}
                        />
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Properties Panel */}
            <div className="lg:col-span-1 space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Layers</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {logoDesign.elements.map((element, index) => (
                      <div
                        key={element.id}
                        className={`flex items-center justify-between p-2 rounded border cursor-pointer ${
                          selectedElement === element.id ? "border-blue-500 bg-blue-50" : "border-gray-200"
                        }`}
                        onClick={() => setSelectedElement(element.id)}
                      >
                        <div className="flex items-center gap-2">
                          {element.type === "text" ? <Type className="w-4 h-4" /> : <Circle className="w-4 h-4" />}
                          <span className="text-sm truncate">
                            {element.type === "text" ? element.content : element.content}
                          </span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation()
                              updateElement(element.id, { visible: !element.visible })
                            }}
                          >
                            {element.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
                          </Button>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation()
                              deleteElement(element.id)
                            }}
                          >
                            ×
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {selectedElementData && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Properties</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Tabs defaultValue="style">
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="style">Style</TabsTrigger>
                        <TabsTrigger value="transform">Transform</TabsTrigger>
                      </TabsList>

                      <TabsContent value="style" className="space-y-4">
                        {selectedElementData.type === "text" && (
                          <>
                            <div>
                              <Label>Text Content</Label>
                              <Input
                                value={selectedElementData.content}
                                onChange={(e) => updateElement(selectedElement!, { content: e.target.value })}
                              />
                            </div>

                            <div>
                              <Label>Font Family</Label>
                              <Select
                                value={selectedElementData.fontFamily}
                                onValueChange={(value) => updateElement(selectedElement!, { fontFamily: value })}
                              >
                                <SelectTrigger>
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                  {FONT_FAMILIES.map((font) => (
                                    <SelectItem key={font} value={font}>
                                      {font}
                                    </SelectItem>
                                  ))}
                                </SelectContent>
                              </Select>
                            </div>

                            <div>
                              <Label>Font Size: {selectedElementData.fontSize}px</Label>
                              <Slider
                                value={[selectedElementData.fontSize || 24]}
                                onValueChange={([value]) => updateElement(selectedElement!, { fontSize: value })}
                                min={8}
                                max={72}
                                step={1}
                              />
                            </div>
                          </>
                        )}

                        <div>
                          <Label>Color</Label>
                          <div className="flex items-center gap-2 mt-2">
                            <Input
                              type="color"
                              value={selectedElementData.color}
                              onChange={(e) => updateElement(selectedElement!, { color: e.target.value })}
                              className="w-12 h-8 p-1 border rounded"
                            />
                            <Input
                              value={selectedElementData.color}
                              onChange={(e) => updateElement(selectedElement!, { color: e.target.value })}
                              className="flex-1"
                            />
                          </div>
                        </div>
                      </TabsContent>

                      <TabsContent value="transform" className="space-y-4">
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label>X Position</Label>
                            <Input
                              type="number"
                              value={selectedElementData.x}
                              onChange={(e) =>
                                updateElement(selectedElement!, { x: Number.parseInt(e.target.value) || 0 })
                              }
                            />
                          </div>
                          <div>
                            <Label>Y Position</Label>
                            <Input
                              type="number"
                              value={selectedElementData.y}
                              onChange={(e) =>
                                updateElement(selectedElement!, { y: Number.parseInt(e.target.value) || 0 })
                              }
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <Label>Width</Label>
                            <Input
                              type="number"
                              value={selectedElementData.width}
                              onChange={(e) =>
                                updateElement(selectedElement!, { width: Number.parseInt(e.target.value) || 1 })
                              }
                            />
                          </div>
                          <div>
                            <Label>Height</Label>
                            <Input
                              type="number"
                              value={selectedElementData.height}
                              onChange={(e) =>
                                updateElement(selectedElement!, { height: Number.parseInt(e.target.value) || 1 })
                              }
                            />
                          </div>
                        </div>

                        <div>
                          <Label>Rotation: {selectedElementData.rotation}°</Label>
                          <Slider
                            value={[selectedElementData.rotation]}
                            onValueChange={([value]) => updateElement(selectedElement!, { rotation: value })}
                            min={-180}
                            max={180}
                            step={1}
                          />
                        </div>

                        <div>
                          <Label>Opacity: {Math.round(selectedElementData.opacity * 100)}%</Label>
                          <Slider
                            value={[selectedElementData.opacity]}
                            onValueChange={([value]) => updateElement(selectedElement!, { opacity: value })}
                            min={0}
                            max={1}
                            step={0.01}
                          />
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </div>
      </div>
    </PaywallGuard>
  )
}
