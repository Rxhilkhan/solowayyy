"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import type React from "react"

interface AnimatedButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
  size?: "default" | "sm" | "lg" | "icon"
  animation?: "bounce" | "scale" | "slide" | "glow"
}

export function AnimatedButton({
  children,
  className,
  animation = "scale",
  variant = "default",
  size = "default",
  ...props
}: AnimatedButtonProps) {
  const animations = {
    bounce: {
      whileHover: { y: -2 },
      whileTap: { y: 0 },
      transition: { type: "spring", stiffness: 400, damping: 10 },
    },
    scale: {
      whileHover: { scale: 1.05 },
      whileTap: { scale: 0.95 },
      transition: { type: "spring", stiffness: 400, damping: 10 },
    },
    slide: {
      whileHover: { x: 5 },
      whileTap: { x: 0 },
      transition: { type: "spring", stiffness: 400, damping: 10 },
    },
    glow: {
      whileHover: {
        boxShadow: "0 0 20px rgba(139, 92, 246, 0.5)",
        scale: 1.02,
      },
      whileTap: { scale: 0.98 },
      transition: { duration: 0.2 },
    },
  }

  return (
    <motion.div {...animations[animation]}>
      <Button variant={variant} size={size} className={cn("transition-all duration-200", className)} {...props}>
        {children}
      </Button>
    </motion.div>
  )
}
