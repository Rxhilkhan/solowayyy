"use client"

import { useState } from "react"
import { DndContext, type DragEndEvent, DragOverlay, type DragStartEvent, closestCenter } from "@dnd-kit/core"
import { SortableContext, verticalListSortingStrategy } from "@dnd-kit/sortable"
import { useSortable } from "@dnd-kit/sortable"
import { CSS } from "@dnd-kit/utilities"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Type, ImageIcon, Square, Layers, GripVertical, Trash2 } from "lucide-react"

interface BuilderElement {
  id: string
  type: "text" | "image" | "button" | "section"
  content: string
  styles: Record<string, string>
}

interface SortableItemProps {
  element: BuilderElement
  onDelete: (id: string) => void
  onEdit: (id: string, content: string) => void
}

function SortableItem({ element, onDelete, onEdit }: SortableItemProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id: element.id })

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  }

  const renderElement = () => {
    switch (element.type) {
      case "text":
        return (
          <div
            className="p-4 border-2 border-dashed border-gray-300 hover:border-purple-400 transition-colors cursor-text"
            onClick={() => {
              const newContent = prompt("Edit text:", element.content)
              if (newContent) onEdit(element.id, newContent)
            }}
          >
            <p>{element.content || "Click to edit text"}</p>
          </div>
        )
      case "image":
        return (
          <div className="p-4 border-2 border-dashed border-gray-300 hover:border-purple-400 transition-colors">
            <div className="w-full h-32 bg-gray-200 rounded flex items-center justify-center">
              <ImageIcon className="w-8 h-8 text-gray-400" />
            </div>
            <p className="text-sm text-gray-500 text-center mt-2">Click to add image</p>
          </div>
        )
      case "button":
        return (
          <div className="p-4 border-2 border-dashed border-gray-300 hover:border-purple-400 transition-colors">
            <Button
              className="bg-purple-600 hover:bg-purple-700"
              onClick={() => {
                const newContent = prompt("Edit button text:", element.content)
                if (newContent) onEdit(element.id, newContent)
              }}
            >
              {element.content || "Button Text"}
            </Button>
          </div>
        )
      case "section":
        return (
          <div className="p-8 border-2 border-dashed border-gray-300 hover:border-purple-400 transition-colors bg-gray-50">
            <h3 className="text-lg font-semibold mb-2">{element.content || "Section Title"}</h3>
            <p className="text-gray-600">This is a section container. Add content here.</p>
          </div>
        )
      default:
        return null
    }
  }

  return (
    <div ref={setNodeRef} style={style} className="relative group">
      <div className="absolute top-2 left-2 z-10 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex space-x-1">
          <Button size="sm" variant="outline" className="h-6 w-6 p-0 bg-white" {...attributes} {...listeners}>
            <GripVertical className="h-3 w-3" />
          </Button>
          <Button
            size="sm"
            variant="outline"
            className="h-6 w-6 p-0 bg-white hover:bg-red-50"
            onClick={() => onDelete(element.id)}
          >
            <Trash2 className="h-3 w-3 text-red-500" />
          </Button>
        </div>
      </div>
      {renderElement()}
    </div>
  )
}

export function DragDropBuilder() {
  const [elements, setElements] = useState<BuilderElement[]>([])
  const [activeId, setActiveId] = useState<string | null>(null)

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id as string)
  }

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event

    if (active.id !== over?.id) {
      setElements((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id)
        const newIndex = items.findIndex((item) => item.id === over?.id)

        const newItems = [...items]
        const [reorderedItem] = newItems.splice(oldIndex, 1)
        newItems.splice(newIndex, 0, reorderedItem)

        return newItems
      })
    }

    setActiveId(null)
  }

  const addElement = (type: BuilderElement["type"]) => {
    const newElement: BuilderElement = {
      id: `${type}-${Date.now()}`,
      type,
      content:
        type === "text" ? "Sample text" : type === "button" ? "Click me" : type === "section" ? "New Section" : "",
      styles: {},
    }
    setElements([...elements, newElement])
  }

  const deleteElement = (id: string) => {
    setElements(elements.filter((el) => el.id !== id))
  }

  const editElement = (id: string, content: string) => {
    setElements(elements.map((el) => (el.id === id ? { ...el, content } : el)))
  }

  return (
    <div className="flex h-full">
      {/* Element Palette */}
      <div className="w-64 bg-white dark:bg-gray-900 border-r p-4">
        <h3 className="font-semibold mb-4">Elements</h3>
        <div className="grid grid-cols-2 gap-2">
          <Button variant="outline" className="h-16 flex-col space-y-1" size="sm" onClick={() => addElement("text")}>
            <Type className="w-4 h-4" />
            <span className="text-xs">Text</span>
          </Button>
          <Button variant="outline" className="h-16 flex-col space-y-1" size="sm" onClick={() => addElement("image")}>
            <ImageIcon className="w-4 h-4" />
            <span className="text-xs">Image</span>
          </Button>
          <Button variant="outline" className="h-16 flex-col space-y-1" size="sm" onClick={() => addElement("button")}>
            <Square className="w-4 h-4" />
            <span className="text-xs">Button</span>
          </Button>
          <Button variant="outline" className="h-16 flex-col space-y-1" size="sm" onClick={() => addElement("section")}>
            <Layers className="w-4 h-4" />
            <span className="text-xs">Section</span>
          </Button>
        </div>
      </div>

      {/* Canvas */}
      <div className="flex-1 bg-gray-100 dark:bg-gray-800 p-8 overflow-auto">
        <Card className="max-w-4xl mx-auto min-h-[800px] bg-white dark:bg-gray-900">
          <CardContent className="p-0">
            <DndContext collisionDetection={closestCenter} onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
              <SortableContext items={elements.map((el) => el.id)} strategy={verticalListSortingStrategy}>
                <div className="space-y-2 p-4">
                  {elements.length === 0 ? (
                    <div className="text-center py-20 text-gray-500">
                      <Layers className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Drag elements from the left panel to start building</p>
                    </div>
                  ) : (
                    elements.map((element) => (
                      <SortableItem key={element.id} element={element} onDelete={deleteElement} onEdit={editElement} />
                    ))
                  )}
                </div>
              </SortableContext>
              <DragOverlay>
                {activeId ? (
                  <div className="opacity-50">
                    <SortableItem
                      element={elements.find((el) => el.id === activeId)!}
                      onDelete={() => {}}
                      onEdit={() => {}}
                    />
                  </div>
                ) : null}
              </DragOverlay>
            </DndContext>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
