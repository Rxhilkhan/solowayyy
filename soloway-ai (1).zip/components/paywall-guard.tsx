"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Lock, Crown, ArrowRight } from "lucide-react"
import { paywallService, type PaywallFeature } from "@/lib/paywall"
import { authService } from "@/lib/auth"
import Link from "next/link"

interface PaywallGuardProps {
  featureId: string
  children: React.ReactNode
  fallback?: React.ReactNode
}

export function PaywallGuard({ featureId, children, fallback }: PaywallGuardProps) {
  const [hasAccess, setHasAccess] = useState<boolean | null>(null)
  const [feature, setFeature] = useState<PaywallFeature | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    checkAccess()
  }, [featureId])

  const checkAccess = async () => {
    try {
      const user = await authService.getCurrentUser()
      if (!user) {
        setHasAccess(false)
        setLoading(false)
        return
      }

      const canAccess = await paywallService.canAccessFeature(user.id, featureId)
      const featureData = paywallService.paywallFeatures.find((f) => f.id === featureId)

      setHasAccess(canAccess)
      setFeature(featureData || null)
      setLoading(false)
    } catch (error) {
      console.error("Error checking feature access:", error)
      setHasAccess(false)
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center p-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  if (hasAccess) {
    return <>{children}</>
  }

  if (fallback) {
    return <>{fallback}</>
  }

  return (
    <Card className="border-2 border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950">
      <CardHeader className="text-center">
        <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
          <Lock className="w-8 h-8 text-white" />
        </div>
        <CardTitle className="flex items-center justify-center gap-2">
          <Crown className="w-5 h-5 text-purple-600" />
          Premium Feature
        </CardTitle>
        <CardDescription>
          {feature?.name} - {feature?.description}
        </CardDescription>
      </CardHeader>
      <CardContent className="text-center space-y-4">
        <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-300">
          Requires {feature?.requiredPlan?.toUpperCase()} Plan
        </Badge>
        <p className="text-sm text-muted-foreground">
          Upgrade your plan to access this premium feature and unlock your full potential.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button asChild className="bg-purple-600 hover:bg-purple-700">
            <Link href="/pricing">
              Upgrade Now
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link href="/dashboard">Back to Dashboard</Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
