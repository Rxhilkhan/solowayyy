"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, CreditCard, Shield, Zap } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

declare global {
  interface Window {
    Razorpay: any
  }
}

interface RazorpayCheckoutProps {
  planType: "pro"
  amount: number
  planName: string
  features: string[]
}

export default function RazorpayCheckout({ planType, amount, planName, features }: RazorpayCheckoutProps) {
  const [loading, setLoading] = useState(false)
  const { toast } = useToast()

  const handlePayment = async () => {
    try {
      setLoading(true)

      // Create order
      const orderResponse = await fetch("/api/razorpay/create-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          amount,
          planType,
        }),
      })

      if (!orderResponse.ok) {
        throw new Error("Failed to create order")
      }

      const orderData = await orderResponse.json()

      // Load Razorpay script
      const script = document.createElement("script")
      script.src = "https://checkout.razorpay.com/v1/checkout.js"
      script.async = true
      document.body.appendChild(script)

      script.onload = () => {
        const options = {
          key: orderData.keyId,
          amount: orderData.amount,
          currency: orderData.currency,
          name: "SoloWay AI",
          description: `${planName} Subscription`,
          order_id: orderData.orderId,
          image: "/logo-orange.png",
          handler: async (response: any) => {
            try {
              // Verify payment
              const verifyResponse = await fetch("/api/razorpay/verify-payment", {
                method: "POST",
                headers: {
                  "Content-Type": "application/json",
                },
                body: JSON.stringify({
                  razorpay_order_id: response.razorpay_order_id,
                  razorpay_payment_id: response.razorpay_payment_id,
                  razorpay_signature: response.razorpay_signature,
                }),
              })

              if (verifyResponse.ok) {
                toast({
                  title: "Payment Successful!",
                  description: "Your subscription has been activated.",
                })
                window.location.href = "/dashboard"
              } else {
                throw new Error("Payment verification failed")
              }
            } catch (error) {
              toast({
                title: "Payment Verification Failed",
                description: "Please contact support if amount was deducted.",
                variant: "destructive",
              })
            }
          },
          prefill: {
            name: "",
            email: "",
            contact: "",
          },
          notes: {
            plan_type: planType,
          },
          theme: {
            color: "#f97316",
          },
          modal: {
            ondismiss: () => {
              setLoading(false)
            },
          },
        }

        const rzp = new window.Razorpay(options)
        rzp.open()
      }
    } catch (error) {
      console.error("Payment error:", error)
      toast({
        title: "Payment Failed",
        description: "Unable to process payment. Please try again.",
        variant: "destructive",
      })
      setLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
          <Zap className="w-6 h-6 text-orange-600" />
        </div>
        <CardTitle className="text-2xl">{planName}</CardTitle>
        <CardDescription>Everything you need to build your online presence</CardDescription>
        <div className="text-center py-4">
          <div className="text-4xl font-bold">₹{amount}</div>
          <div className="text-sm text-muted-foreground">per month</div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        <div className="space-y-3">
          {features.map((feature, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-3 h-3 text-green-600" />
              </div>
              <span className="text-sm">{feature}</span>
            </div>
          ))}
        </div>

        <div className="space-y-3">
          <Button
            onClick={handlePayment}
            disabled={loading}
            className="w-full bg-orange-600 hover:bg-orange-700"
            size="lg"
          >
            <CreditCard className="w-4 h-4 mr-2" />
            {loading ? "Processing..." : `Pay ₹${amount}`}
          </Button>

          <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground">
            <Shield className="w-3 h-3" />
            Secured by Razorpay
          </div>
        </div>

        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
            <Badge variant="outline" className="text-xs">
              UPI
            </Badge>
            <Badge variant="outline" className="text-xs">
              Cards
            </Badge>
            <Badge variant="outline" className="text-xs">
              Net Banking
            </Badge>
            <Badge variant="outline" className="text-xs">
              Wallets
            </Badge>
          </div>
          <p className="text-xs text-muted-foreground">Cancel anytime • 30-day money-back guarantee</p>
        </div>
      </CardContent>
    </Card>
  )
}
