"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import type React from "react"

interface EnhancedButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link"
  size?: "default" | "sm" | "lg" | "icon"
  animation?: "bounce" | "scale" | "slide" | "glow" | "pulse" | "shake" | "flip"
  glowColor?: string
}

export function EnhancedButton({
  children,
  className,
  animation = "scale",
  variant = "default",
  size = "default",
  glowColor = "rgba(139, 92, 246, 0.5)",
  ...props
}: EnhancedButtonProps) {
  const animations = {
    bounce: {
      whileHover: { y: -3, transition: { type: "spring", stiffness: 400, damping: 10 } },
      whileTap: { y: 0, scale: 0.98 },
    },
    scale: {
      whileHover: { scale: 1.05, transition: { type: "spring", stiffness: 400, damping: 10 } },
      whileTap: { scale: 0.95 },
    },
    slide: {
      whileHover: { x: 5, transition: { type: "spring", stiffness: 400, damping: 10 } },
      whileTap: { x: 0 },
    },
    glow: {
      whileHover: {
        boxShadow: `0 0 20px ${glowColor}`,
        scale: 1.02,
        transition: { duration: 0.2 },
      },
      whileTap: { scale: 0.98 },
    },
    pulse: {
      whileHover: {
        scale: [1, 1.05, 1],
        transition: { duration: 0.6, repeat: Number.POSITIVE_INFINITY },
      },
      whileTap: { scale: 0.95 },
    },
    shake: {
      whileHover: {
        x: [-1, 1, -1, 1, 0],
        transition: { duration: 0.4 },
      },
      whileTap: { scale: 0.95 },
    },
    flip: {
      whileHover: { rotateY: 180, transition: { duration: 0.6 } },
      whileTap: { scale: 0.95 },
    },
  }

  return (
    <motion.div {...animations[animation]}>
      <Button variant={variant} size={size} className={cn("transition-all duration-200", className)} {...props}>
        {children}
      </Button>
    </motion.div>
  )
}
