import { createServerClient } from "@/lib/supabase"
import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"
import { securityHeaders } from "@/lib/security"

// Rate limiting store (in production, use Redis or similar)
const rateLimitStore = new Map<string, { count: number; resetTime: number }>()

// Rate limiting function
function rateLimit(identifier: string, limit = 100, windowMs = 60000): boolean {
  const now = Date.now()
  const key = identifier
  const record = rateLimitStore.get(key)

  if (!record || now > record.resetTime) {
    rateLimitStore.set(key, { count: 1, resetTime: now + windowMs })
    return true
  }

  if (record.count >= limit) {
    return false
  }

  record.count++
  return true
}

export async function middleware(request: NextRequest) {
  const response = NextResponse.next()

  // Apply security headers to all responses
  Object.entries(securityHeaders).forEach(([key, value]) => {
    response.headers.set(key, value)
  })

  // Get client IP for rate limiting
  const clientIP = request.ip || request.headers.get("x-forwarded-for") || "unknown"

  // Apply rate limiting
  if (!rateLimit(clientIP, 100, 60000)) {
    return new NextResponse("Too Many Requests", {
      status: 429,
      headers: {
        "Retry-After": "60",
        ...Object.fromEntries(Object.entries(securityHeaders)),
      },
    })
  }

  // Protected routes that require authentication
  const protectedPaths = [
    "/dashboard",
    "/builder",
    "/name-generator",
    "/logo-maker",
    "/seo-tools",
    "/email-marketing",
    "/admin",
  ]

  const isProtectedPath = protectedPaths.some((path) => request.nextUrl.pathname.startsWith(path))

  if (isProtectedPath) {
    try {
      const supabase = createServerClient()
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser()

      if (error || !user) {
        const redirectUrl = new URL("/auth/login", request.url)
        redirectUrl.searchParams.set("redirect", request.nextUrl.pathname)
        return NextResponse.redirect(redirectUrl)
      }

      // Check if user profile exists
      const { data: profile } = await supabase
        .from("user_profiles")
        .select("id, plan, subscription_status")
        .eq("id", user.id)
        .single()

      if (!profile) {
        return NextResponse.redirect(new URL("/auth/setup", request.url))
      }

      // Admin routes require admin access
      if (request.nextUrl.pathname.startsWith("/admin")) {
        // In a real app, check for admin role
        const isAdmin = profile.plan === "enterprise" // Simplified check
        if (!isAdmin) {
          return NextResponse.redirect(new URL("/dashboard", request.url))
        }
      }
    } catch (error) {
      console.error("Middleware auth error:", error)
      return NextResponse.redirect(new URL("/auth/login", request.url))
    }
  }

  // API routes security
  if (request.nextUrl.pathname.startsWith("/api/")) {
    // Add CORS headers for API routes
    response.headers.set("Access-Control-Allow-Origin", process.env.NEXT_PUBLIC_SITE_URL || "*")
    response.headers.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS")
    response.headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization")

    // Handle preflight requests
    if (request.method === "OPTIONS") {
      return new NextResponse(null, { status: 200, headers: response.headers })
    }

    // Enhanced rate limiting for API routes
    const apiLimit = request.nextUrl.pathname.includes("/auth/") ? 5 : 50 // Stricter for auth endpoints
    if (!rateLimit(`api:${clientIP}`, apiLimit, 60000)) {
      return new NextResponse("API Rate Limit Exceeded", {
        status: 429,
        headers: response.headers,
      })
    }
  }

  return response
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    "/((?!_next/static|_next/image|favicon.ico|public/).*)",
  ],
}
