import { authService } from "./auth"

export interface PaywallFeature {
  id: string
  name: string
  description: string
  requiredPlan: "free" | "pro" | "enterprise"
  isEnabled: boolean
}

export const paywallFeatures: PaywallFeature[] = [
  {
    id: "custom_domain",
    name: "Custom Domain",
    description: "Connect your own domain name",
    requiredPlan: "pro",
    isEnabled: true,
  },
  {
    id: "advanced_seo",
    name: "Advanced SEO Tools",
    description: "Advanced keyword research and SEO analysis",
    requiredPlan: "pro",
    isEnabled: true,
  },
  {
    id: "unlimited_websites",
    name: "Unlimited Websites",
    description: "Create unlimited websites",
    requiredPlan: "pro",
    isEnabled: true,
  },
  {
    id: "premium_templates",
    name: "Premium Templates",
    description: "Access to premium website templates",
    requiredPlan: "pro",
    isEnabled: true,
  },
  {
    id: "email_marketing",
    name: "Email Marketing",
    description: "Advanced email marketing campaigns",
    requiredPlan: "pro",
    isEnabled: true,
  },
  {
    id: "analytics",
    name: "Advanced Analytics",
    description: "Detailed website analytics and insights",
    requiredPlan: "pro",
    isEnabled: true,
  },
]

export const paywallService = {
  // Check if user can access a feature
  async canAccessFeature(userId: string, featureId: string): Promise<boolean> {
    const feature = paywallFeatures.find((f) => f.id === featureId)
    if (!feature || !feature.isEnabled) return false

    if (feature.requiredPlan === "free") return true

    const profile = await authService.getUserProfile(userId)
    if (!profile) return false

    // Check if user has required plan and active subscription
    const hasRequiredPlan = this.comparePlans(profile.plan, feature.requiredPlan) >= 0
    const hasActiveSubscription = profile.subscription_status === "active" || profile.plan === "free"

    return hasRequiredPlan && hasActiveSubscription
  },

  // Compare plan levels (free < pro < enterprise)
  comparePlans(userPlan: string, requiredPlan: string): number {
    const planLevels = { free: 0, pro: 1, enterprise: 2 }
    return planLevels[userPlan as keyof typeof planLevels] - planLevels[requiredPlan as keyof typeof planLevels]
  },

  // Get features available to user
  async getAvailableFeatures(userId: string): Promise<PaywallFeature[]> {
    const profile = await authService.getUserProfile(userId)
    if (!profile) return paywallFeatures.filter((f) => f.requiredPlan === "free")

    return paywallFeatures.filter((feature) => {
      if (!feature.isEnabled) return false
      if (feature.requiredPlan === "free") return true

      const hasRequiredPlan = this.comparePlans(profile.plan, feature.requiredPlan) >= 0
      const hasActiveSubscription = profile.subscription_status === "active" || profile.plan === "free"

      return hasRequiredPlan && hasActiveSubscription
    })
  },

  // Get blocked features for user
  async getBlockedFeatures(userId: string): Promise<PaywallFeature[]> {
    const availableFeatures = await this.getAvailableFeatures(userId)
    const availableIds = availableFeatures.map((f) => f.id)
    return paywallFeatures.filter((f) => f.isEnabled && !availableIds.includes(f.id))
  },
}
