import crypto from "crypto"
import bcrypt from "bcryptjs"

// Security headers for all responses
export const securityHeaders = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "X-XSS-Protection": "1; mode=block",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Content-Security-Policy":
    "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; font-src 'self' data:;",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
}

// Password validation
export const validators = {
  email: (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  },

  password: (password: string): { valid: boolean; errors: string[] } => {
    const errors: string[] = []

    if (password.length < 8) {
      errors.push("Password must be at least 8 characters long")
    }
    if (!/[A-Z]/.test(password)) {
      errors.push("Password must contain at least one uppercase letter")
    }
    if (!/[a-z]/.test(password)) {
      errors.push("Password must contain at least one lowercase letter")
    }
    if (!/\d/.test(password)) {
      errors.push("Password must contain at least one number")
    }
    if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
      errors.push("Password must contain at least one special character")
    }

    return { valid: errors.length === 0, errors }
  },

  sanitizeInput: (input: string): string => {
    return input.trim().replace(/[<>]/g, "")
  },
}

// Hash data with salt
export const hashData = async (data: string): Promise<string> => {
  const saltRounds = 12
  return await bcrypt.hash(data, saltRounds)
}

// Encrypt data
export const encryptData = (data: string): string => {
  const algorithm = "aes-256-cbc"
  const key = process.env.MFA_ENCRYPTION_KEY || crypto.randomBytes(32).toString("hex")
  const iv = crypto.randomBytes(16)

  const cipher = crypto.createCipher(algorithm, key)
  let encrypted = cipher.update(data, "utf8", "hex")
  encrypted += cipher.final("hex")

  return iv.toString("hex") + ":" + encrypted
}

// Decrypt data
export const decryptData = (encryptedData: string): string => {
  const algorithm = "aes-256-cbc"
  const key = process.env.MFA_ENCRYPTION_KEY || crypto.randomBytes(32).toString("hex")

  const parts = encryptedData.split(":")
  const iv = Buffer.from(parts[0], "hex")
  const encrypted = parts[1]

  const decipher = crypto.createDecipher(algorithm, key)
  let decrypted = decipher.update(encrypted, "hex", "utf8")
  decrypted += decipher.final("utf8")

  return decrypted
}

// Rate limiting
export const createRateLimit = (windowMs: number, maxRequests: number) => {
  const requests = new Map()

  return (identifier: string): boolean => {
    const now = Date.now()
    const windowStart = now - windowMs

    if (!requests.has(identifier)) {
      requests.set(identifier, [])
    }

    const userRequests = requests.get(identifier)
    const validRequests = userRequests.filter((time: number) => time > windowStart)

    if (validRequests.length >= maxRequests) {
      return false
    }

    validRequests.push(now)
    requests.set(identifier, validRequests)

    return true
  }
}

// Generate secure random token
export const generateSecureToken = (length = 32): string => {
  return crypto.randomBytes(length).toString("hex")
}

// Verify password hash
export const verifyPassword = async (password: string, hash: string): Promise<boolean> => {
  return await bcrypt.compare(password, hash)
}

// CSRF token generation and validation
export const generateCSRFToken = (): string => {
  return crypto.randomBytes(32).toString("hex")
}

export const validateCSRFToken = (token: string, sessionToken: string): boolean => {
  return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(sessionToken))
}

// Input sanitization
export const sanitizeInput = (input: string): string => {
  return input
    .replace(/[<>]/g, "") // Remove potential HTML tags
    .replace(/javascript:/gi, "") // Remove javascript: protocol
    .replace(/on\w+=/gi, "") // Remove event handlers
    .trim()
}

// Audit logging
export interface AuditLog {
  userId?: string
  action: string
  resource: string
  details: Record<string, any>
  ipAddress: string
  userAgent: string
  timestamp: Date
  success: boolean
}

export const logAuditEvent = async (log: AuditLog): Promise<void> => {
  console.log("AUDIT LOG:", JSON.stringify(log, null, 2))
}
