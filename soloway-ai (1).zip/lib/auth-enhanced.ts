import { createServerClient } from "@/lib/supabase"
import { generateSecureToken, hashData, encryptData, decryptData } from "@/lib/security"
import speakeasy from "speakeasy"
import QRCode from "qrcode"

export interface User {
  id: string
  email: string
  name: string
  avatar_url?: string
  plan: "free" | "pro" | "enterprise"
  subscription_status: "active" | "canceled" | "past_due"
  mfa_enabled: boolean
  mfa_secret?: string
  created_at: string
  updated_at: string
}

export interface LoginAttempt {
  id: string
  user_id?: string
  email: string
  ip_address: string
  user_agent: string
  success: boolean
  failure_reason?: string
  attempted_at: string
}

export interface Session {
  id: string
  user_id: string
  token: string
  expires_at: string
  ip_address: string
  user_agent: string
  created_at: string
}

export const enhancedAuthService = {
  // Get current user with enhanced security
  async getCurrentUser(): Promise<User | null> {
    try {
      const supabase = createServerClient()
      const {
        data: { user },
        error,
      } = await supabase.auth.getUser()

      if (error || !user) return null

      const { data: profile } = await supabase.from("user_profiles").select("*").eq("id", user.id).single()

      if (!profile) return null

      return {
        id: profile.id,
        email: profile.email,
        name: profile.name,
        avatar_url: profile.avatar_url,
        plan: profile.plan || "free",
        subscription_status: profile.subscription_status || "active",
        mfa_enabled: profile.mfa_enabled || false,
        mfa_secret: profile.mfa_secret,
        created_at: profile.created_at,
        updated_at: profile.updated_at,
      }
    } catch (error) {
      console.error("Error getting current user:", error)
      return null
    }
  },

  // Enhanced login with security tracking
  async signIn(
    email: string,
    password: string,
    mfaToken?: string,
    ipAddress?: string,
    userAgent?: string,
  ): Promise<{ success: boolean; user?: User; error?: string; requiresMFA?: boolean }> {
    try {
      const supabase = createServerClient()

      // Log login attempt
      await this.logLoginAttempt(email, ipAddress || "", userAgent || "", false)

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      })

      if (error) {
        await this.logLoginAttempt(email, ipAddress || "", userAgent || "", false, error.message)
        return { success: false, error: error.message }
      }

      if (!data.user) {
        return { success: false, error: "Authentication failed" }
      }

      // Check if MFA is enabled
      const { data: profile } = await supabase
        .from("user_profiles")
        .select("mfa_enabled, mfa_secret")
        .eq("id", data.user.id)
        .single()

      if (profile?.mfa_enabled) {
        if (!mfaToken) {
          return { success: false, requiresMFA: true }
        }

        // Verify MFA token
        const isValidMFA = speakeasy.totp.verify({
          secret: profile.mfa_secret,
          encoding: "base32",
          token: mfaToken,
          window: 2,
        })

        if (!isValidMFA) {
          await this.logLoginAttempt(email, ipAddress || "", userAgent || "", false, "Invalid MFA token")
          return { success: false, error: "Invalid MFA token" }
        }
      }

      // Create secure session
      await this.createSession(data.user.id, ipAddress || "", userAgent || "")

      // Log successful login
      await this.logLoginAttempt(email, ipAddress || "", userAgent || "", true)

      const user = await this.getCurrentUser()
      return { success: true, user: user || undefined }
    } catch (error: any) {
      console.error("Sign in error:", error)
      return { success: false, error: "Authentication failed" }
    }
  },

  // Enhanced signup with validation
  async signUp(
    email: string,
    password: string,
    name: string,
  ): Promise<{ success: boolean; user?: User; error?: string }> {
    try {
      const supabase = createServerClient()

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
          },
        },
      })

      if (error) {
        return { success: false, error: error.message }
      }

      if (!data.user) {
        return { success: false, error: "Registration failed" }
      }

      // Create user profile
      const { error: profileError } = await supabase.from("user_profiles").insert({
        id: data.user.id,
        email,
        name,
        plan: "free",
        subscription_status: "active",
        mfa_enabled: false,
      })

      if (profileError) {
        console.error("Profile creation error:", profileError)
      }

      const user = await this.getCurrentUser()
      return { success: true, user: user || undefined }
    } catch (error: any) {
      console.error("Sign up error:", error)
      return { success: false, error: "Registration failed" }
    }
  },

  // Setup MFA
  async setupMFA(userId: string): Promise<{ secret: string; qrCode: string; backupCodes: string[] }> {
    const secret = speakeasy.generateSecret({
      name: `SoloWay AI (${userId})`,
      issuer: "SoloWay AI",
    })

    const qrCode = await QRCode.toDataURL(secret.otpauth_url!)

    // Generate backup codes
    const backupCodes = Array.from({ length: 10 }, () => generateSecureToken(8))

    // Store encrypted secret and backup codes
    const supabase = createServerClient()
    const encryptedSecret = encryptData(secret.base32, process.env.MFA_ENCRYPTION_KEY!)
    const encryptedBackupCodes = encryptData(JSON.stringify(backupCodes), process.env.MFA_ENCRYPTION_KEY!)

    await supabase
      .from("user_profiles")
      .update({
        mfa_secret: encryptedSecret,
        mfa_backup_codes: encryptedBackupCodes,
      })
      .eq("id", userId)

    return {
      secret: secret.base32,
      qrCode,
      backupCodes,
    }
  },

  // Enable MFA
  async enableMFA(userId: string, token: string): Promise<{ success: boolean; error?: string }> {
    try {
      const supabase = createServerClient()

      const { data: profile } = await supabase.from("user_profiles").select("mfa_secret").eq("id", userId).single()

      if (!profile?.mfa_secret) {
        return { success: false, error: "MFA not set up" }
      }

      const decryptedSecret = decryptData(profile.mfa_secret, process.env.MFA_ENCRYPTION_KEY!)

      const isValid = speakeasy.totp.verify({
        secret: decryptedSecret,
        encoding: "base32",
        token,
        window: 2,
      })

      if (!isValid) {
        return { success: false, error: "Invalid token" }
      }

      await supabase.from("user_profiles").update({ mfa_enabled: true }).eq("id", userId)

      return { success: true }
    } catch (error) {
      console.error("Enable MFA error:", error)
      return { success: false, error: "Failed to enable MFA" }
    }
  },

  // Log login attempts for security monitoring
  async logLoginAttempt(
    email: string,
    ipAddress: string,
    userAgent: string,
    success: boolean,
    failureReason?: string,
  ): Promise<void> {
    try {
      const supabase = createServerClient()

      await supabase.from("login_attempts").insert({
        email,
        ip_address: ipAddress,
        user_agent: userAgent,
        success,
        failure_reason: failureReason,
        attempted_at: new Date().toISOString(),
      })
    } catch (error) {
      console.error("Error logging login attempt:", error)
    }
  },

  // Create secure session
  async createSession(userId: string, ipAddress: string, userAgent: string): Promise<void> {
    try {
      const supabase = createServerClient()
      const token = generateSecureToken(64)
      const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours

      await supabase.from("user_sessions").insert({
        user_id: userId,
        token: hashData(token),
        expires_at: expiresAt.toISOString(),
        ip_address: ipAddress,
        user_agent: userAgent,
      })
    } catch (error) {
      console.error("Error creating session:", error)
    }
  },

  // Get user profile
  async getUserProfile(userId: string): Promise<User | null> {
    try {
      const supabase = createServerClient()

      const { data: profile } = await supabase.from("user_profiles").select("*").eq("id", userId).single()

      if (!profile) return null

      return {
        id: profile.id,
        email: profile.email,
        name: profile.name,
        avatar_url: profile.avatar_url,
        plan: profile.plan || "free",
        subscription_status: profile.subscription_status || "active",
        mfa_enabled: profile.mfa_enabled || false,
        mfa_secret: profile.mfa_secret,
        created_at: profile.created_at,
        updated_at: profile.updated_at,
      }
    } catch (error) {
      console.error("Error getting user profile:", error)
      return null
    }
  },

  // Sign out with session cleanup
  async signOut(): Promise<void> {
    try {
      const supabase = createServerClient()
      const user = await this.getCurrentUser()

      if (user) {
        // Clean up sessions
        await supabase.from("user_sessions").delete().eq("user_id", user.id)
      }

      await supabase.auth.signOut()
    } catch (error) {
      console.error("Sign out error:", error)
    }
  },
}
