import { createClient as createSupabaseClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

// Client-side Supabase client
export const createClient = () => {
  return createSupabaseClient(supabaseUrl, supabaseAnonKey)
}

// Default client instance
export const supabase = createClient()

// Server-side client with service role key
export const createServerClient = () => {
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY!
  return createSupabaseClient(supabaseUrl, serviceRoleKey)
}

// Database types
export interface User {
  id: string
  email: string
  name: string
  subscription_status: "free" | "pro"
  created_at: string
  updated_at: string
}

export interface Website {
  id: string
  user_id: string
  name: string
  domain: string
  template: string
  content: any
  published: boolean
  created_at: string
  updated_at: string
}

export interface Payment {
  id: string
  user_id: string
  amount: number
  currency: string
  status: "pending" | "completed" | "failed"
  payment_method: string
  razorpay_payment_id?: string
  razorpay_order_id?: string
  created_at: string
}

export interface Subscription {
  id: string
  user_id: string
  plan: "free" | "pro"
  status: "active" | "cancelled" | "expired"
  current_period_start: string
  current_period_end: string
  razorpay_subscription_id?: string
  created_at: string
  updated_at: string
}

// Helper functions
export const getUserById = async (id: string): Promise<User | null> => {
  const { data, error } = await supabase.from("users").select("*").eq("id", id).single()

  if (error) {
    console.error("Error fetching user:", error)
    return null
  }

  return data
}

export const getUserByEmail = async (email: string): Promise<User | null> => {
  const { data, error } = await supabase.from("users").select("*").eq("email", email).single()

  if (error) {
    console.error("Error fetching user by email:", error)
    return null
  }

  return data
}

export const createUser = async (userData: Partial<User>): Promise<User | null> => {
  const { data, error } = await supabase.from("users").insert([userData]).select().single()

  if (error) {
    console.error("Error creating user:", error)
    return null
  }

  return data
}

export const updateUser = async (id: string, updates: Partial<User>): Promise<User | null> => {
  const { data, error } = await supabase.from("users").update(updates).eq("id", id).select().single()

  if (error) {
    console.error("Error updating user:", error)
    return null
  }

  return data
}

export const getUserWebsites = async (userId: string): Promise<Website[]> => {
  const { data, error } = await supabase
    .from("websites")
    .select("*")
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching user websites:", error)
    return []
  }

  return data || []
}

export const createWebsite = async (websiteData: Partial<Website>): Promise<Website | null> => {
  const { data, error } = await supabase.from("websites").insert([websiteData]).select().single()

  if (error) {
    console.error("Error creating website:", error)
    return null
  }

  return data
}

export const updateWebsite = async (id: string, updates: Partial<Website>): Promise<Website | null> => {
  const { data, error } = await supabase.from("websites").update(updates).eq("id", id).select().single()

  if (error) {
    console.error("Error updating website:", error)
    return null
  }

  return data
}

export const deleteWebsite = async (id: string): Promise<boolean> => {
  const { error } = await supabase.from("websites").delete().eq("id", id)

  if (error) {
    console.error("Error deleting website:", error)
    return false
  }

  return true
}

export const createPayment = async (paymentData: Partial<Payment>): Promise<Payment | null> => {
  const { data, error } = await supabase.from("payments").insert([paymentData]).select().single()

  if (error) {
    console.error("Error creating payment:", error)
    return null
  }

  return data
}

export const updatePayment = async (id: string, updates: Partial<Payment>): Promise<Payment | null> => {
  const { data, error } = await supabase.from("payments").update(updates).eq("id", id).select().single()

  if (error) {
    console.error("Error updating payment:", error)
    return null
  }

  return data
}

export const getUserSubscription = async (userId: string): Promise<Subscription | null> => {
  const { data, error } = await supabase
    .from("subscriptions")
    .select("*")
    .eq("user_id", userId)
    .eq("status", "active")
    .single()

  if (error) {
    console.error("Error fetching user subscription:", error)
    return null
  }

  return data
}

export const createSubscription = async (subscriptionData: Partial<Subscription>): Promise<Subscription | null> => {
  const { data, error } = await supabase.from("subscriptions").insert([subscriptionData]).select().single()

  if (error) {
    console.error("Error creating subscription:", error)
    return null
  }

  return data
}

export const updateSubscription = async (id: string, updates: Partial<Subscription>): Promise<Subscription | null> => {
  const { data, error } = await supabase.from("subscriptions").update(updates).eq("id", id).select().single()

  if (error) {
    console.error("Error updating subscription:", error)
    return null
  }

  return data
}
