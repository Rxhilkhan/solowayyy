import Stripe from "stripe"

if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("STRIPE_SECRET_KEY is not set")
}

export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2024-06-20",
  typescript: true,
})

export const STRIPE_PLANS = {
  free: {
    name: "Free",
    price: 0,
    priceId: null,
    features: ["3 websites", "Basic templates", "SoloWay subdomain", "100 email subscribers", "Basic support"],
  },
  pro: {
    name: "Pro",
    price: 999, // $9.99 in cents
    priceId: process.env.STRIPE_PRO_PRICE_ID,
    features: [
      "Unlimited websites",
      "Premium templates",
      "Custom domain",
      "10,000 email subscribers",
      "Advanced SEO tools",
      "Priority support",
    ],
  },
}

export async function createCheckoutSession(userId: string, priceId: string, successUrl: string, cancelUrl: string) {
  const session = await stripe.checkout.sessions.create({
    customer_creation: "always",
    payment_method_types: ["card"],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    mode: "subscription",
    success_url: successUrl,
    cancel_url: cancelUrl,
    metadata: {
      userId,
    },
    subscription_data: {
      metadata: {
        userId,
      },
    },
  })

  return session
}

export async function createPortalSession(customerId: string, returnUrl: string) {
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  })

  return session
}
