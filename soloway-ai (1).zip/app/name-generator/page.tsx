"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Sparkles, Copy, Heart, RefreshCw, Download } from "lucide-react"

export default function NameGeneratorPage() {
  const [businessType, setBusinessType] = useState("")
  const [keywords, setKeywords] = useState("")
  const [style, setStyle] = useState("")
  const [generatedNames, setGeneratedNames] = useState<string[]>([])
  const [favorites, setFavorites] = useState<string[]>([])
  const [isGenerating, setIsGenerating] = useState(false)

  const businessTypes = [
    "Technology",
    "E-commerce",
    "Consulting",
    "Restaurant",
    "Fashion",
    "Health & Fitness",
    "Real Estate",
    "Education",
    "Finance",
    "Creative Agency",
  ]

  const nameStyles = ["Modern", "Classic", "Creative", "Professional", "Playful", "Minimalist"]

  const sampleNames = [
    "TechFlow Solutions",
    "Digital Nexus",
    "InnovateLab",
    "CloudSync Pro",
    "DataVault Systems",
    "SmartEdge Technologies",
    "FutureForge",
    "CodeCraft Studios",
    "TechPulse",
    "DigitalSphere",
  ]

  const handleGenerate = async () => {
    if (!businessType || !keywords) {
      alert("Please fill in business type and keywords")
      return
    }

    setIsGenerating(true)

    // Simulate API call
    setTimeout(() => {
      setGeneratedNames(sampleNames.sort(() => Math.random() - 0.5).slice(0, 8))
      setIsGenerating(false)
    }, 2000)
  }

  const toggleFavorite = (name: string) => {
    setFavorites((prev) => (prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]))
  }

  const copyToClipboard = (name: string) => {
    navigator.clipboard.writeText(name)
    alert("Name copied to clipboard!")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Business Name Generator</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Generate unique and memorable business names powered by AI. Perfect for startups, brands, and new ventures.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Input Form */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-blue-600" />
                  Generate Names
                </CardTitle>
                <CardDescription>Tell us about your business and we'll generate perfect names</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="businessType">Business Type</Label>
                  <Select value={businessType} onValueChange={setBusinessType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select business type" />
                    </SelectTrigger>
                    <SelectContent>
                      {businessTypes.map((type) => (
                        <SelectItem key={type} value={type.toLowerCase()}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="keywords">Keywords</Label>
                  <Input
                    id="keywords"
                    placeholder="e.g., tech, digital, smart"
                    value={keywords}
                    onChange={(e) => setKeywords(e.target.value)}
                  />
                  <p className="text-xs text-gray-500">Enter words that describe your business (comma separated)</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="style">Style (Optional)</Label>
                  <Select value={style} onValueChange={setStyle}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a style" />
                    </SelectTrigger>
                    <SelectContent>
                      {nameStyles.map((styleOption) => (
                        <SelectItem key={styleOption} value={styleOption.toLowerCase()}>
                          {styleOption}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <Button
                  onClick={handleGenerate}
                  className="w-full bg-blue-600 hover:bg-blue-700"
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4 mr-2" />
                      Generate Names
                    </>
                  )}
                </Button>

                {generatedNames.length > 0 && (
                  <Button
                    onClick={handleGenerate}
                    variant="outline"
                    className="w-full bg-transparent"
                    disabled={isGenerating}
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Generate More
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Favorites */}
            {favorites.length > 0 && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-red-500" />
                    Favorites ({favorites.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {favorites.map((name, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-red-50 rounded">
                        <span className="font-medium">{name}</span>
                        <Button size="sm" variant="ghost" onClick={() => copyToClipboard(name)}>
                          <Copy className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    <Button className="w-full mt-4" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Export Favorites
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Generated Names */}
          <div className="lg:col-span-2">
            {generatedNames.length === 0 ? (
              <Card className="h-96 flex items-center justify-center">
                <CardContent className="text-center">
                  <Sparkles className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">Ready to Generate Names?</h3>
                  <p className="text-gray-500">
                    Fill in your business details and click "Generate Names" to get started
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">Generated Names ({generatedNames.length})</h2>
                  <Badge variant="secondary">
                    {businessType} • {style || "Any Style"}
                  </Badge>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {generatedNames.map((name, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h3 className="font-semibold text-lg text-gray-900">{name}</h3>
                            <p className="text-sm text-gray-500">
                              Available domain: {name.toLowerCase().replace(/\s+/g, "")}.com
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => toggleFavorite(name)}
                              className={favorites.includes(name) ? "text-red-500" : "text-gray-400"}
                            >
                              <Heart className={`h-4 w-4 ${favorites.includes(name) ? "fill-current" : ""}`} />
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => copyToClipboard(name)}>
                              <Copy className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
