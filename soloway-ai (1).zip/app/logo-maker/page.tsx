"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Palette, Download, Sparkles, Heart, RefreshCw, Zap } from "lucide-react"

export default function LogoMakerPage() {
  const [businessName, setBusinessName] = useState("")
  const [industry, setIndustry] = useState("")
  const [selectedStyle, setSelectedStyle] = useState("")
  const [selectedColor, setSelectedColor] = useState("")
  const [generatedLogos, setGeneratedLogos] = useState<any[]>([])
  const [favorites, setFavorites] = useState<number[]>([])
  const [isGenerating, setIsGenerating] = useState(false)

  const industries = [
    "Technology",
    "Healthcare",
    "Finance",
    "Education",
    "Food & Beverage",
    "Fashion",
    "Real Estate",
    "Consulting",
    "Marketing",
    "Construction",
  ]

  const logoStyles = ["Modern", "Minimalist", "Vintage", "Bold", "Elegant", "Playful"]

  const colorSchemes = [
    { name: "Blue", colors: ["#3B82F6", "#1E40AF", "#60A5FA"] },
    { name: "Green", colors: ["#10B981", "#059669", "#34D399"] },
    { name: "Purple", colors: ["#8B5CF6", "#7C3AED", "#A78BFA"] },
    { name: "Orange", colors: ["#F97316", "#EA580C", "#FB923C"] },
    { name: "Red", colors: ["#EF4444", "#DC2626", "#F87171"] },
    { name: "Gray", colors: ["#6B7280", "#4B5563", "#9CA3AF"] },
  ]

  const sampleLogos = [
    { id: 1, name: "TechFlow", style: "Modern", colors: ["#3B82F6", "#1E40AF"] },
    { id: 2, name: "GreenLeaf", style: "Organic", colors: ["#10B981", "#059669"] },
    { id: 3, name: "UrbanCafe", style: "Vintage", colors: ["#F97316", "#EA580C"] },
    { id: 4, name: "BuildPro", style: "Bold", colors: ["#EF4444", "#DC2626"] },
    { id: 5, name: "ArtSpace", style: "Creative", colors: ["#8B5CF6", "#7C3AED"] },
    { id: 6, name: "FinanceHub", style: "Professional", colors: ["#6B7280", "#4B5563"] },
  ]

  const handleGenerate = async () => {
    if (!businessName) {
      alert("Please enter your business name")
      return
    }

    setIsGenerating(true)

    // Simulate API call
    setTimeout(() => {
      const logos = sampleLogos.map((logo) => ({
        ...logo,
        name: businessName,
        id: Math.random(),
      }))
      setGeneratedLogos(logos)
      setIsGenerating(false)
    }, 3000)
  }

  const toggleFavorite = (logoId: number) => {
    setFavorites((prev) => (prev.includes(logoId) ? prev.filter((id) => id !== logoId) : [...prev, logoId]))
  }

  const downloadLogo = (logo: any) => {
    alert(`Downloading ${logo.name} logo in high resolution...`)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">AI Logo Maker</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Create professional logos in minutes with our AI-powered design tool. No design experience required.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Controls */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-purple-600" />
                  Logo Generator
                </CardTitle>
                <CardDescription>Customize your logo preferences</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="businessName">Business Name *</Label>
                  <Input
                    id="businessName"
                    placeholder="Enter your business name"
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="industry">Industry</Label>
                  <Select value={industry} onValueChange={setIndustry}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select industry" />
                    </SelectTrigger>
                    <SelectContent>
                      {industries.map((ind) => (
                        <SelectItem key={ind} value={ind.toLowerCase()}>
                          {ind}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="style">Logo Style</Label>
                  <Select value={selectedStyle} onValueChange={setSelectedStyle}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose style" />
                    </SelectTrigger>
                    <SelectContent>
                      {logoStyles.map((style) => (
                        <SelectItem key={style} value={style.toLowerCase()}>
                          {style}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Color Scheme</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {colorSchemes.map((scheme) => (
                      <button
                        key={scheme.name}
                        onClick={() => setSelectedColor(scheme.name)}
                        className={`p-2 rounded border-2 transition-all ${
                          selectedColor === scheme.name
                            ? "border-purple-500 ring-2 ring-purple-200"
                            : "border-gray-200 hover:border-gray-300"
                        }`}
                      >
                        <div className="flex gap-1">
                          {scheme.colors.map((color, index) => (
                            <div key={index} className="w-4 h-4 rounded-full" style={{ backgroundColor: color }} />
                          ))}
                        </div>
                        <p className="text-xs mt-1">{scheme.name}</p>
                      </button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={handleGenerate}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Generating...
                    </>
                  ) : (
                    <>
                      <Zap className="h-4 w-4 mr-2" />
                      Generate Logos
                    </>
                  )}
                </Button>

                {generatedLogos.length > 0 && (
                  <Button
                    onClick={handleGenerate}
                    variant="outline"
                    className="w-full bg-transparent"
                    disabled={isGenerating}
                  >
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Generate More
                  </Button>
                )}
              </CardContent>
            </Card>

            {/* Favorites */}
            {favorites.length > 0 && (
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Heart className="h-5 w-5 text-red-500" />
                    Favorites ({favorites.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">
                    You have {favorites.length} favorite logo{favorites.length !== 1 ? "s" : ""}
                  </p>
                  <Button className="w-full" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download All Favorites
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Generated Logos */}
          <div className="lg:col-span-3">
            {generatedLogos.length === 0 ? (
              <Card className="h-96 flex items-center justify-center">
                <CardContent className="text-center">
                  <Palette className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">Ready to Create Your Logo?</h3>
                  <p className="text-gray-500">
                    Enter your business name and preferences, then click "Generate Logos" to get started
                  </p>
                </CardContent>
              </Card>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-bold text-gray-900">Your Logo Options ({generatedLogos.length})</h2>
                  <div className="flex gap-2">
                    <Badge variant="secondary">{industry || "Any Industry"}</Badge>
                    <Badge variant="secondary">{selectedStyle || "Any Style"}</Badge>
                  </div>
                </div>

                <Tabs defaultValue="grid" className="w-full">
                  <TabsList className="mb-6">
                    <TabsTrigger value="grid">Grid View</TabsTrigger>
                    <TabsTrigger value="list">List View</TabsTrigger>
                  </TabsList>

                  <TabsContent value="grid">
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {generatedLogos.map((logo) => (
                        <Card key={logo.id} className="hover:shadow-lg transition-shadow">
                          <CardContent className="p-4">
                            <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg mb-4 flex items-center justify-center">
                              <div className="text-center">
                                <div
                                  className="w-16 h-16 rounded-full mx-auto mb-2"
                                  style={{
                                    background: `linear-gradient(45deg, ${logo.colors[0]}, ${logo.colors[1]})`,
                                  }}
                                />
                                <h3 className="font-bold text-lg">{logo.name}</h3>
                                <p className="text-sm text-gray-500">{logo.style}</p>
                              </div>
                            </div>

                            <div className="flex items-center justify-between">
                              <Badge variant="outline">{logo.style}</Badge>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => toggleFavorite(logo.id)}
                                  className={favorites.includes(logo.id) ? "text-red-500" : "text-gray-400"}
                                >
                                  <Heart className={`h-4 w-4 ${favorites.includes(logo.id) ? "fill-current" : ""}`} />
                                </Button>
                                <Button size="sm" variant="ghost" onClick={() => downloadLogo(logo)}>
                                  <Download className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>

                  <TabsContent value="list">
                    <div className="space-y-4">
                      {generatedLogos.map((logo) => (
                        <Card key={logo.id}>
                          <CardContent className="p-4">
                            <div className="flex items-center gap-4">
                              <div className="w-16 h-16 bg-gradient-to-br from-gray-100 to-gray-200 rounded-lg flex items-center justify-center">
                                <div
                                  className="w-8 h-8 rounded-full"
                                  style={{
                                    background: `linear-gradient(45deg, ${logo.colors[0]}, ${logo.colors[1]})`,
                                  }}
                                />
                              </div>
                              <div className="flex-1">
                                <h3 className="font-semibold text-lg">{logo.name}</h3>
                                <p className="text-gray-600">{logo.style} style</p>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => toggleFavorite(logo.id)}
                                  className={favorites.includes(logo.id) ? "text-red-500" : "text-gray-400"}
                                >
                                  <Heart className={`h-4 w-4 ${favorites.includes(logo.id) ? "fill-current" : ""}`} />
                                </Button>
                                <Button size="sm" onClick={() => downloadLogo(logo)}>
                                  <Download className="h-4 w-4 mr-2" />
                                  Download
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </TabsContent>
                </Tabs>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
