import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { EnhancedButton } from "@/components/enhanced-button"
import { ThemeToggle } from "@/components/theme-toggle"
import { ArrowLeft, Shield, Award, Users, Star, CheckCircle, Lock, Heart, Quote } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function TrustPage() {
  const stats = [
    { number: "50,000+", label: "Happy Customers", icon: Users },
    { number: "99.9%", label: "Uptime Guarantee", icon: Shield },
    { number: "4.9/5", label: "Customer Rating", icon: Star },
    { number: "24/7", label: "Support Available", icon: CheckCircle },
  ]

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Freelance Designer",
      company: "Creative Studio",
      content:
        "SoloWay AI transformed my business. I went from struggling to get clients to having a waiting list in just 3 months!",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Mike Chen",
      role: "E-commerce Owner",
      company: "TechGadgets Pro",
      content:
        "The website builder is incredibly intuitive. I built my entire online store without any coding knowledge.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "Emily Rodriguez",
      role: "Marketing Consultant",
      company: "Growth Marketing Co",
      content: "The AI tools saved me hours of work. The name generator and logo maker are absolutely brilliant!",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
    {
      name: "David Thompson",
      role: "Restaurant Owner",
      company: "Bella Vista Restaurant",
      content: "Our online presence increased by 300% after using SoloWay AI. The results speak for themselves.",
      rating: 5,
      avatar: "/placeholder.svg?height=60&width=60",
    },
  ]

  const certifications = [
    { name: "SOC 2 Compliant", icon: Shield },
    { name: "GDPR Compliant", icon: Lock },
    { name: "SSL Encrypted", icon: CheckCircle },
    { name: "ISO 27001", icon: Award },
  ]

  const achievements = [
    { title: "Best Website Builder 2024", organization: "TechCrunch" },
    { title: "Top AI Tool for Small Business", organization: "Forbes" },
    { title: "Editor's Choice Award", organization: "PC Magazine" },
    { title: "Best Customer Support", organization: "G2 Crowd" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <EnhancedButton variant="ghost" size="sm" asChild animation="slide">
              <Link href="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </EnhancedButton>
            <div className="flex items-center space-x-2">
              <Image src="/logo-white.png" alt="SoloWay AI" width={24} height={24} className="dark:hidden" />
              <Image src="/logo-orange.png" alt="SoloWay AI" width={24} height={24} className="hidden dark:block" />
              <span className="font-semibold">Customer Trust</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <EnhancedButton
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              animation="glow"
              asChild
            >
              <Link href="/auth/signup">Get Started</Link>
            </EnhancedButton>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-200">
            <Shield className="w-4 h-4 mr-2" />
            Trusted by 50,000+ Businesses
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Why Thousands Trust SoloWay AI</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            We're committed to providing secure, reliable, and exceptional service to help your business succeed online.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat, index) => {
            const IconComponent = stat.icon
            return (
              <Card
                key={index}
                className="text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                <CardContent className="p-6">
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <IconComponent className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <div className="text-3xl font-bold mb-2">{stat.number}</div>
                  <div className="text-sm text-muted-foreground">{stat.label}</div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Testimonials Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
            <p className="text-xl text-muted-foreground">Real stories from real entrepreneurs</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <Quote className="w-8 h-8 text-purple-600 dark:text-purple-400 flex-shrink-0 mt-1" />
                    <div>
                      <p className="text-muted-foreground mb-4 italic">"{testimonial.content}"</p>
                      <div className="flex items-center space-x-1 mb-3">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                      <div className="flex items-center space-x-3">
                        <Image
                          src={testimonial.avatar || "/placeholder.svg"}
                          alt={testimonial.name}
                          width={40}
                          height={40}
                          className="rounded-full"
                        />
                        <div>
                          <div className="font-semibold">{testimonial.name}</div>
                          <div className="text-sm text-muted-foreground">
                            {testimonial.role} at {testimonial.company}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Security & Compliance */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Security & Compliance</h2>
            <p className="text-xl text-muted-foreground">Your data is safe and secure with us</p>
          </div>

          <div className="grid md:grid-cols-4 gap-6">
            {certifications.map((cert, index) => {
              const IconComponent = cert.icon
              return (
                <Card key={index} className="text-center hover:shadow-lg transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="w-12 h-12 bg-gradient-to-r from-green-100 to-emerald-100 dark:from-green-900 dark:to-emerald-900 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <IconComponent className="w-6 h-6 text-green-600 dark:text-green-400" />
                    </div>
                    <div className="font-semibold">{cert.name}</div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>

        {/* Awards & Recognition */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Awards & Recognition</h2>
            <p className="text-xl text-muted-foreground">Recognized by industry leaders</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {achievements.map((achievement, index) => (
              <Card key={index} className="hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6 flex items-center space-x-4">
                  <div className="w-12 h-12 bg-gradient-to-r from-yellow-100 to-orange-100 dark:from-yellow-900 dark:to-orange-900 rounded-lg flex items-center justify-center">
                    <Award className="w-6 h-6 text-yellow-600 dark:text-yellow-400" />
                  </div>
                  <div>
                    <div className="font-semibold">{achievement.title}</div>
                    <div className="text-sm text-muted-foreground">{achievement.organization}</div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 border-purple-200 dark:border-purple-800">
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Heart className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-3xl font-bold mb-4">Join Our Trusted Community</h3>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto text-lg">
              Start your journey with SoloWay AI today and see why thousands of entrepreneurs trust us with their online
              success.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <EnhancedButton
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                animation="glow"
                asChild
              >
                <Link href="/auth/signup">Start Free Trial</Link>
              </EnhancedButton>
              <EnhancedButton size="lg" variant="outline" animation="bounce" asChild>
                <Link href="/contact">Contact Us</Link>
              </EnhancedButton>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
