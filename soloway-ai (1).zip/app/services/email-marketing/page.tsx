"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Mail,
  Users,
  BarChart3,
  Zap,
  CheckCircle,
  ArrowRight,
  Filter,
  Target,
  TrendingUp,
  Sparkles,
} from "lucide-react"
import Link from "next/link"

export default function EmailMarketingPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const features = [
    {
      icon: <Mail className="h-6 w-6" />,
      title: "Drag & Drop Editor",
      description: "Create beautiful emails with our intuitive visual editor",
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Smart Segmentation",
      description: "Target the right audience with advanced segmentation tools",
    },
    {
      icon: <BarChart3 className="h-6 w-6" />,
      title: "Advanced Analytics",
      description: "Track opens, clicks, and conversions with detailed reports",
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Automation Workflows",
      description: "Set up automated email sequences to nurture leads",
    },
  ]

  const emailTemplates = [
    { id: 1, name: "Welcome Series", category: "Onboarding", opens: "45%", clicks: "12%" },
    { id: 2, name: "Product Launch", category: "Promotional", opens: "38%", clicks: "8%" },
    { id: 3, name: "Newsletter", category: "Content", opens: "42%", clicks: "15%" },
    { id: 4, name: "Abandoned Cart", category: "E-commerce", opens: "52%", clicks: "18%" },
    { id: 5, name: "Event Invitation", category: "Events", opens: "48%", clicks: "22%" },
    { id: 6, name: "Survey Request", category: "Feedback", opens: "35%", clicks: "25%" },
  ]

  const subscribers = [
    {
      id: 1,
      email: "john@example.com",
      name: "John Doe",
      status: "Active",
      joined: "2024-01-15",
      tags: ["Customer", "VIP"],
    },
    { id: 2, email: "jane@example.com", name: "Jane Smith", status: "Active", joined: "2024-01-20", tags: ["Lead"] },
    {
      id: 3,
      email: "bob@example.com",
      name: "Bob Johnson",
      status: "Unsubscribed",
      joined: "2024-01-10",
      tags: ["Customer"],
    },
    {
      id: 4,
      email: "alice@example.com",
      name: "Alice Brown",
      status: "Active",
      joined: "2024-01-25",
      tags: ["Lead", "Newsletter"],
    },
  ]

  const automationWorkflows = [
    {
      id: 1,
      name: "Welcome Series",
      trigger: "New Subscriber",
      emails: 3,
      status: "Active",
      subscribers: 1250,
      openRate: "45%",
    },
    {
      id: 2,
      name: "Abandoned Cart Recovery",
      trigger: "Cart Abandonment",
      emails: 2,
      status: "Active",
      subscribers: 890,
      openRate: "52%",
    },
    {
      id: 3,
      name: "Re-engagement Campaign",
      trigger: "Inactive for 30 days",
      emails: 4,
      status: "Paused",
      subscribers: 450,
      openRate: "28%",
    },
  ]

  const analyticsData = {
    totalSent: 15420,
    delivered: 14890,
    opened: 6250,
    clicked: 1890,
    unsubscribed: 45,
    bounced: 530,
  }

  const pricingPlans = [
    {
      name: "Starter",
      price: "₹999",
      description: "Perfect for small businesses",
      features: ["Up to 1,000 subscribers", "5,000 emails per month", "Basic templates", "Email support"],
    },
    {
      name: "Professional",
      price: "₹1999",
      description: "Most popular choice",
      features: [
        "Up to 10,000 subscribers",
        "50,000 emails per month",
        "Advanced templates",
        "Automation workflows",
        "A/B testing",
        "Priority support",
      ],
      popular: true,
    },
    {
      name: "Enterprise",
      price: "₹3999",
      description: "For growing businesses",
      features: [
        "Unlimited subscribers",
        "Unlimited emails",
        "Custom templates",
        "Advanced automation",
        "Advanced analytics",
        "Dedicated support",
        "API access",
      ],
    },
  ]

  const filteredTemplates = emailTemplates.filter(
    (template) =>
      (selectedCategory === "all" || template.category.toLowerCase() === selectedCategory) &&
      template.name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-200">
            <Sparkles className="h-4 w-4 mr-1" />
            Email Marketing Platform
          </Badge>
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
            Grow Your Business with Email Marketing
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Create, send, and track email campaigns that convert. Build stronger relationships with your customers
            through personalized email marketing.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              Start Free Trial
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <Button size="lg" variant="outline">
              Watch Demo
            </Button>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Powerful Email Marketing Features</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Everything you need to create, send, and optimize your email campaigns
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="bg-blue-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600 text-sm">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Interactive Dashboard */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Complete Email Marketing Dashboard</h2>
            <p className="text-gray-600">Manage all aspects of your email marketing from one place</p>
          </div>

          <Tabs defaultValue="campaigns" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
              <TabsTrigger value="subscribers">Subscribers</TabsTrigger>
              <TabsTrigger value="automation">Automation</TabsTrigger>
              <TabsTrigger value="analytics">Analytics</TabsTrigger>
            </TabsList>

            <TabsContent value="campaigns" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Email Templates</CardTitle>
                      <CardDescription>Choose from our library of high-converting templates</CardDescription>
                    </div>
                    <Button>Create New Campaign</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-6">
                    <div className="flex-1">
                      <Input
                        placeholder="Search templates..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="w-full"
                      />
                    </div>
                    <select
                      className="px-3 py-2 border rounded-md"
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                    >
                      <option value="all">All Categories</option>
                      <option value="onboarding">Onboarding</option>
                      <option value="promotional">Promotional</option>
                      <option value="content">Content</option>
                      <option value="e-commerce">E-commerce</option>
                      <option value="events">Events</option>
                      <option value="feedback">Feedback</option>
                    </select>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredTemplates.map((template) => (
                      <Card key={template.id} className="hover:shadow-md transition-shadow cursor-pointer">
                        <CardContent className="p-4">
                          <div className="aspect-video bg-gradient-to-br from-blue-100 to-indigo-100 rounded-lg mb-3 flex items-center justify-center">
                            <Mail className="h-8 w-8 text-blue-600" />
                          </div>
                          <h3 className="font-medium mb-1">{template.name}</h3>
                          <p className="text-sm text-gray-500 mb-2">{template.category}</p>
                          <div className="flex justify-between text-xs text-gray-600">
                            <span>Opens: {template.opens}</span>
                            <span>Clicks: {template.clicks}</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="subscribers" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Subscriber Management</CardTitle>
                      <CardDescription>Manage your email subscribers and segments</CardDescription>
                    </div>
                    <Button>Import Subscribers</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-4 mb-6">
                    <Input placeholder="Search subscribers..." className="flex-1" />
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Filter
                    </Button>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left p-2">Email</th>
                          <th className="text-left p-2">Name</th>
                          <th className="text-left p-2">Status</th>
                          <th className="text-left p-2">Joined</th>
                          <th className="text-left p-2">Tags</th>
                        </tr>
                      </thead>
                      <tbody>
                        {subscribers.map((subscriber) => (
                          <tr key={subscriber.id} className="border-b hover:bg-gray-50">
                            <td className="p-2">{subscriber.email}</td>
                            <td className="p-2">{subscriber.name}</td>
                            <td className="p-2">
                              <Badge variant={subscriber.status === "Active" ? "default" : "secondary"}>
                                {subscriber.status}
                              </Badge>
                            </td>
                            <td className="p-2">{subscriber.joined}</td>
                            <td className="p-2">
                              <div className="flex gap-1">
                                {subscriber.tags.map((tag, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="automation" className="space-y-6">
              <Card>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <div>
                      <CardTitle>Email Automation</CardTitle>
                      <CardDescription>Set up automated email workflows</CardDescription>
                    </div>
                    <Button>Create Workflow</Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {automationWorkflows.map((workflow) => (
                      <Card key={workflow.id}>
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h3 className="font-medium">{workflow.name}</h3>
                                <Badge variant={workflow.status === "Active" ? "default" : "secondary"}>
                                  {workflow.status}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-2">Trigger: {workflow.trigger}</p>
                              <div className="flex gap-4 text-sm text-gray-500">
                                <span>{workflow.emails} emails</span>
                                <span>{workflow.subscribers} subscribers</span>
                                <span>Open rate: {workflow.openRate}</span>
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm">
                                Edit
                              </Button>
                              <Button variant="outline" size="sm">
                                {workflow.status === "Active" ? "Pause" : "Activate"}
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="analytics" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Total Sent</p>
                        <p className="text-2xl font-bold">{analyticsData.totalSent.toLocaleString()}</p>
                      </div>
                      <Mail className="h-8 w-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Delivered</p>
                        <p className="text-2xl font-bold">{analyticsData.delivered.toLocaleString()}</p>
                        <p className="text-sm text-green-600">
                          {((analyticsData.delivered / analyticsData.totalSent) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <CheckCircle className="h-8 w-8 text-green-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Opened</p>
                        <p className="text-2xl font-bold">{analyticsData.opened.toLocaleString()}</p>
                        <p className="text-sm text-blue-600">
                          {((analyticsData.opened / analyticsData.delivered) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <TrendingUp className="h-8 w-8 text-blue-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Clicked</p>
                        <p className="text-2xl font-bold">{analyticsData.clicked.toLocaleString()}</p>
                        <p className="text-sm text-purple-600">
                          {((analyticsData.clicked / analyticsData.opened) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <Target className="h-8 w-8 text-purple-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Unsubscribed</p>
                        <p className="text-2xl font-bold">{analyticsData.unsubscribed}</p>
                        <p className="text-sm text-red-600">
                          {((analyticsData.unsubscribed / analyticsData.delivered) * 100).toFixed(2)}%
                        </p>
                      </div>
                      <Users className="h-8 w-8 text-red-600" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm text-gray-600">Bounced</p>
                        <p className="text-2xl font-bold">{analyticsData.bounced}</p>
                        <p className="text-sm text-orange-600">
                          {((analyticsData.bounced / analyticsData.totalSent) * 100).toFixed(1)}%
                        </p>
                      </div>
                      <BarChart3 className="h-8 w-8 text-orange-600" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Choose Your Plan</h2>
            <p className="text-gray-600">Affordable pricing for businesses of all sizes</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <Card key={index} className={`relative ${plan.popular ? "border-blue-500 shadow-lg" : ""}`}>
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="text-3xl font-bold text-blue-600">{plan.price}</div>
                  <CardDescription>{plan.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full ${plan.popular ? "bg-blue-600 hover:bg-blue-700" : ""}`}
                    variant={plan.popular ? "default" : "outline"}
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Boost Your Email Marketing?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of businesses growing their revenue with our email marketing platform
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/email-marketing">
                Start Free Trial
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-blue-600 bg-transparent"
            >
              Schedule Demo
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
