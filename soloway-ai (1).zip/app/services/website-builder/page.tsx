import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { EnhancedButton } from "@/components/enhanced-button"
import { ThemeToggle } from "@/components/theme-toggle"
import { ArrowLeft, Globe, Smartphone, Monitor, Palette, Code, Zap, CheckCircle, ArrowRight, Play } from "lucide-react"
import Link from "next/link"

export default function WebsiteBuilderServicePage() {
  const features = [
    {
      title: "Drag & Drop Editor",
      description: "Intuitive visual editor that requires no coding knowledge",
      icon: Globe,
    },
    {
      title: "Mobile Responsive",
      description: "All websites automatically adapt to any screen size",
      icon: Smartphone,
    },
    {
      title: "Professional Templates",
      description: "Choose from hundreds of industry-specific templates",
      icon: Monitor,
    },
    {
      title: "Custom Styling",
      description: "Full control over colors, fonts, and layout",
      icon: Palette,
    },
    {
      title: "SEO Optimized",
      description: "Built-in SEO tools to help you rank higher",
      icon: Zap,
    },
    {
      title: "Custom Code",
      description: "Add custom HTML, CSS, and JavaScript when needed",
      icon: Code,
    },
  ]

  const plans = [
    {
      name: "Free",
      price: "$0",
      period: "/month",
      features: ["3 Pages", "SoloWay Subdomain", "Basic Templates", "Mobile Responsive"],
      cta: "Start Free",
      popular: false,
    },
    {
      name: "Pro",
      price: "$9.99",
      period: "/month",
      features: ["Unlimited Pages", "Custom Domain", "Premium Templates", "Advanced Editor", "Priority Support"],
      cta: "Start Pro Trial",
      popular: true,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <EnhancedButton variant="ghost" size="sm" asChild animation="slide">
              <Link href="/services">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Services
              </Link>
            </EnhancedButton>
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-gradient-to-r from-purple-600 to-blue-600 rounded flex items-center justify-center">
                <Globe className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold">Website Builder</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <EnhancedButton
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              animation="glow"
              asChild
            >
              <Link href="/builder">Try Builder</Link>
            </EnhancedButton>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-200">
            🎨 No Code Required
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Build Professional Websites in Minutes</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Create stunning, responsive websites with our intuitive drag-and-drop builder. No coding skills required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <EnhancedButton
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              animation="glow"
              asChild
            >
              <Link href="/builder">
                Start Building Now
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </EnhancedButton>
            <EnhancedButton size="lg" variant="outline" animation="bounce">
              <Play className="w-4 h-4 mr-2" />
              Watch Demo
            </EnhancedButton>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => {
            const IconComponent = feature.icon
            return (
              <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-lg flex items-center justify-center mb-4">
                    <IconComponent className="w-6 h-6 text-purple-600 dark:text-purple-400" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
              </Card>
            )
          })}
        </div>

        {/* Pricing Section */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Choose Your Plan</h2>
            <p className="text-xl text-muted-foreground">Start free and upgrade as you grow</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {plans.map((plan, index) => (
              <Card key={index} className={`relative ${plan.popular ? "border-purple-500 shadow-lg" : ""}`}>
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-500">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="text-4xl font-bold mt-4">
                    {plan.price}
                    <span className="text-lg font-normal text-muted-foreground">{plan.period}</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <EnhancedButton
                    className={`w-full ${plan.popular ? "bg-purple-600 hover:bg-purple-700" : ""}`}
                    variant={plan.popular ? "default" : "outline"}
                    animation="glow"
                    asChild
                  >
                    <Link href="/auth/signup">{plan.cta}</Link>
                  </EnhancedButton>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 border-purple-200 dark:border-purple-800">
          <CardContent className="p-12 text-center">
            <h3 className="text-3xl font-bold mb-4">Ready to Build Your Website?</h3>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto text-lg">
              Join thousands of entrepreneurs who have already built their online presence with SoloWay AI.
            </p>
            <EnhancedButton
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              animation="glow"
              asChild
            >
              <Link href="/builder">Start Building Today</Link>
            </EnhancedButton>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
