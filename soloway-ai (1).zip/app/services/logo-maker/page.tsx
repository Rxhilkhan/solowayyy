"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Palette, Zap, Download, Star, CheckCircle, ArrowRight, Sparkles } from "lucide-react"
import Link from "next/link"

export default function LogoMakerPage() {
  const [businessName, setBusinessName] = useState("")
  const [industry, setIndustry] = useState("")
  const [selectedStyle, setSelectedStyle] = useState("")

  const logoStyles = [
    { id: "modern", name: "Modern", description: "Clean and contemporary designs" },
    { id: "vintage", name: "Vintage", description: "Classic and timeless appeal" },
    { id: "minimalist", name: "Minimalist", description: "Simple and elegant" },
    { id: "bold", name: "Bold", description: "Strong and impactful" },
    { id: "playful", name: "Playful", description: "Fun and creative" },
    { id: "professional", name: "Professional", description: "Corporate and trustworthy" },
  ]

  const logoTemplates = [
    { id: 1, name: "Tech Startup", category: "Technology", preview: "/placeholder.svg?height=100&width=100" },
    { id: 2, name: "Restaurant", category: "Food & Beverage", preview: "/placeholder.svg?height=100&width=100" },
    { id: 3, name: "Fashion Brand", category: "Fashion", preview: "/placeholder.svg?height=100&width=100" },
    { id: 4, name: "Fitness Gym", category: "Health & Fitness", preview: "/placeholder.svg?height=100&width=100" },
    { id: 5, name: "Real Estate", category: "Real Estate", preview: "/placeholder.svg?height=100&width=100" },
    { id: 6, name: "Creative Agency", category: "Creative", preview: "/placeholder.svg?height=100&width=100" },
    { id: 7, name: "Medical Clinic", category: "Healthcare", preview: "/placeholder.svg?height=100&width=100" },
    { id: 8, name: "Law Firm", category: "Legal", preview: "/placeholder.svg?height=100&width=100" },
  ]

  const features = [
    {
      icon: <Palette className="h-6 w-6" />,
      title: "AI-Powered Design",
      description: "Our AI creates unique logos based on your business name and industry",
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Instant Generation",
      description: "Get hundreds of logo options in seconds, not days",
    },
    {
      icon: <Download className="h-6 w-6" />,
      title: "High-Quality Files",
      description: "Download in PNG, SVG, and PDF formats for any use case",
    },
  ]

  const pricingPlans = [
    {
      name: "Basic",
      price: "₹499",
      description: "Perfect for small businesses",
      features: ["5 Logo concepts", "PNG & JPG formats", "Basic customization", "Email support"],
    },
    {
      name: "Professional",
      price: "₹999",
      description: "Most popular choice",
      features: [
        "20 Logo concepts",
        "All file formats (PNG, SVG, PDF)",
        "Advanced customization",
        "Color variations",
        "Priority support",
        "Brand guidelines",
      ],
      popular: true,
    },
    {
      name: "Enterprise",
      price: "₹1999",
      description: "For growing businesses",
      features: [
        "Unlimited logo concepts",
        "All file formats",
        "Full customization",
        "Multiple color schemes",
        "24/7 support",
        "Brand guidelines",
        "Social media kit",
        "Business card templates",
      ],
    },
  ]

  const testimonials = [
    {
      name: "Priya Sharma",
      business: "Sharma Boutique",
      rating: 5,
      comment: "Amazing logo designs! Got exactly what I wanted for my fashion boutique.",
    },
    {
      name: "Rajesh Kumar",
      business: "TechStart Solutions",
      rating: 5,
      comment: "Professional quality logos at affordable prices. Highly recommended!",
    },
    {
      name: "Anita Patel",
      business: "Patel Restaurant",
      rating: 5,
      comment: "The AI understood my restaurant concept perfectly. Great service!",
    },
  ]

  const handleGenerateLogos = () => {
    if (!businessName || !industry) {
      alert("Please fill in your business name and industry")
      return
    }
    // Redirect to logo generator with parameters
    window.location.href = `/logo-maker?name=${encodeURIComponent(businessName)}&industry=${encodeURIComponent(industry)}&style=${selectedStyle}`
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <Badge className="mb-4 bg-purple-100 text-purple-800 hover:bg-purple-200">
            <Sparkles className="h-4 w-4 mr-1" />
            AI-Powered Logo Design
          </Badge>
          <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
            Create Professional Logos in Minutes
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Design stunning logos for your business with our AI-powered logo maker. Get professional results instantly,
            no design experience required.
          </p>

          {/* Logo Generator Form */}
          <Card className="max-w-2xl mx-auto mb-12">
            <CardHeader>
              <CardTitle>Start Creating Your Logo</CardTitle>
              <CardDescription>Tell us about your business and we'll generate perfect logos for you</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="businessName">Business Name</Label>
                  <Input
                    id="businessName"
                    placeholder="Enter your business name"
                    value={businessName}
                    onChange={(e) => setBusinessName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="industry">Industry</Label>
                  <Select value={industry} onValueChange={setIndustry}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your industry" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="technology">Technology</SelectItem>
                      <SelectItem value="food-beverage">Food & Beverage</SelectItem>
                      <SelectItem value="fashion">Fashion</SelectItem>
                      <SelectItem value="health-fitness">Health & Fitness</SelectItem>
                      <SelectItem value="real-estate">Real Estate</SelectItem>
                      <SelectItem value="creative">Creative</SelectItem>
                      <SelectItem value="healthcare">Healthcare</SelectItem>
                      <SelectItem value="legal">Legal</SelectItem>
                      <SelectItem value="education">Education</SelectItem>
                      <SelectItem value="finance">Finance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Logo Style (Optional)</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {logoStyles.map((style) => (
                    <Button
                      key={style.id}
                      variant={selectedStyle === style.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedStyle(selectedStyle === style.id ? "" : style.id)}
                      className="h-auto p-3 flex flex-col items-center"
                    >
                      <span className="font-medium">{style.name}</span>
                      <span className="text-xs text-muted-foreground">{style.description}</span>
                    </Button>
                  ))}
                </div>
              </div>

              <Button
                onClick={handleGenerateLogos}
                size="lg"
                className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                Generate My Logos
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Why Choose Our Logo Maker?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Create professional logos with cutting-edge AI technology and intuitive design tools
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="pt-6">
                  <div className="bg-purple-100 w-12 h-12 rounded-full flex items-center justify-center mx-auto mb-4">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Logo Templates Gallery */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Professional Logo Templates</h2>
            <p className="text-gray-600">Browse our collection of industry-specific logo designs</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {logoTemplates.map((template) => (
              <Card key={template.id} className="hover:shadow-lg transition-shadow cursor-pointer">
                <CardContent className="p-4">
                  <div className="aspect-square bg-gradient-to-br from-purple-100 to-blue-100 rounded-lg mb-3 flex items-center justify-center">
                    <img
                      src={template.preview || "/placeholder.svg"}
                      alt={template.name}
                      className="w-16 h-16 object-contain"
                    />
                  </div>
                  <h3 className="font-medium text-sm">{template.name}</h3>
                  <p className="text-xs text-gray-500">{template.category}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Choose Your Plan</h2>
            <p className="text-gray-600">Affordable pricing for businesses of all sizes</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {pricingPlans.map((plan, index) => (
              <Card key={index} className={`relative ${plan.popular ? "border-purple-500 shadow-lg" : ""}`}>
                {plan.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-600">
                    Most Popular
                  </Badge>
                )}
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <div className="text-3xl font-bold text-purple-600">{plan.price}</div>
                  <CardDescription>{plan.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 mb-6">
                    {plan.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <Button
                    className={`w-full ${plan.popular ? "bg-purple-600 hover:bg-purple-700" : ""}`}
                    variant={plan.popular ? "default" : "outline"}
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">What Our Customers Say</h2>
            <p className="text-gray-600">Join thousands of satisfied customers</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-4">"{testimonial.comment}"</p>
                  <div>
                    <p className="font-medium">{testimonial.name}</p>
                    <p className="text-sm text-gray-500">{testimonial.business}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Create Your Perfect Logo?</h2>
          <p className="text-xl mb-8 opacity-90">
            Join over 10,000+ businesses who trust SoloWay AI for their branding needs
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" variant="secondary" asChild>
              <Link href="/logo-maker">
                Start Creating Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-white border-white hover:bg-white hover:text-purple-600 bg-transparent"
            >
              View Examples
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
