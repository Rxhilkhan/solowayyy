"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import {
  Search,
  BarChart3,
  TrendingUp,
  Eye,
  Target,
  CheckCircle,
  AlertCircle,
  Download,
  Zap,
  Users,
} from "lucide-react"
import { AnimatedButton } from "@/components/animated-button"

const seoFeatures = [
  {
    icon: Search,
    title: "Keyword Research",
    description: "Find the best keywords for your content with search volume and difficulty scores",
    color: "bg-blue-100 text-blue-700",
  },
  {
    icon: BarChart3,
    title: "SEO Analysis",
    description: "Comprehensive analysis of your website's SEO performance and recommendations",
    color: "bg-green-100 text-green-700",
  },
  {
    icon: TrendingUp,
    title: "Rank Tracking",
    description: "Monitor your keyword rankings and track your progress over time",
    color: "bg-purple-100 text-purple-700",
  },
  {
    icon: Eye,
    title: "Competitor Analysis",
    description: "See what keywords your competitors rank for and find new opportunities",
    color: "bg-orange-100 text-orange-700",
  },
]

const keywordData = [
  { keyword: "website builder", volume: 49500, difficulty: 65, cpc: 3.45, trend: "up" },
  { keyword: "logo maker", volume: 33100, difficulty: 58, cpc: 2.89, trend: "up" },
  { keyword: "seo tools", volume: 27100, difficulty: 72, cpc: 4.12, trend: "stable" },
  { keyword: "email marketing", volume: 22200, difficulty: 69, cpc: 3.78, trend: "up" },
  { keyword: "business name generator", volume: 18100, difficulty: 45, cpc: 2.34, trend: "down" },
]

const seoIssues = [
  { type: "error", title: "Missing meta descriptions", count: 12, priority: "High" },
  { type: "warning", title: "Images without alt text", count: 8, priority: "Medium" },
  { type: "warning", title: "Slow loading pages", count: 5, priority: "High" },
  { type: "info", title: "Internal linking opportunities", count: 15, priority: "Low" },
]

export default function SEOToolsPage() {
  const [websiteUrl, setWebsiteUrl] = useState("")
  const [keyword, setKeyword] = useState("")
  const [isAnalyzing, setIsAnalyzing] = useState(false)

  const handleAnalyze = () => {
    setIsAnalyzing(true)
    // Simulate analysis
    setTimeout(() => setIsAnalyzing(false), 3000)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">SEO Tools</h1>
            <p className="text-xl text-gray-600 mb-8">
              Optimize your website for search engines and increase your visibility
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Features Overview */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {seoFeatures.map((feature, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className={`w-12 h-12 rounded-lg ${feature.color} flex items-center justify-center mb-4`}>
                  <feature.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600 text-sm">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="analysis" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="analysis">Website Analysis</TabsTrigger>
            <TabsTrigger value="keywords">Keyword Research</TabsTrigger>
            <TabsTrigger value="tracking">Rank Tracking</TabsTrigger>
            <TabsTrigger value="competitors">Competitors</TabsTrigger>
          </TabsList>

          <TabsContent value="analysis" className="mt-8">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Website SEO Analysis</CardTitle>
                    <CardDescription>Enter your website URL to get a comprehensive SEO audit</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex space-x-4 mb-6">
                      <Input
                        placeholder="https://your-website.com"
                        value={websiteUrl}
                        onChange={(e) => setWebsiteUrl(e.target.value)}
                        className="flex-1"
                      />
                      <AnimatedButton onClick={handleAnalyze} disabled={!websiteUrl || isAnalyzing} animation="bounce">
                        {isAnalyzing ? (
                          <>
                            <Zap className="w-4 h-4 mr-2 animate-spin" />
                            Analyzing...
                          </>
                        ) : (
                          <>
                            <Search className="w-4 h-4 mr-2" />
                            Analyze
                          </>
                        )}
                      </AnimatedButton>
                    </div>

                    {isAnalyzing && (
                      <div className="space-y-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-4 h-4 bg-blue-600 rounded-full animate-pulse"></div>
                          <span>Crawling website...</span>
                        </div>
                        <Progress value={33} />
                        <div className="flex items-center space-x-2">
                          <div className="w-4 h-4 bg-green-600 rounded-full animate-pulse"></div>
                          <span>Analyzing SEO factors...</span>
                        </div>
                        <Progress value={66} />
                        <div className="flex items-center space-x-2">
                          <div className="w-4 h-4 bg-purple-600 rounded-full animate-pulse"></div>
                          <span>Generating report...</span>
                        </div>
                        <Progress value={90} />
                      </div>
                    )}

                    {!isAnalyzing && websiteUrl && (
                      <div className="space-y-6">
                        {/* SEO Score */}
                        <div className="text-center p-6 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg">
                          <div className="text-4xl font-bold text-green-600 mb-2">78/100</div>
                          <p className="text-gray-600">Overall SEO Score</p>
                          <Badge className="mt-2 bg-green-100 text-green-700">Good</Badge>
                        </div>

                        {/* Issues */}
                        <div>
                          <h3 className="text-lg font-semibold mb-4">Issues Found</h3>
                          <div className="space-y-3">
                            {seoIssues.map((issue, index) => (
                              <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                                <div className="flex items-center space-x-3">
                                  {issue.type === "error" && <AlertCircle className="w-5 h-5 text-red-500" />}
                                  {issue.type === "warning" && <AlertCircle className="w-5 h-5 text-yellow-500" />}
                                  {issue.type === "info" && <CheckCircle className="w-5 h-5 text-blue-500" />}
                                  <div>
                                    <p className="font-medium">{issue.title}</p>
                                    <p className="text-sm text-gray-500">{issue.count} instances found</p>
                                  </div>
                                </div>
                                <Badge
                                  variant={
                                    issue.priority === "High"
                                      ? "destructive"
                                      : issue.priority === "Medium"
                                        ? "default"
                                        : "secondary"
                                  }
                                >
                                  {issue.priority}
                                </Badge>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Actions */}
                        <div className="flex space-x-4">
                          <AnimatedButton variant="outline" className="flex-1">
                            <Download className="w-4 h-4 mr-2" />
                            Download Report
                          </AnimatedButton>
                          <AnimatedButton className="flex-1">
                            <Target className="w-4 h-4 mr-2" />
                            Fix Issues
                          </AnimatedButton>
                        </div>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle>SEO Checklist</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-sm">Title tags optimized</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-sm">SSL certificate installed</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <AlertCircle className="w-5 h-5 text-yellow-500" />
                        <span className="text-sm">Meta descriptions missing</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <AlertCircle className="w-5 h-5 text-red-500" />
                        <span className="text-sm">Page speed needs improvement</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <CheckCircle className="w-5 h-5 text-green-500" />
                        <span className="text-sm">Mobile-friendly design</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Quick Stats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Pages crawled</span>
                        <span className="font-medium">247</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Load time</span>
                        <span className="font-medium">2.3s</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Mobile score</span>
                        <span className="font-medium">85/100</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-sm text-gray-600">Backlinks</span>
                        <span className="font-medium">1,234</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="keywords" className="mt-8">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Keyword Research</CardTitle>
                    <CardDescription>Find the best keywords for your content strategy</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex space-x-4 mb-6">
                      <Input
                        placeholder="Enter a keyword or topic"
                        value={keyword}
                        onChange={(e) => setKeyword(e.target.value)}
                        className="flex-1"
                      />
                      <AnimatedButton animation="bounce">
                        <Search className="w-4 h-4 mr-2" />
                        Research
                      </AnimatedButton>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">Keyword Suggestions</h3>
                        <Badge variant="outline">Top 5 Results</Badge>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full">
                          <thead>
                            <tr className="border-b">
                              <th className="text-left py-2">Keyword</th>
                              <th className="text-left py-2">Volume</th>
                              <th className="text-left py-2">Difficulty</th>
                              <th className="text-left py-2">CPC</th>
                              <th className="text-left py-2">Trend</th>
                            </tr>
                          </thead>
                          <tbody>
                            {keywordData.map((item, index) => (
                              <tr key={index} className="border-b hover:bg-gray-50">
                                <td className="py-3 font-medium">{item.keyword}</td>
                                <td className="py-3">{item.volume.toLocaleString()}</td>
                                <td className="py-3">
                                  <div className="flex items-center space-x-2">
                                    <div className="w-12 bg-gray-200 rounded-full h-2">
                                      <div
                                        className={`h-2 rounded-full ${
                                          item.difficulty < 50
                                            ? "bg-green-500"
                                            : item.difficulty < 70
                                              ? "bg-yellow-500"
                                              : "bg-red-500"
                                        }`}
                                        style={{ width: `${item.difficulty}%` }}
                                      />
                                    </div>
                                    <span className="text-sm">{item.difficulty}</span>
                                  </div>
                                </td>
                                <td className="py-3">${item.cpc}</td>
                                <td className="py-3">
                                  <TrendingUp
                                    className={`w-4 h-4 ${
                                      item.trend === "up"
                                        ? "text-green-500"
                                        : item.trend === "down"
                                          ? "text-red-500"
                                          : "text-gray-500"
                                    }`}
                                  />
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle>Keyword Metrics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">150K+</div>
                        <p className="text-sm text-gray-600">Total Search Volume</p>
                      </div>
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">58</div>
                        <p className="text-sm text-gray-600">Avg. Difficulty</p>
                      </div>
                      <div className="text-center p-4 bg-purple-50 rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">$3.12</div>
                        <p className="text-sm text-gray-600">Avg. CPC</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Related Topics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <Badge variant="outline">web design</Badge>
                      <Badge variant="outline">online business</Badge>
                      <Badge variant="outline">digital marketing</Badge>
                      <Badge variant="outline">e-commerce</Badge>
                      <Badge variant="outline">branding</Badge>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="tracking" className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Rank Tracking</CardTitle>
                <CardDescription>Monitor your keyword rankings over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Start Tracking Keywords</h3>
                  <p className="text-gray-600 mb-6">
                    Add keywords to track their ranking positions and monitor your SEO progress
                  </p>
                  <AnimatedButton>
                    <Target className="w-4 h-4 mr-2" />
                    Add Keywords to Track
                  </AnimatedButton>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="competitors" className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle>Competitor Analysis</CardTitle>
                <CardDescription>Analyze your competitors' SEO strategies and find opportunities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Analyze Competitors</h3>
                  <p className="text-gray-600 mb-6">
                    Enter competitor URLs to see their top keywords and SEO strategies
                  </p>
                  <div className="max-w-md mx-auto flex space-x-4">
                    <Input placeholder="competitor-website.com" />
                    <AnimatedButton>
                      <Search className="w-4 h-4 mr-2" />
                      Analyze
                    </AnimatedButton>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
