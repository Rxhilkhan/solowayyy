import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { EnhancedButton } from "@/components/enhanced-button"
import { ThemeToggle } from "@/components/theme-toggle"
import { ArrowLeft, Zap, Lightbulb, Target, Globe, CheckCircle, ArrowRight, Play, Sparkles } from "lucide-react"
import Link from "next/link"

export default function NameGeneratorServicePage() {
  const features = [
    {
      title: "AI-Powered Generation",
      description: "Advanced AI algorithms create unique, memorable business names",
      icon: Zap,
    },
    {
      title: "Industry-Specific",
      description: "Tailored suggestions based on your business type and niche",
      icon: Target,
    },
    {
      title: "Domain Availability",
      description: "Instant domain name checking for all suggestions",
      icon: Globe,
    },
    {
      title: "Creative Variations",
      description: "Multiple naming styles from modern to traditional",
      icon: Lightbulb,
    },
    {
      title: "Trademark Check",
      description: "Basic trademark screening to avoid conflicts",
      icon: CheckCircle,
    },
    {
      title: "Instant Results",
      description: "Get hundreds of name ideas in seconds",
      icon: Sparkles,
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <EnhancedButton variant="ghost" size="sm" asChild animation="slide">
              <Link href="/services">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Services
              </Link>
            </EnhancedButton>
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-gradient-to-r from-blue-600 to-cyan-600 rounded flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold">AI Name Generator</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <EnhancedButton
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
              animation="glow"
              asChild
            >
              <Link href="/name-generator">Try Generator</Link>
            </EnhancedButton>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-blue-100 text-blue-700 dark:bg-blue-900 dark:text-blue-200">
            ⚡ AI-Powered Naming
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Generate Perfect Business Names with AI</h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto mb-8">
            Let our advanced AI create unique, memorable business names tailored to your industry and vision.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <EnhancedButton
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
              animation="glow"
              asChild
            >
              <Link href="/name-generator">
                Generate Names Now
                <ArrowRight className="w-4 h-4 ml-2" />
              </Link>
            </EnhancedButton>
            <EnhancedButton size="lg" variant="outline" animation="bounce">
              <Play className="w-4 h-4 mr-2" />
              See Examples
            </EnhancedButton>
          </div>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {features.map((feature, index) => {
            const IconComponent = feature.icon
            return (
              <Card key={index} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                <CardHeader>
                  <div className="w-12 h-12 bg-gradient-to-r from-blue-100 to-cyan-100 dark:from-blue-900 dark:to-cyan-900 rounded-lg flex items-center justify-center mb-4">
                    <IconComponent className="w-6 h-6 text-blue-600 dark:text-blue-400" />
                  </div>
                  <CardTitle className="text-lg">{feature.title}</CardTitle>
                  <CardDescription>{feature.description}</CardDescription>
                </CardHeader>
              </Card>
            )
          })}
        </div>

        {/* How It Works */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">How It Works</h2>
            <p className="text-xl text-muted-foreground">Simple steps to find your perfect business name</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold">
                  1
                </div>
                <h3 className="text-xl font-semibold mb-2">Describe Your Business</h3>
                <p className="text-muted-foreground">Tell us about your industry, target audience, and key values</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold">
                  2
                </div>
                <h3 className="text-xl font-semibold mb-2">AI Generates Names</h3>
                <p className="text-muted-foreground">Our AI creates hundreds of unique name suggestions instantly</p>
              </CardContent>
            </Card>

            <Card className="text-center">
              <CardContent className="p-6">
                <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-4 text-white text-2xl font-bold">
                  3
                </div>
                <h3 className="text-xl font-semibold mb-2">Choose & Register</h3>
                <p className="text-muted-foreground">Pick your favorite and check domain availability instantly</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Example Names */}
        <div className="mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Example Generated Names</h2>
            <p className="text-xl text-muted-foreground">See the quality of names our AI creates</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { name: "TechFlow", industry: "Technology", available: true },
              { name: "CreativeHub", industry: "Design", available: true },
              { name: "GrowthLab", industry: "Marketing", available: false },
              { name: "SmartVenture", industry: "Consulting", available: true },
              { name: "DigitalCraft", industry: "Web Design", available: true },
              { name: "InnovatePro", industry: "Innovation", available: false },
              { name: "BrightPath", industry: "Education", available: true },
              { name: "NextGen Solutions", industry: "Technology", available: true },
            ].map((example, index) => (
              <Card key={index} className="hover:shadow-md transition-all duration-300">
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-1">{example.name}</h3>
                  <p className="text-sm text-muted-foreground mb-2">{example.industry}</p>
                  <Badge variant={example.available ? "default" : "secondary"} className="text-xs">
                    {example.available ? "Available" : "Taken"}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950 border-blue-200 dark:border-blue-800">
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-3xl font-bold mb-4">Ready to Find Your Perfect Name?</h3>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto text-lg">
              Join thousands of entrepreneurs who have found their perfect business name with our AI generator.
            </p>
            <EnhancedButton
              size="lg"
              className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700"
              animation="glow"
              asChild
            >
              <Link href="/name-generator">Start Generating Names</Link>
            </EnhancedButton>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
