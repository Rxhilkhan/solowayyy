import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { EnhancedButton } from "@/components/enhanced-button"
import { ThemeToggle } from "@/components/theme-toggle"
import { ArrowLeft, Globe, Palette, Search, Mail, Zap, BarChart3, ArrowRight, CheckCircle } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function ServicesPage() {
  const services = [
    {
      id: "website-builder",
      title: "Website Builder",
      description: "Create stunning websites with our drag-and-drop builder",
      icon: Globe,
      features: ["Drag & Drop Editor", "Mobile Responsive", "SEO Optimized", "Custom Domains"],
      color: "from-purple-500 to-blue-500",
      href: "/services/website-builder",
    },
    {
      id: "name-generator",
      title: "AI Name Generator",
      description: "Generate unique business names powered by AI",
      icon: Zap,
      features: ["AI Powered", "Industry Specific", "Domain Check", "Trademark Search"],
      color: "from-blue-500 to-cyan-500",
      href: "/services/name-generator",
    },
    {
      id: "logo-maker",
      title: "Logo Maker",
      description: "Design professional logos in minutes",
      icon: Palette,
      features: ["AI Design", "Vector Graphics", "Multiple Formats", "Brand Guidelines"],
      color: "from-green-500 to-emerald-500",
      href: "/services/logo-maker",
    },
    {
      id: "seo-tools",
      title: "SEO Tools",
      description: "Optimize your website for search engines",
      icon: Search,
      features: ["Keyword Research", "Site Analysis", "Meta Tags", "Performance Tracking"],
      color: "from-orange-500 to-red-500",
      href: "/services/seo-tools",
    },
    {
      id: "email-marketing",
      title: "Email Marketing",
      description: "Build and manage email campaigns",
      icon: Mail,
      features: ["Campaign Builder", "Automation", "Analytics", "Templates"],
      color: "from-pink-500 to-rose-500",
      href: "/services/email-marketing",
    },
    {
      id: "analytics",
      title: "Analytics",
      description: "Track your website performance",
      icon: BarChart3,
      features: ["Real-time Data", "Visitor Insights", "Conversion Tracking", "Custom Reports"],
      color: "from-indigo-500 to-purple-500",
      href: "/services/analytics",
    },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <EnhancedButton variant="ghost" size="sm" asChild animation="slide">
              <Link href="/">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Home
              </Link>
            </EnhancedButton>
            <div className="flex items-center space-x-2">
              <Image src="/logo-white.png" alt="SoloWay AI" width={24} height={24} className="dark:hidden" />
              <Image src="/logo-orange.png" alt="SoloWay AI" width={24} height={24} className="hidden dark:block" />
              <span className="font-semibold">Our Services</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <EnhancedButton
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              animation="glow"
              asChild
            >
              <Link href="/auth/signup">Get Started</Link>
            </EnhancedButton>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-purple-100 text-purple-700 dark:bg-purple-900 dark:text-purple-200">
            🚀 All-in-One Platform
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent dark:from-orange-500 dark:via-yellow-500 dark:to-orange-500">
            Everything You Need to Succeed Online
          </h1>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            From website creation to marketing automation, our comprehensive suite of AI-powered tools helps
            solopreneurs build and grow their online presence.
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {services.map((service, index) => {
            const IconComponent = service.icon
            return (
              <Card
                key={service.id}
                className="group hover:shadow-xl transition-all duration-300 hover:-translate-y-2 border-0 shadow-lg"
              >
                <CardHeader>
                  <div
                    className={`w-12 h-12 bg-gradient-to-r ${service.color} rounded-lg flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="group-hover:text-purple-600 dark:group-hover:text-orange-500 transition-colors">
                    {service.title}
                  </CardTitle>
                  <CardDescription>{service.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium mb-2">Key Features:</h4>
                      <div className="space-y-1">
                        {service.features.map((feature, featureIndex) => (
                          <div key={featureIndex} className="flex items-center text-sm text-muted-foreground">
                            <CheckCircle className="w-3 h-3 text-green-500 mr-2" />
                            {feature}
                          </div>
                        ))}
                      </div>
                    </div>
                    <EnhancedButton
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                      animation="glow"
                      asChild
                    >
                      <Link href={service.href}>
                        Explore {service.title}
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </Link>
                    </EnhancedButton>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 border-purple-200 dark:border-purple-800">
          <CardContent className="p-12 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-3xl font-bold mb-4">Ready to Get Started?</h3>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto text-lg">
              Join thousands of solopreneurs who are already using SoloWay AI to build their online empire.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <EnhancedButton
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                animation="glow"
                asChild
              >
                <Link href="/auth/signup">Start Free Trial</Link>
              </EnhancedButton>
              <EnhancedButton size="lg" variant="outline" animation="bounce" asChild>
                <Link href="/contact">Contact Sales</Link>
              </EnhancedButton>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
