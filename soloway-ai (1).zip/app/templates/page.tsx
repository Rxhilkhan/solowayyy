import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { AnimatedButton } from "@/components/animated-button"
import { ThemeToggle } from "@/components/theme-toggle"
import { ArrowLeft, Eye, Zap, Briefcase, User, ShoppingBag, Camera, Code, Heart } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function TemplatesPage() {
  const templates = [
    {
      id: 1,
      name: "Modern Portfolio",
      category: "Portfolio",
      description: "Perfect for freelancers and creative professionals",
      image: "/placeholder.svg?height=200&width=300",
      icon: User,
      features: ["Responsive Design", "Contact Form", "Gallery", "About Section"],
      popular: true,
    },
    {
      id: 2,
      name: "Business Landing",
      category: "Business",
      description: "Professional landing page for service businesses",
      image: "/placeholder.svg?height=200&width=300",
      icon: Briefcase,
      features: ["Hero Section", "Services", "Testimonials", "CTA"],
      popular: false,
    },
    {
      id: 3,
      name: "E-commerce Store",
      category: "E-commerce",
      description: "Complete online store with product catalog",
      image: "/placeholder.svg?height=200&width=300",
      icon: ShoppingBag,
      features: ["Product Grid", "Shopping Cart", "Checkout", "Inventory"],
      popular: true,
    },
    {
      id: 4,
      name: "Photography Studio",
      category: "Creative",
      description: "Showcase your photography work beautifully",
      image: "/placeholder.svg?height=200&width=300",
      icon: Camera,
      features: ["Image Gallery", "Lightbox", "Booking", "Pricing"],
      popular: false,
    },
    {
      id: 5,
      name: "Tech Startup",
      category: "Technology",
      description: "Modern design for tech companies and startups",
      image: "/placeholder.svg?height=200&width=300",
      icon: Code,
      features: ["Product Demo", "Team Section", "Pricing", "Blog"],
      popular: false,
    },
    {
      id: 6,
      name: "Restaurant Menu",
      category: "Food & Beverage",
      description: "Elegant menu display for restaurants and cafes",
      image: "/placeholder.svg?height=200&width=300",
      icon: Heart,
      features: ["Menu Display", "Reservations", "Location", "Reviews"],
      popular: true,
    },
  ]

  const categories = ["All", "Portfolio", "Business", "E-commerce", "Creative", "Technology", "Food & Beverage"]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <AnimatedButton variant="ghost" size="sm" asChild animation="slide">
              <Link href="/dashboard">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Link>
            </AnimatedButton>
            <div className="flex items-center space-x-2">
              <Image src="/logo-white.png" alt="SoloWay AI" width={24} height={24} className="dark:hidden" />
              <Image src="/logo-orange.png" alt="SoloWay AI" width={24} height={24} className="hidden dark:block" />
              <span className="font-semibold">Website Templates</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <AnimatedButton
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              animation="glow"
            >
              <Zap className="w-4 h-4 mr-2" />
              Create Custom
            </AnimatedButton>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-4">Choose Your Template</h1>
          <p className="text-xl text-muted-foreground">
            Start with a professionally designed template and customize it to match your brand
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          {categories.map((category) => (
            <AnimatedButton
              key={category}
              variant={category === "All" ? "default" : "outline"}
              size="sm"
              animation="bounce"
            >
              {category}
            </AnimatedButton>
          ))}
        </div>

        {/* Templates Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {templates.map((template) => {
            const IconComponent = template.icon
            return (
              <Card
                key={template.id}
                className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
              >
                {template.popular && (
                  <Badge className="absolute top-4 right-4 z-10 bg-gradient-to-r from-purple-600 to-blue-600">
                    Popular
                  </Badge>
                )}
                <div className="relative overflow-hidden rounded-t-lg">
                  <Image
                    src={template.image || "/placeholder.svg"}
                    alt={template.name}
                    width={300}
                    height={200}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                    <AnimatedButton variant="secondary" size="sm" animation="scale">
                      <Eye className="w-4 h-4 mr-2" />
                      Preview
                    </AnimatedButton>
                  </div>
                </div>
                <CardHeader>
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="w-8 h-8 bg-gradient-to-r from-purple-100 to-blue-100 dark:from-purple-900 dark:to-blue-900 rounded-lg flex items-center justify-center">
                      <IconComponent className="w-4 h-4 text-purple-600 dark:text-purple-400" />
                    </div>
                    <Badge variant="outline">{template.category}</Badge>
                  </div>
                  <CardTitle className="group-hover:text-purple-600 transition-colors">{template.name}</CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium mb-2">Features:</h4>
                      <div className="flex flex-wrap gap-1">
                        {template.features.map((feature, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <AnimatedButton variant="outline" className="flex-1" animation="bounce">
                        <Eye className="w-4 h-4 mr-2" />
                        Preview
                      </AnimatedButton>
                      <AnimatedButton
                        className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                        animation="glow"
                        asChild
                      >
                        <Link href={`/builder?template=${template.id}`}>Use Template</Link>
                      </AnimatedButton>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Custom Template CTA */}
        <Card className="mt-12 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950 border-purple-200 dark:border-purple-800">
          <CardContent className="p-8 text-center">
            <div className="w-16 h-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Zap className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-2xl font-bold mb-2">Need Something Custom?</h3>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
              Can't find the perfect template? Our AI can generate a custom design based on your specific requirements
              and industry.
            </p>
            <AnimatedButton
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              animation="glow"
            >
              <Zap className="w-5 h-5 mr-2" />
              Generate Custom Template
            </AnimatedButton>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
