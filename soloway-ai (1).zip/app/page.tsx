import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, Zap, Globe, Palette, Search, Mail, Star, ArrowRight } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { EnhancedButton } from "@/components/enhanced-button"
import Image from "next/image"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 dark:bg-gradient-to-br dark:from-gray-900 dark:via-gray-800 dark:to-gray-700">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50 dark:bg-gray-900/80 dark:border-gray-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Image src="/logo-white.png" alt="SoloWay AI" width={32} height={32} className="dark:hidden" />
            <Image src="/logo-orange.png" alt="SoloWay AI" width={32} height={32} className="hidden dark:block" />
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent dark:from-orange-500 dark:to-yellow-500">
              SoloWay AI
            </span>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              href="/services"
              className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100 transition-colors"
            >
              Services
            </Link>
            <Link
              href="#pricing"
              className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100 transition-colors"
            >
              Pricing
            </Link>
            <Link
              href="/trust"
              className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100 transition-colors"
            >
              Trust
            </Link>
            <Link
              href="/contact"
              className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100 transition-colors"
            >
              Contact
            </Link>
            <Link
              href="/auth/login"
              className="text-gray-600 hover:text-gray-900 dark:text-gray-300 dark:hover:text-gray-100 transition-colors"
            >
              Login
            </Link>
            <ThemeToggle />
            <EnhancedButton asChild animation="glow">
              <Link href="/auth/signup">Get Started Free</Link>
            </EnhancedButton>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center max-w-4xl">
          <Badge className="mb-4 bg-purple-100 text-purple-700 hover:bg-purple-100 dark:bg-purple-900 dark:text-purple-200 dark:hover:bg-purple-900">
            🚀 Launching January 1, 2025
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-600 via-blue-600 to-indigo-600 bg-clip-text text-transparent dark:from-orange-500 dark:via-yellow-500 dark:to-orange-500">
            Build Your Dream Website in Minutes
          </h1>
          <p className="text-xl text-gray-600 mb-8 leading-relaxed dark:text-gray-400">
            The all-in-one platform for solopreneurs. Create stunning websites, generate business names, design logos,
            optimize for SEO, and launch email campaigns - all powered by AI.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <EnhancedButton
              size="lg"
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 dark:from-orange-500 dark:to-yellow-500 dark:hover:from-orange-600 dark:hover:to-yellow-600"
              asChild
              animation="glow"
            >
              <Link href="/auth/signup">
                Start Building Free <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </EnhancedButton>
            <EnhancedButton size="lg" variant="outline" asChild animation="bounce">
              <Link href="/services">View Services</Link>
            </EnhancedButton>
          </div>
          <p className="text-sm text-gray-500 mt-4 dark:text-gray-400">
            No credit card required • Free forever plan available
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 px-4 bg-white dark:bg-gray-800">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 dark:text-white">Everything You Need to Succeed Online</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto dark:text-gray-400">
              From website creation to marketing automation, we've got all your business needs covered.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700 dark:hover:shadow-2xl">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4 dark:bg-purple-900">
                  <Globe className="w-6 h-6 text-purple-600 dark:text-purple-300" />
                </div>
                <CardTitle className="dark:text-white">Drag & Drop Website Builder</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Create professional websites with our intuitive drag-and-drop editor. No coding required.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700 dark:hover:shadow-2xl">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4 dark:bg-blue-900">
                  <Zap className="w-6 h-6 text-blue-600 dark:text-blue-300" />
                </div>
                <CardTitle className="dark:text-white">AI Name Generator</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Generate unique, memorable business names based on your industry and keywords.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700 dark:hover:shadow-2xl">
              <CardHeader>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4 dark:bg-green-900">
                  <Palette className="w-6 h-6 text-green-600 dark:text-green-300" />
                </div>
                <CardTitle className="dark:text-white">Logo Maker</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Design professional logos with AI assistance. Customize colors, fonts, and styles.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700 dark:hover:shadow-2xl">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4 dark:bg-orange-900">
                  <Search className="w-6 h-6 text-orange-600 dark:text-orange-300" />
                </div>
                <CardTitle className="dark:text-white">SEO Tools</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Optimize your website for search engines with keyword suggestions and meta tag generators.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700 dark:hover:shadow-2xl">
              <CardHeader>
                <div className="w-12 h-12 bg-pink-100 rounded-lg flex items-center justify-center mb-4 dark:bg-pink-900">
                  <Mail className="w-6 h-6 text-pink-600 dark:text-pink-300" />
                </div>
                <CardTitle className="dark:text-white">Email Marketing</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Build and send professional email campaigns to grow your customer base.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 dark:bg-gray-900 dark:border-gray-700 dark:hover:shadow-2xl">
              <CardHeader>
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4 dark:bg-indigo-900">
                  <Star className="w-6 h-6 text-indigo-600 dark:text-indigo-300" />
                </div>
                <CardTitle className="dark:text-white">AI Templates</CardTitle>
                <CardDescription className="dark:text-gray-400">
                  Choose from hundreds of AI-generated templates designed for different industries.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-20 px-4 bg-gray-50 dark:bg-gray-700">
        <div className="container mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4 dark:text-white">Simple, Transparent Pricing</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400">Start free, upgrade when you're ready to grow</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="border-2 border-gray-200 dark:bg-gray-800 dark:border-gray-700">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl dark:text-white">Free</CardTitle>
                <div className="text-4xl font-bold mt-4 dark:text-white">
                  $0<span className="text-lg font-normal text-gray-600 dark:text-gray-400">/month</span>
                </div>
                <CardDescription className="dark:text-gray-400">Perfect for getting started</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>3 Website templates</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>SoloWay subdomain</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Basic name generator</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Simple logo maker</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Basic SEO tools</span>
                  </li>
                </ul>
                <EnhancedButton className="w-full mt-6" variant="outline" asChild animation="bounce">
                  <Link href="/auth/signup">Get Started Free</Link>
                </EnhancedButton>
              </CardContent>
            </Card>

            <Card className="border-2 border-purple-500 relative dark:bg-gray-800 dark:border-purple-700">
              <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-purple-500 dark:bg-purple-700">
                Most Popular
              </Badge>
              <CardHeader className="text-center">
                <CardTitle className="text-2xl dark:text-white">Pro</CardTitle>
                <div className="text-4xl font-bold mt-4 dark:text-white">
                  $9.99<span className="text-lg font-normal text-gray-600 dark:text-gray-400">/month</span>
                </div>
                <CardDescription className="dark:text-gray-400">Everything you need to grow</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Unlimited templates</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Custom domain</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Advanced AI tools</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Premium logo designs</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Advanced SEO & Analytics</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Email marketing campaigns</span>
                  </li>
                  <li className="flex items-center dark:text-gray-300">
                    <Check className="w-5 h-5 text-green-500 mr-3" />
                    <span>Priority support</span>
                  </li>
                </ul>
                <EnhancedButton
                  className="w-full mt-6 bg-purple-600 hover:bg-purple-700 dark:bg-purple-700 dark:hover:bg-purple-800"
                  asChild
                  animation="glow"
                >
                  <Link href="/auth/signup?plan=pro">Start Pro Trial</Link>
                </EnhancedButton>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white dark:from-orange-500 dark:to-yellow-500">
        <div className="container mx-auto text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Build Your Online Empire?</h2>
          <p className="text-xl mb-8 opacity-90">Join thousands of solopreneurs who've already started their journey</p>
          <EnhancedButton
            size="lg"
            className="bg-white text-purple-600 hover:bg-gray-100 dark:text-gray-900 dark:hover:bg-gray-200"
            asChild
            animation="glow"
          >
            <Link href="/auth/signup">
              Get Started Today <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </EnhancedButton>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">SoloWay AI</span>
              </div>
              <p className="text-gray-400">
                Empowering solopreneurs to build their online presence with AI-powered tools.
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Product</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/services" className="hover:text-white transition-colors">
                    Services
                  </Link>
                </li>
                <li>
                  <Link href="/pricing" className="hover:text-white transition-colors">
                    Pricing
                  </Link>
                </li>
                <li>
                  <Link href="/templates" className="hover:text-white transition-colors">
                    Templates
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Support</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/contact" className="hover:text-white transition-colors">
                    Contact
                  </Link>
                </li>
                <li>
                  <Link href="/trust" className="hover:text-white transition-colors">
                    Trust & Security
                  </Link>
                </li>
                <li>
                  <Link href="/help" className="hover:text-white transition-colors">
                    Help Center
                  </Link>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-4">Company</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about" className="hover:text-white transition-colors">
                    About
                  </Link>
                </li>
                <li>
                  <Link href="/blog" className="hover:text-white transition-colors">
                    Blog
                  </Link>
                </li>
                <li>
                  <Link href="/careers" className="hover:text-white transition-colors">
                    Careers
                  </Link>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 SoloWay AI. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
