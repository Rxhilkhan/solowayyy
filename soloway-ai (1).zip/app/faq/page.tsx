"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { ChevronDown, Search, HelpCircle, MessageCircle, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function FAQPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [openItems, setOpenItems] = useState<number[]>([])

  const faqCategories = [
    {
      name: "Getting Started",
      icon: "🚀",
      questions: [
        {
          id: 1,
          question: "How do I create my first website?",
          answer:
            "To create your first website, sign up for an account, choose a template from our gallery, customize it with your content, and publish it. Our drag-and-drop builder makes it easy even for beginners.",
        },
        {
          id: 2,
          question: "What's included in the free plan?",
          answer:
            "The free plan includes 3 website templates, basic customization options, SoloWay subdomain hosting, and community support. You can upgrade anytime for more features.",
        },
        {
          id: 3,
          question: "How long does it take to build a website?",
          answer:
            "With our AI-powered tools, you can have a professional website ready in as little as 15 minutes. More complex sites with custom features may take a few hours.",
        },
      ],
    },
    {
      name: "Pricing & Plans",
      icon: "💰",
      questions: [
        {
          id: 4,
          question: "What payment methods do you accept?",
          answer:
            "We accept all major credit cards, debit cards, UPI, net banking, and digital wallets through our secure Razorpay integration.",
        },
        {
          id: 5,
          question: "Can I cancel my subscription anytime?",
          answer:
            "Yes, you can cancel your subscription at any time from your account settings. You'll continue to have access until the end of your billing period.",
        },
        {
          id: 6,
          question: "Do you offer refunds?",
          answer:
            "We offer a 30-day money-back guarantee for all paid plans. If you're not satisfied, contact our support team for a full refund.",
        },
      ],
    },
    {
      name: "Features & Tools",
      icon: "🛠️",
      questions: [
        {
          id: 7,
          question: "What AI tools are available?",
          answer:
            "We offer AI-powered website building, logo creation, business name generation, SEO optimization, and email marketing tools. All designed to help you build and grow your business online.",
        },
        {
          id: 8,
          question: "Can I use my own domain?",
          answer:
            "Yes, Pro and Enterprise plans include custom domain support. You can either register a new domain through us or connect your existing domain.",
        },
        {
          id: 9,
          question: "Is my website mobile-friendly?",
          answer:
            "All our templates are fully responsive and optimized for mobile devices. Your website will look great on phones, tablets, and desktops.",
        },
      ],
    },
    {
      name: "Technical Support",
      icon: "🔧",
      questions: [
        {
          id: 10,
          question: "How do I backup my website?",
          answer:
            "Your website is automatically backed up daily. Pro users can also create manual backups and restore previous versions from the dashboard.",
        },
        {
          id: 11,
          question: "What if my website goes down?",
          answer:
            "We guarantee 99.9% uptime. In the rare event of downtime, our team is notified immediately and works to resolve issues quickly. Pro users get priority support.",
        },
        {
          id: 12,
          question: "Can I export my website?",
          answer:
            "Yes, Enterprise users can export their website code. This gives you full ownership and the ability to host your site elsewhere if needed.",
        },
      ],
    },
    {
      name: "Account & Security",
      icon: "🔒",
      questions: [
        {
          id: 13,
          question: "How secure is my data?",
          answer:
            "We use enterprise-grade security with SSL encryption, regular security audits, and secure data centers. Your data is protected with industry-standard security measures.",
        },
        {
          id: 14,
          question: "Can I have multiple users on my account?",
          answer:
            "Pro and Enterprise plans support team collaboration. You can invite team members with different permission levels to help manage your website.",
        },
        {
          id: 15,
          question: "How do I reset my password?",
          answer:
            "Click 'Forgot Password' on the login page and enter your email. You'll receive a secure link to reset your password. Make sure to check your spam folder.",
        },
      ],
    },
  ]

  const allQuestions = faqCategories.flatMap((category) =>
    category.questions.map((q) => ({ ...q, category: category.name })),
  )

  const filteredQuestions = searchTerm
    ? allQuestions.filter(
        (q) =>
          q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
          q.answer.toLowerCase().includes(searchTerm.toLowerCase()),
      )
    : allQuestions

  const toggleItem = (id: number) => {
    setOpenItems((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]))
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Find answers to common questions about SoloWay AI. Can't find what you're looking for? Contact our support
            team.
          </p>

          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search FAQs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center">
            <CardContent className="p-6">
              <HelpCircle className="h-12 w-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">15+ FAQs</h3>
              <p className="text-gray-600 text-sm">Comprehensive answers to help you succeed</p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <MessageCircle className="h-12 w-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">24/7 Support</h3>
              <p className="text-gray-600 text-sm">Get help whenever you need it</p>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardContent className="p-6">
              <Mail className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">Quick Response</h3>
              <p className="text-gray-600 text-sm">Average response time under 2 hours</p>
            </CardContent>
          </Card>
        </div>

        {/* FAQ Content */}
        {searchTerm ? (
          /* Search Results */
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Search Results ({filteredQuestions.length})</h2>
            {filteredQuestions.map((question) => (
              <Card key={question.id}>
                <Collapsible open={openItems.includes(question.id)} onOpenChange={() => toggleItem(question.id)}>
                  <CollapsibleTrigger className="w-full">
                    <CardHeader className="text-left hover:bg-gray-50 transition-colors">
                      <div className="flex items-center justify-between">
                        <div>
                          <CardTitle className="text-lg">{question.question}</CardTitle>
                          <Badge variant="outline" className="mt-2">
                            {question.category}
                          </Badge>
                        </div>
                        <ChevronDown
                          className={`h-5 w-5 text-gray-500 transition-transform ${
                            openItems.includes(question.id) ? "rotate-180" : ""
                          }`}
                        />
                      </div>
                    </CardHeader>
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <CardContent className="pt-0">
                      <p className="text-gray-600 leading-relaxed">{question.answer}</p>
                    </CardContent>
                  </CollapsibleContent>
                </Collapsible>
              </Card>
            ))}
          </div>
        ) : (
          /* Categories */
          <div className="space-y-8">
            {faqCategories.map((category, categoryIndex) => (
              <div key={categoryIndex}>
                <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center gap-3">
                  <span className="text-3xl">{category.icon}</span>
                  {category.name}
                </h2>

                <div className="space-y-4">
                  {category.questions.map((question) => (
                    <Card key={question.id}>
                      <Collapsible open={openItems.includes(question.id)} onOpenChange={() => toggleItem(question.id)}>
                        <CollapsibleTrigger className="w-full">
                          <CardHeader className="text-left hover:bg-gray-50 transition-colors">
                            <div className="flex items-center justify-between">
                              <CardTitle className="text-lg">{question.question}</CardTitle>
                              <ChevronDown
                                className={`h-5 w-5 text-gray-500 transition-transform ${
                                  openItems.includes(question.id) ? "rotate-180" : ""
                                }`}
                              />
                            </div>
                          </CardHeader>
                        </CollapsibleTrigger>
                        <CollapsibleContent>
                          <CardContent className="pt-0">
                            <p className="text-gray-600 leading-relaxed">{question.answer}</p>
                          </CardContent>
                        </CollapsibleContent>
                      </Collapsible>
                    </Card>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Contact Support */}
        <Card className="mt-12 bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Still have questions?</h3>
            <p className="text-blue-100 mb-6">Our support team is here to help you succeed with SoloWay AI</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button variant="secondary" size="lg">
                <MessageCircle className="h-4 w-4 mr-2" />
                Live Chat
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="bg-transparent border-white text-white hover:bg-white hover:text-blue-600"
              >
                <Mail className="h-4 w-4 mr-2" />
                Email Support
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
