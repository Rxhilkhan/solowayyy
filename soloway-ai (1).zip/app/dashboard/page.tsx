import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Globe, Palette, Search, Mail, Plus, BarChart3, Users, Eye, Zap, Settings, Bell } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"
import { AnimatedButton } from "@/components/animated-button"

export default function DashboardPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Zap className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                SoloWay AI
              </span>
            </div>
            <Badge variant="secondary">Free Plan</Badge>
          </div>
          <div className="flex items-center space-x-4">
            <AnimatedButton variant="ghost" size="sm">
              <Bell className="w-4 h-4" />
            </AnimatedButton>
            <ThemeToggle />
            <AnimatedButton variant="ghost" size="sm">
              <Settings className="w-4 h-4" />
            </AnimatedButton>
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-purple-600">JD</span>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Welcome back, John!</h1>
          <p className="text-gray-600">Let's continue building your online presence</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Websites</p>
                  <p className="text-2xl font-bold">2</p>
                </div>
                <Globe className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Views</p>
                  <p className="text-2xl font-bold">1,234</p>
                </div>
                <Eye className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Email Subscribers</p>
                  <p className="text-2xl font-bold">89</p>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Conversion Rate</p>
                  <p className="text-2xl font-bold">3.2%</p>
                </div>
                <BarChart3 className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Get started with these essential tools</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <AnimatedButton className="h-20 flex-col space-y-2" variant="outline" asChild animation="bounce">
                    <Link href="/builder">
                      <Globe className="w-6 h-6" />
                      <span>Website Builder</span>
                    </Link>
                  </AnimatedButton>
                  <AnimatedButton className="h-20 flex-col space-y-2" variant="outline" asChild animation="bounce">
                    <Link href="/name-generator">
                      <Zap className="w-6 h-6" />
                      <span>Name Generator</span>
                    </Link>
                  </AnimatedButton>
                  <AnimatedButton className="h-20 flex-col space-y-2" variant="outline" asChild animation="bounce">
                    <Link href="/logo-maker">
                      <Palette className="w-6 h-6" />
                      <span>Logo Maker</span>
                    </Link>
                  </AnimatedButton>
                  <AnimatedButton className="h-20 flex-col space-y-2" variant="outline" asChild animation="bounce">
                    <Link href="/seo-tools">
                      <Search className="w-6 h-6" />
                      <span>SEO Tools</span>
                    </Link>
                  </AnimatedButton>
                </div>
              </CardContent>
            </Card>

            {/* Recent Websites */}
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Your Websites</CardTitle>
                  <CardDescription>Manage and edit your websites</CardDescription>
                </div>
                <AnimatedButton size="sm" asChild animation="bounce">
                  <Link href="/builder">
                    <Plus className="w-4 h-4 mr-2" />
                    New Website
                  </Link>
                </AnimatedButton>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-purple-400 to-pink-400 rounded-lg"></div>
                      <div>
                        <h3 className="font-medium">My Portfolio</h3>
                        <p className="text-sm text-gray-600">myportfolio.soloway.ai</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="secondary">Published</Badge>
                      <AnimatedButton size="sm" variant="outline" asChild animation="bounce">
                        <Link href="/builder/portfolio">Edit</Link>
                      </AnimatedButton>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-blue-400 to-green-400 rounded-lg"></div>
                      <div>
                        <h3 className="font-medium">Business Landing</h3>
                        <p className="text-sm text-gray-600">business.soloway.ai</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline">Draft</Badge>
                      <AnimatedButton size="sm" variant="outline" asChild animation="bounce">
                        <Link href="/builder/business">Edit</Link>
                      </AnimatedButton>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Upgrade Card */}
            <Card className="border-purple-200 bg-gradient-to-br from-purple-50 to-blue-50">
              <CardHeader>
                <CardTitle className="text-purple-700">Upgrade to Pro</CardTitle>
                <CardDescription>Unlock all features and remove limits</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Websites used</span>
                      <span>2/3</span>
                    </div>
                    <Progress value={66} className="h-2" />
                  </div>
                  <AnimatedButton className="w-full bg-purple-600 hover:bg-purple-700" asChild animation="glow">
                    <Link href="/pricing">Upgrade Now</Link>
                  </AnimatedButton>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm font-medium">Website published</p>
                      <p className="text-xs text-gray-600">My Portfolio went live</p>
                      <p className="text-xs text-gray-500">2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm font-medium">Logo created</p>
                      <p className="text-xs text-gray-600">New logo for Business Landing</p>
                      <p className="text-xs text-gray-500">1 day ago</p>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                    <div>
                      <p className="text-sm font-medium">Name generated</p>
                      <p className="text-xs text-gray-600">Created 5 business name ideas</p>
                      <p className="text-xs text-gray-500">2 days ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Email Marketing */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Mail className="w-5 h-5 mr-2" />
                  Email Marketing
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold">89</p>
                    <p className="text-sm text-gray-600">Total Subscribers</p>
                  </div>
                  <AnimatedButton className="w-full" variant="outline" asChild animation="bounce">
                    <Link href="/email-marketing">Create Campaign</Link>
                  </AnimatedButton>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
