"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, User, Search, ArrowRight, TrendingUp } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function BlogPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = [
    { id: "all", name: "All Posts", count: 24 },
    { id: "tutorials", name: "Tutorials", count: 8 },
    { id: "business", name: "Business Tips", count: 6 },
    { id: "ai", name: "AI & Technology", count: 5 },
    { id: "design", name: "Design", count: 3 },
    { id: "marketing", name: "Marketing", count: 2 },
  ]

  const blogPosts = [
    {
      id: 1,
      title: "How to Build a Professional Website in 2024",
      excerpt:
        "Learn the essential steps to create a stunning website that converts visitors into customers using modern tools and techniques.",
      category: "tutorials",
      author: "Priya Sharma",
      date: "2024-01-15",
      readTime: "8 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: true,
      tags: ["Website Building", "Tutorial", "Beginner"],
    },
    {
      id: 2,
      title: "AI-Powered Logo Design: The Future is Here",
      excerpt:
        "Discover how artificial intelligence is revolutionizing logo design and helping businesses create memorable brand identities.",
      category: "ai",
      author: "Rajesh Kumar",
      date: "2024-01-12",
      readTime: "6 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: true,
      tags: ["AI", "Logo Design", "Branding"],
    },
    {
      id: 3,
      title: "10 SEO Tips to Boost Your Website Traffic",
      excerpt:
        "Proven strategies to improve your search engine rankings and drive more organic traffic to your website.",
      category: "marketing",
      author: "Anita Patel",
      date: "2024-01-10",
      readTime: "12 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: false,
      tags: ["SEO", "Marketing", "Traffic"],
    },
    {
      id: 4,
      title: "Small Business Success Stories with SoloWay AI",
      excerpt:
        "Real stories from entrepreneurs who transformed their businesses using our AI-powered tools and platforms.",
      category: "business",
      author: "Vikram Singh",
      date: "2024-01-08",
      readTime: "10 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: false,
      tags: ["Success Stories", "Small Business", "Case Study"],
    },
    {
      id: 5,
      title: "Email Marketing Best Practices for 2024",
      excerpt:
        "Master the art of email marketing with these proven strategies that increase open rates and drive conversions.",
      category: "marketing",
      author: "Meera Gupta",
      date: "2024-01-05",
      readTime: "9 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: false,
      tags: ["Email Marketing", "Best Practices", "Conversion"],
    },
    {
      id: 6,
      title: "The Psychology of Color in Web Design",
      excerpt:
        "Understanding how colors affect user behavior and how to choose the perfect color scheme for your website.",
      category: "design",
      author: "Arjun Reddy",
      date: "2024-01-03",
      readTime: "7 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: false,
      tags: ["Color Psychology", "Web Design", "UX"],
    },
    {
      id: 7,
      title: "Building Your Personal Brand Online",
      excerpt:
        "Step-by-step guide to establishing a strong personal brand that attracts opportunities and builds trust.",
      category: "business",
      author: "Kavya Nair",
      date: "2024-01-01",
      readTime: "11 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: false,
      tags: ["Personal Branding", "Online Presence", "Career"],
    },
    {
      id: 8,
      title: "Mobile-First Design: Why It Matters",
      excerpt: "Learn why mobile-first design is crucial for modern websites and how to implement it effectively.",
      category: "design",
      author: "Rohit Sharma",
      date: "2023-12-28",
      readTime: "6 min read",
      image: "/placeholder.svg?height=200&width=400",
      featured: false,
      tags: ["Mobile Design", "Responsive", "UX"],
    },
  ]

  const filteredPosts = blogPosts.filter((post) => {
    const matchesSearch =
      post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      post.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))

    const matchesCategory = selectedCategory === "all" || post.category === selectedCategory

    return matchesSearch && matchesCategory
  })

  const featuredPosts = blogPosts.filter((post) => post.featured)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">SoloWay AI Blog</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Insights, tutorials, and tips to help you build and grow your business with AI-powered tools.
          </p>

          {/* Search */}
          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Categories */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              onClick={() => setSelectedCategory(category.id)}
              className="mb-2"
            >
              {category.name} ({category.count})
            </Button>
          ))}
        </div>

        {/* Featured Posts */}
        {!searchTerm && selectedCategory === "all" && (
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-gray-900 mb-8 flex items-center gap-2">
              <TrendingUp className="h-6 w-6 text-purple-600" />
              Featured Articles
            </h2>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {featuredPosts.map((post) => (
                <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video bg-gradient-to-br from-purple-100 to-pink-100">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={400}
                      height={200}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="secondary">{categories.find((c) => c.id === post.category)?.name}</Badge>
                      <Badge variant="outline">Featured</Badge>
                    </div>

                    <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">{post.title}</h3>

                    <p className="text-gray-600 mb-4 line-clamp-3">{post.excerpt}</p>

                    <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1">
                          <User className="h-4 w-4" />
                          {post.author}
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(post.date).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {post.readTime}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1 mb-4">
                      {post.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <Button asChild className="w-full">
                      <Link href={`/blog/${post.id}`}>
                        Read More
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* All Posts */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-8">
            {searchTerm ? `Search Results (${filteredPosts.length})` : "Latest Articles"}
          </h2>

          {filteredPosts.length === 0 ? (
            <Card className="text-center py-12">
              <CardContent>
                <Search className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No articles found</h3>
                <p className="text-gray-500">Try adjusting your search terms or browse different categories</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredPosts.map((post) => (
                <Card key={post.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                  <div className="aspect-video bg-gradient-to-br from-purple-100 to-pink-100">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={400}
                      height={200}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="secondary">{categories.find((c) => c.id === post.category)?.name}</Badge>
                      {post.featured && <Badge variant="outline">Featured</Badge>}
                    </div>

                    <h3 className="text-lg font-bold text-gray-900 mb-3 line-clamp-2">{post.title}</h3>

                    <p className="text-gray-600 mb-4 line-clamp-3 text-sm">{post.excerpt}</p>

                    <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                      <div className="flex items-center gap-1">
                        <User className="h-3 w-3" />
                        {post.author}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {post.readTime}
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1 mb-4">
                      {post.tags.slice(0, 2).map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {post.tags.length > 2 && (
                        <Badge variant="outline" className="text-xs">
                          +{post.tags.length - 2}
                        </Badge>
                      )}
                    </div>

                    <Button asChild className="w-full" size="sm">
                      <Link href={`/blog/${post.id}`}>
                        Read More
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </Link>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>

        {/* Newsletter Signup */}
        <Card className="mt-16 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Stay Updated</h3>
            <p className="text-purple-100 mb-6 max-w-2xl mx-auto">
              Get the latest articles, tutorials, and business tips delivered straight to your inbox. Join thousands of
              entrepreneurs growing their businesses with SoloWay AI.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <Input placeholder="Enter your email" className="bg-white text-gray-900 border-0" />
              <Button variant="secondary" size="lg">
                Subscribe
              </Button>
            </div>
            <p className="text-purple-200 text-sm mt-4">No spam, unsubscribe anytime</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
