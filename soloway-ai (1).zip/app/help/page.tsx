"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  MessageCircle,
  Mail,
  Phone,
  Clock,
  CheckCircle,
  AlertCircle,
  BookOpen,
  Video,
  Download,
  ExternalLink,
} from "lucide-react"

export default function HelpPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [ticketSubject, setTicketSubject] = useState("")
  const [ticketMessage, setTicketMessage] = useState("")

  const helpCategories = [
    {
      title: "Getting Started",
      icon: "🚀",
      articles: [
        { title: "How to create your first website", views: 1250, helpful: 95 },
        { title: "Understanding the dashboard", views: 890, helpful: 92 },
        { title: "Choosing the right template", views: 756, helpful: 88 },
      ],
    },
    {
      title: "Website Builder",
      icon: "🏗️",
      articles: [
        { title: "Using the drag-and-drop editor", views: 2100, helpful: 97 },
        { title: "Customizing colors and fonts", views: 1680, helpful: 94 },
        { title: "Adding images and media", views: 1420, helpful: 91 },
      ],
    },
    {
      title: "AI Tools",
      icon: "🤖",
      articles: [
        { title: "AI logo maker guide", views: 1890, helpful: 96 },
        { title: "Business name generator tips", views: 1340, helpful: 89 },
        { title: "SEO optimization with AI", views: 1120, helpful: 93 },
      ],
    },
    {
      title: "Billing & Plans",
      icon: "💳",
      articles: [
        { title: "Understanding pricing plans", views: 980, helpful: 87 },
        { title: "How to upgrade your account", views: 760, helpful: 91 },
        { title: "Refund and cancellation policy", views: 650, helpful: 85 },
      ],
    },
  ]

  const supportChannels = [
    {
      title: "Live Chat",
      description: "Get instant help from our support team",
      icon: MessageCircle,
      availability: "24/7",
      responseTime: "< 2 minutes",
      color: "bg-green-100 text-green-700",
    },
    {
      title: "Email Support",
      description: "Send us a detailed message",
      icon: Mail,
      availability: "24/7",
      responseTime: "< 4 hours",
      color: "bg-blue-100 text-blue-700",
    },
    {
      title: "Phone Support",
      description: "Speak directly with our experts",
      icon: Phone,
      availability: "Mon-Fri 9AM-6PM",
      responseTime: "Immediate",
      color: "bg-purple-100 text-purple-700",
    },
  ]

  const resources = [
    {
      title: "Video Tutorials",
      description: "Step-by-step video guides",
      icon: Video,
      count: "25+ videos",
      link: "/tutorials",
    },
    {
      title: "Documentation",
      description: "Comprehensive guides and references",
      icon: BookOpen,
      count: "50+ articles",
      link: "/docs",
    },
    {
      title: "Downloads",
      description: "Templates, assets, and tools",
      icon: Download,
      count: "100+ resources",
      link: "/downloads",
    },
  ]

  const handleSubmitTicket = () => {
    if (!ticketSubject || !ticketMessage) {
      alert("Please fill in all fields")
      return
    }
    alert("Support ticket submitted successfully! We'll get back to you within 4 hours.")
    setTicketSubject("")
    setTicketMessage("")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Help Center</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
            Find answers, get support, and learn how to make the most of SoloWay AI
          </p>

          {/* Search */}
          <div className="relative max-w-lg mx-auto">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              placeholder="Search for help articles..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-12 py-3 text-lg"
            />
          </div>
        </div>

        {/* Support Channels */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {supportChannels.map((channel, index) => (
            <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
              <CardContent className="p-6 text-center">
                <div
                  className={`w-16 h-16 rounded-full ${channel.color} flex items-center justify-center mx-auto mb-4`}
                >
                  <channel.icon className="h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold mb-2">{channel.title}</h3>
                <p className="text-gray-600 mb-4">{channel.description}</p>
                <div className="space-y-2">
                  <div className="flex items-center justify-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span>{channel.availability}</span>
                  </div>
                  <Badge variant="secondary">Response: {channel.responseTime}</Badge>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="articles" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="articles">Help Articles</TabsTrigger>
            <TabsTrigger value="contact">Contact Support</TabsTrigger>
            <TabsTrigger value="resources">Resources</TabsTrigger>
            <TabsTrigger value="status">System Status</TabsTrigger>
          </TabsList>

          {/* Help Articles */}
          <TabsContent value="articles" className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {helpCategories.map((category, index) => (
                <Card key={index}>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-3">
                      <span className="text-2xl">{category.icon}</span>
                      {category.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {category.articles.map((article, articleIndex) => (
                        <div
                          key={articleIndex}
                          className="flex items-center justify-between p-3 hover:bg-gray-50 rounded-lg cursor-pointer"
                        >
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-900">{article.title}</h4>
                            <div className="flex items-center gap-4 text-sm text-gray-500 mt-1">
                              <span>{article.views} views</span>
                              <span className="flex items-center gap-1">
                                <CheckCircle className="h-3 w-3 text-green-500" />
                                {article.helpful}% helpful
                              </span>
                            </div>
                          </div>
                          <ExternalLink className="h-4 w-4 text-gray-400" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Contact Support */}
          <TabsContent value="contact" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Submit a Support Ticket</CardTitle>
                  <CardDescription>Describe your issue and we'll get back to you as soon as possible</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label htmlFor="subject" className="text-sm font-medium">
                      Subject
                    </label>
                    <Input
                      id="subject"
                      placeholder="Brief description of your issue"
                      value={ticketSubject}
                      onChange={(e) => setTicketSubject(e.target.value)}
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="message" className="text-sm font-medium">
                      Message
                    </label>
                    <Textarea
                      id="message"
                      placeholder="Please provide as much detail as possible..."
                      value={ticketMessage}
                      onChange={(e) => setTicketMessage(e.target.value)}
                      rows={6}
                    />
                  </div>

                  <Button onClick={handleSubmitTicket} className="w-full">
                    Submit Ticket
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Contact</CardTitle>
                  <CardDescription>Choose the best way to reach our support team</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4">
                    <Button className="w-full justify-start bg-transparent" variant="outline">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Start Live Chat
                    </Button>

                    <Button className="w-full justify-start bg-transparent" variant="outline">
                      <Mail className="h-4 w-4 mr-2" />
                      Send Email
                    </Button>

                    <Button className="w-full justify-start bg-transparent" variant="outline">
                      <Phone className="h-4 w-4 mr-2" />
                      Schedule Call
                    </Button>
                  </div>

                  <div className="mt-6 p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900 mb-2">Pro Tip</h4>
                    <p className="text-sm text-blue-700">
                      Include your account email and a detailed description of the issue for faster resolution.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Resources */}
          <TabsContent value="resources" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {resources.map((resource, index) => (
                <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <resource.icon className="h-8 w-8 text-gray-600" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{resource.title}</h3>
                    <p className="text-gray-600 mb-4">{resource.description}</p>
                    <Badge variant="outline" className="mb-4">
                      {resource.count}
                    </Badge>
                    <Button asChild className="w-full">
                      <a href={resource.link}>
                        Explore
                        <ExternalLink className="h-4 w-4 ml-2" />
                      </a>
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Community Forum</CardTitle>
                <CardDescription>Connect with other users, share tips, and get help from the community</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600 mb-2">
                      Join thousands of entrepreneurs sharing knowledge and experiences
                    </p>
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <span>5,000+ members</span>
                      <span>1,200+ discussions</span>
                      <span>Active community</span>
                    </div>
                  </div>
                  <Button>
                    Join Forum
                    <ExternalLink className="h-4 w-4 ml-2" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Status */}
          <TabsContent value="status" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  All Systems Operational
                </CardTitle>
                <CardDescription>All SoloWay AI services are running smoothly</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="font-medium">Website Builder</span>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      Operational
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="font-medium">AI Tools</span>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      Operational
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <CheckCircle className="h-4 w-4 text-green-500" />
                      <span className="font-medium">Email Marketing</span>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      Operational
                    </Badge>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <AlertCircle className="h-4 w-4 text-yellow-500" />
                      <span className="font-medium">Payment Processing</span>
                    </div>
                    <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                      Maintenance
                    </Badge>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium mb-2">Scheduled Maintenance</h4>
                  <p className="text-sm text-gray-600">
                    Payment processing will undergo routine maintenance on January 20, 2024 from 2:00 AM to 4:00 AM UTC.
                    All other services will remain fully operational.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
