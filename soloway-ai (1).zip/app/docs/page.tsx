"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  BookOpen,
  Video,
  HelpCircle,
  FileText,
  Zap,
  Shield,
  Globe,
  Palette,
  Mail,
  BarChart3,
  Users,
  ArrowRight,
  ExternalLink,
  Play,
  Clock,
  CheckCircle,
} from "lucide-react"
import Link from "next/link"

interface DocSection {
  id: string
  title: string
  description: string
  icon: any
  articles: Article[]
}

interface Article {
  id: string
  title: string
  description: string
  readTime: string
  difficulty: "Beginner" | "Intermediate" | "Advanced"
  tags: string[]
  url: string
}

interface VideoTutorial {
  id: string
  title: string
  description: string
  duration: string
  thumbnail: string
  difficulty: "Beginner" | "Intermediate" | "Advanced"
  views: number
  url: string
}

interface FAQ {
  id: string
  question: string
  answer: string
  category: string
  helpful: number
}

export default function DocsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const docSections: DocSection[] = [
    {
      id: "getting-started",
      title: "Getting Started",
      description: "Learn the basics of SoloWay AI",
      icon: Zap,
      articles: [
        {
          id: "quick-start",
          title: "Quick Start Guide",
          description: "Get up and running with SoloWay AI in 5 minutes",
          readTime: "5 min",
          difficulty: "Beginner",
          tags: ["setup", "basics"],
          url: "/docs/quick-start",
        },
        {
          id: "account-setup",
          title: "Account Setup",
          description: "Configure your account and security settings",
          readTime: "3 min",
          difficulty: "Beginner",
          tags: ["account", "security"],
          url: "/docs/account-setup",
        },
        {
          id: "first-website",
          title: "Creating Your First Website",
          description: "Step-by-step guide to building your first site",
          readTime: "10 min",
          difficulty: "Beginner",
          tags: ["website", "tutorial"],
          url: "/docs/first-website",
        },
      ],
    },
    {
      id: "website-builder",
      title: "Website Builder",
      description: "Master the drag-and-drop website builder",
      icon: Globe,
      articles: [
        {
          id: "builder-interface",
          title: "Builder Interface Overview",
          description: "Understanding the website builder interface",
          readTime: "7 min",
          difficulty: "Beginner",
          tags: ["interface", "builder"],
          url: "/docs/builder-interface",
        },
        {
          id: "templates",
          title: "Working with Templates",
          description: "How to customize and use website templates",
          readTime: "8 min",
          difficulty: "Intermediate",
          tags: ["templates", "customization"],
          url: "/docs/templates",
        },
        {
          id: "custom-domain",
          title: "Custom Domain Setup",
          description: "Connect your own domain to your website",
          readTime: "12 min",
          difficulty: "Intermediate",
          tags: ["domain", "dns"],
          url: "/docs/custom-domain",
        },
      ],
    },
    {
      id: "ai-tools",
      title: "AI Tools",
      description: "Leverage AI for business growth",
      icon: Palette,
      articles: [
        {
          id: "name-generator",
          title: "Business Name Generator",
          description: "Generate unique business names with AI",
          readTime: "4 min",
          difficulty: "Beginner",
          tags: ["ai", "naming"],
          url: "/docs/name-generator",
        },
        {
          id: "logo-maker",
          title: "Logo Maker Guide",
          description: "Create professional logos with our AI tool",
          readTime: "15 min",
          difficulty: "Intermediate",
          tags: ["logo", "design"],
          url: "/docs/logo-maker",
        },
        {
          id: "seo-optimization",
          title: "SEO Optimization",
          description: "Improve your search engine rankings",
          readTime: "20 min",
          difficulty: "Advanced",
          tags: ["seo", "optimization"],
          url: "/docs/seo-optimization",
        },
      ],
    },
    {
      id: "email-marketing",
      title: "Email Marketing",
      description: "Build and engage your audience",
      icon: Mail,
      articles: [
        {
          id: "email-campaigns",
          title: "Creating Email Campaigns",
          description: "Design and send effective email campaigns",
          readTime: "12 min",
          difficulty: "Intermediate",
          tags: ["email", "campaigns"],
          url: "/docs/email-campaigns",
        },
        {
          id: "automation",
          title: "Email Automation",
          description: "Set up automated email sequences",
          readTime: "18 min",
          difficulty: "Advanced",
          tags: ["automation", "sequences"],
          url: "/docs/email-automation",
        },
      ],
    },
    {
      id: "analytics",
      title: "Analytics & Insights",
      description: "Track and analyze your performance",
      icon: BarChart3,
      articles: [
        {
          id: "dashboard-overview",
          title: "Dashboard Overview",
          description: "Understanding your analytics dashboard",
          readTime: "6 min",
          difficulty: "Beginner",
          tags: ["dashboard", "analytics"],
          url: "/docs/dashboard-overview",
        },
        {
          id: "tracking-setup",
          title: "Setting Up Tracking",
          description: "Configure analytics and tracking codes",
          readTime: "10 min",
          difficulty: "Intermediate",
          tags: ["tracking", "setup"],
          url: "/docs/tracking-setup",
        },
      ],
    },
    {
      id: "security",
      title: "Security & Privacy",
      description: "Keep your account and data secure",
      icon: Shield,
      articles: [
        {
          id: "mfa-setup",
          title: "Multi-Factor Authentication",
          description: "Enable MFA for enhanced security",
          readTime: "5 min",
          difficulty: "Beginner",
          tags: ["security", "mfa"],
          url: "/docs/mfa-setup",
        },
        {
          id: "data-privacy",
          title: "Data Privacy & GDPR",
          description: "Understanding data privacy and compliance",
          readTime: "8 min",
          difficulty: "Intermediate",
          tags: ["privacy", "gdpr"],
          url: "/docs/data-privacy",
        },
      ],
    },
  ]

  const videoTutorials: VideoTutorial[] = [
    {
      id: "getting-started-video",
      title: "Getting Started with SoloWay AI",
      description: "Complete walkthrough of the platform",
      duration: "12:34",
      thumbnail: "/placeholder.svg?height=200&width=300",
      difficulty: "Beginner",
      views: 15420,
      url: "/videos/getting-started",
    },
    {
      id: "website-builder-video",
      title: "Website Builder Masterclass",
      description: "Advanced techniques for building websites",
      duration: "28:15",
      thumbnail: "/placeholder.svg?height=200&width=300",
      difficulty: "Intermediate",
      views: 8930,
      url: "/videos/website-builder",
    },
    {
      id: "logo-design-video",
      title: "Logo Design Best Practices",
      description: "Create stunning logos that convert",
      duration: "18:42",
      thumbnail: "/placeholder.svg?height=200&width=300",
      difficulty: "Intermediate",
      views: 12150,
      url: "/videos/logo-design",
    },
    {
      id: "seo-guide-video",
      title: "Complete SEO Guide",
      description: "Rank higher in search results",
      duration: "35:20",
      thumbnail: "/placeholder.svg?height=200&width=300",
      difficulty: "Advanced",
      views: 6780,
      url: "/videos/seo-guide",
    },
  ]

  const faqs: FAQ[] = [
    {
      id: "pricing-faq",
      question: "Can I upgrade or downgrade my plan at any time?",
      answer:
        "Yes, you can upgrade to Pro at any time and start using premium features immediately. If you need to downgrade, you can do so at the end of your current billing cycle to avoid losing access to premium features mid-cycle.",
      category: "Billing",
      helpful: 45,
    },
    {
      id: "domain-faq",
      question: "How do I connect my custom domain?",
      answer:
        "To connect your custom domain, go to your website settings, click on 'Custom Domain', enter your domain name, and follow the DNS configuration instructions. The process typically takes 24-48 hours to complete.",
      category: "Technical",
      helpful: 38,
    },
    {
      id: "backup-faq",
      question: "Are my websites automatically backed up?",
      answer:
        "Yes, we automatically backup all websites daily. Pro users get access to version history and can restore previous versions of their websites at any time.",
      category: "Technical",
      helpful: 52,
    },
    {
      id: "support-faq",
      question: "What support options are available?",
      answer:
        "Free users have access to our help documentation and community forums. Pro users get priority email support and live chat during business hours (9 AM - 6 PM EST, Monday-Friday).",
      category: "Support",
      helpful: 29,
    },
    {
      id: "limits-faq",
      question: "What are the limits on the free plan?",
      answer:
        "The free plan includes 3 websites, basic templates, SoloWay subdomain, up to 100 email subscribers, and community support. You can upgrade to Pro for unlimited websites and premium features.",
      category: "Billing",
      helpful: 67,
    },
    {
      id: "security-faq",
      question: "How secure is my data?",
      answer:
        "We use enterprise-grade security including 256-bit encryption, secure data centers, regular security audits, and optional multi-factor authentication. All data is encrypted both in transit and at rest.",
      category: "Security",
      helpful: 41,
    },
  ]

  const filteredSections = docSections.filter(
    (section) => selectedCategory === "all" || section.id === selectedCategory,
  )

  const searchResults = searchQuery
    ? docSections.flatMap((section) =>
        section.articles.filter(
          (article) =>
            article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            article.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
            article.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())),
        ),
      )
    : []

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-100 text-green-700"
      case "Intermediate":
        return "bg-yellow-100 text-yellow-700"
      case "Advanced":
        return "bg-red-100 text-red-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-8">
          <div className="text-center">
            <h1 className="text-4xl font-bold mb-4 flex items-center justify-center gap-3">
              <BookOpen className="w-10 h-10 text-purple-600" />
              Help Center
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">
              Everything you need to know about SoloWay AI
            </p>

            {/* Search */}
            <div className="max-w-2xl mx-auto relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Search documentation, tutorials, and FAQs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 py-3 text-lg"
              />
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {searchQuery ? (
          /* Search Results */
          <div>
            <h2 className="text-2xl font-bold mb-6">
              Search Results for "{searchQuery}" ({searchResults.length})
            </h2>
            <div className="grid gap-4">
              {searchResults.map((article) => (
                <Card key={article.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-2">
                          <Link href={article.url} className="hover:text-purple-600">
                            {article.title}
                          </Link>
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-3">{article.description}</p>
                        <div className="flex items-center gap-3">
                          <Badge className={getDifficultyColor(article.difficulty)}>{article.difficulty}</Badge>
                          <span className="text-sm text-gray-500 flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {article.readTime}
                          </span>
                          <div className="flex gap-1">
                            {article.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <ArrowRight className="w-5 h-5 text-gray-400 ml-4" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ) : (
          <Tabs defaultValue="documentation" className="space-y-8">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="documentation" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Documentation
              </TabsTrigger>
              <TabsTrigger value="videos" className="flex items-center gap-2">
                <Video className="w-4 h-4" />
                Video Tutorials
              </TabsTrigger>
              <TabsTrigger value="faq" className="flex items-center gap-2">
                <HelpCircle className="w-4 h-4" />
                FAQ
              </TabsTrigger>
            </TabsList>

            <TabsContent value="documentation">
              <div className="grid lg:grid-cols-4 gap-8">
                {/* Categories Sidebar */}
                <div className="lg:col-span-1">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Categories</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <Button
                          variant={selectedCategory === "all" ? "default" : "ghost"}
                          className="w-full justify-start"
                          onClick={() => setSelectedCategory("all")}
                        >
                          All Documentation
                        </Button>
                        {docSections.map((section) => (
                          <Button
                            key={section.id}
                            variant={selectedCategory === section.id ? "default" : "ghost"}
                            className="w-full justify-start"
                            onClick={() => setSelectedCategory(section.id)}
                          >
                            <section.icon className="w-4 h-4 mr-2" />
                            {section.title}
                          </Button>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Documentation Content */}
                <div className="lg:col-span-3">
                  <div className="space-y-8">
                    {filteredSections.map((section) => (
                      <div key={section.id}>
                        <div className="flex items-center gap-3 mb-6">
                          <section.icon className="w-8 h-8 text-purple-600" />
                          <div>
                            <h2 className="text-2xl font-bold">{section.title}</h2>
                            <p className="text-gray-600 dark:text-gray-400">{section.description}</p>
                          </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4">
                          {section.articles.map((article) => (
                            <Card key={article.id} className="hover:shadow-md transition-shadow">
                              <CardContent className="p-6">
                                <h3 className="text-lg font-semibold mb-2">
                                  <Link href={article.url} className="hover:text-purple-600">
                                    {article.title}
                                  </Link>
                                </h3>
                                <p className="text-gray-600 dark:text-gray-400 mb-4">{article.description}</p>
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-2">
                                    <Badge className={getDifficultyColor(article.difficulty)}>
                                      {article.difficulty}
                                    </Badge>
                                    <span className="text-sm text-gray-500 flex items-center gap-1">
                                      <Clock className="w-4 h-4" />
                                      {article.readTime}
                                    </span>
                                  </div>
                                  <Button variant="ghost" size="sm" asChild>
                                    <Link href={article.url}>
                                      Read More
                                      <ArrowRight className="w-4 h-4 ml-1" />
                                    </Link>
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="videos">
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="text-3xl font-bold mb-4">Video Tutorials</h2>
                  <p className="text-gray-600 dark:text-gray-400">Learn SoloWay AI with step-by-step video guides</p>
                </div>

                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {videoTutorials.map((video) => (
                    <Card key={video.id} className="hover:shadow-md transition-shadow">
                      <div className="relative">
                        <img
                          src={video.thumbnail || "/placeholder.svg"}
                          alt={video.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center rounded-t-lg">
                          <Button size="lg" className="rounded-full w-16 h-16">
                            <Play className="w-6 h-6" />
                          </Button>
                        </div>
                        <Badge className="absolute top-2 right-2 bg-black bg-opacity-70 text-white">
                          {video.duration}
                        </Badge>
                      </div>
                      <CardContent className="p-6">
                        <h3 className="text-lg font-semibold mb-2">{video.title}</h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">{video.description}</p>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <Badge className={getDifficultyColor(video.difficulty)}>{video.difficulty}</Badge>
                            <span className="text-sm text-gray-500">{video.views.toLocaleString()} views</span>
                          </div>
                          <Button variant="outline" size="sm" asChild>
                            <Link href={video.url}>
                              Watch
                              <ExternalLink className="w-4 h-4 ml-1" />
                            </Link>
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="faq">
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
                  <p className="text-gray-600 dark:text-gray-400">Quick answers to common questions</p>
                </div>

                <div className="grid gap-4">
                  {faqs.map((faq) => (
                    <Card key={faq.id}>
                      <CardContent className="p-6">
                        <div className="flex items-start justify-between mb-3">
                          <h3 className="text-lg font-semibold pr-4">{faq.question}</h3>
                          <Badge variant="outline">{faq.category}</Badge>
                        </div>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">{faq.answer}</p>
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-gray-500 flex items-center gap-1">
                            <CheckCircle className="w-4 h-4 text-green-500" />
                            {faq.helpful} people found this helpful
                          </span>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              👍 Helpful
                            </Button>
                            <Button variant="outline" size="sm">
                              👎 Not helpful
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        )}

        {/* Contact Support */}
        <Card className="mt-12 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-950 dark:to-blue-950">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold mb-4">Still need help?</h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              Can't find what you're looking for? Our support team is here to help.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild>
                <Link href="/contact">
                  Contact Support
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/community">
                  Join Community
                  <Users className="w-4 h-4 ml-2" />
                </Link>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
