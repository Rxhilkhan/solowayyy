"use client"

import { useState } from "react"

export default function OnboardingPage() {
  const [currentStep, setCurrentStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    businessName: "",
    businessType: "",
    goals: [],
    experience: "",
    preferences: {
      style: "",
      colors: "",
      features: []
    }
  })

  const totalSteps = 7
  const progress = (currentStep / totalSteps) * 100

  const businessTypes = [
    "E-commerce Store",
    "Service Business",
    "Restaurant/Food",
    "Technology/Software",
    "Healthcare",
    "Education",
    "Real Estate",
    "Creative/Agency",
    "Non-profit",
    "Other"
  ]

  const businessGoals = [
    { id: "online-presence", label: "Build online presence", icon: "🌐" },
    { id: "sell-products", label: "Sell products online", icon: "🛒" },
    { id: "generate-leads", label: "Generate leads", icon: "📈" },
    { id: "showcase-portfolio", label: "Showcase portfolio", icon: "🎨\
