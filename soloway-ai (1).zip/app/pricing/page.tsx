"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, X, Zap, Crown, Rocket } from "lucide-react"
import RazorpayCheckout from "@/components/razorpay-checkout"
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog"

const plans = [
  {
    name: "Free",
    price: 0,
    description: "Perfect for getting started",
    icon: Zap,
    features: [
      "3 website generations per month",
      "Basic templates",
      "Standard support",
      "SoloWay branding",
      "1 GB storage",
    ],
    limitations: ["Limited customization", "No custom domain", "Basic SEO tools"],
    popular: false,
    buttonText: "Get Started Free",
    buttonVariant: "outline" as const,
  },
  {
    name: "Pro",
    price: 999,
    description: "Best for growing businesses",
    icon: Crown,
    features: [
      "Unlimited website generations",
      "Premium templates & themes",
      "Advanced AI customization",
      "Custom domain support",
      "Priority support",
      "Remove SoloWay branding",
      "Advanced SEO tools",
      "Email marketing integration",
      "Analytics dashboard",
      "50 GB storage",
      "SSL certificate included",
      "Mobile optimization",
    ],
    limitations: [],
    popular: true,
    buttonText: "Upgrade to Pro",
    buttonVariant: "default" as const,
  },
  {
    name: "Enterprise",
    price: "Custom",
    description: "For large organizations",
    icon: Rocket,
    features: [
      "Everything in Pro",
      "White-label solution",
      "Custom integrations",
      "Dedicated account manager",
      "24/7 phone support",
      "Custom training",
      "SLA guarantee",
      "Unlimited storage",
      "Multi-user collaboration",
      "Advanced security features",
    ],
    limitations: [],
    popular: false,
    buttonText: "Contact Sales",
    buttonVariant: "outline" as const,
  },
]

const faqs = [
  {
    question: "Can I cancel my subscription anytime?",
    answer:
      "Yes, you can cancel your subscription at any time. Your access will continue until the end of your current billing period.",
  },
  {
    question: "Do you offer refunds?",
    answer:
      "We offer a 30-day money-back guarantee for all paid plans. If you're not satisfied, contact us for a full refund.",
  },
  {
    question: "What payment methods do you accept?",
    answer: "We accept all major credit cards, debit cards, UPI, net banking, and digital wallets through Razorpay.",
  },
  {
    question: "Can I upgrade or downgrade my plan?",
    answer:
      "Yes, you can change your plan at any time. Upgrades take effect immediately, while downgrades take effect at the next billing cycle.",
  },
]

export default function PricingPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-white">
      <div className="container mx-auto px-4 py-16">
        {/* Header */}
        <div className="text-center mb-16">
          <Badge className="mb-4 bg-orange-100 text-orange-800 hover:bg-orange-200">Pricing Plans</Badge>
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Choose Your Perfect Plan</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Start free and scale as you grow. All plans include our core AI-powered website building features.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan) => {
            const Icon = plan.icon
            return (
              <Card
                key={plan.name}
                className={`relative ${plan.popular ? "border-orange-500 shadow-lg scale-105" : ""}`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <Badge className="bg-orange-500 text-white">Most Popular</Badge>
                  </div>
                )}

                <CardHeader className="text-center pb-8">
                  <div className="mx-auto w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-orange-600" />
                  </div>
                  <CardTitle className="text-2xl">{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="text-center py-4">
                    <div className="text-4xl font-bold">
                      {typeof plan.price === "number" ? `₹${plan.price}` : plan.price}
                    </div>
                    {typeof plan.price === "number" && plan.price > 0 && (
                      <div className="text-sm text-muted-foreground">per month</div>
                    )}
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    {plan.features.map((feature, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <Check className="w-3 h-3 text-green-600" />
                        </div>
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}

                    {plan.limitations.map((limitation, index) => (
                      <div key={index} className="flex items-center gap-3 opacity-60">
                        <div className="w-5 h-5 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0">
                          <X className="w-3 h-3 text-red-600" />
                        </div>
                        <span className="text-sm">{limitation}</span>
                      </div>
                    ))}
                  </div>

                  {plan.name === "Pro" ? (
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant={plan.buttonVariant} className="w-full" size="lg">
                          {plan.buttonText}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <RazorpayCheckout planType="pro" amount={999} planName="Pro Plan" features={plan.features} />
                      </DialogContent>
                    </Dialog>
                  ) : (
                    <Button
                      variant={plan.buttonVariant}
                      className="w-full"
                      size="lg"
                      onClick={() => {
                        if (plan.name === "Free") {
                          window.location.href = "/auth/signup"
                        } else {
                          window.location.href = "/contact"
                        }
                      }}
                    >
                      {plan.buttonText}
                    </Button>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* FAQ Section */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-8">Frequently Asked Questions</h2>
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="text-lg">{faq.question}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16 p-8 bg-orange-50 rounded-2xl">
          <h3 className="text-2xl font-bold mb-4">Ready to get started?</h3>
          <p className="text-muted-foreground mb-6">
            Join thousands of businesses already using SoloWay AI to build their online presence.
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" onClick={() => (window.location.href = "/auth/signup")}>
              Start Free Trial
            </Button>
            <Button variant="outline" size="lg" onClick={() => (window.location.href = "/contact")}>
              Contact Sales
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
