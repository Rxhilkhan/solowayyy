import { type NextRequest, NextResponse } from "next/server"

// Mock keyword research - replace with actual SEO API
const generateKeywords = (seedKeyword: string, location?: string) => {
  const relatedKeywords = {
    "web design": [
      { keyword: "responsive web design", volume: 22000, difficulty: "Medium", cpc: 2.5, intent: "Commercial" },
      { keyword: "website design services", volume: 18000, difficulty: "High", cpc: 3.2, intent: "Commercial" },
      { keyword: "modern web design", volume: 8100, difficulty: "Low", cpc: 1.8, intent: "Informational" },
      { keyword: "web design company", volume: 15000, difficulty: "High", cpc: 4.1, intent: "Commercial" },
      { keyword: "custom web design", volume: 12000, difficulty: "Medium", cpc: 2.9, intent: "Commercial" },
    ],
    marketing: [
      { keyword: "digital marketing", volume: 45000, difficulty: "High", cpc: 3.8, intent: "Commercial" },
      { keyword: "content marketing", volume: 28000, difficulty: "Medium", cpc: 2.4, intent: "Informational" },
      { keyword: "email marketing", volume: 35000, difficulty: "Medium", cpc: 2.1, intent: "Commercial" },
      { keyword: "social media marketing", volume: 32000, difficulty: "High", cpc: 3.5, intent: "Commercial" },
      { keyword: "marketing strategy", volume: 19000, difficulty: "Medium", cpc: 2.8, intent: "Informational" },
    ],
  }

  const defaultKeywords = [
    { keyword: `${seedKeyword} services`, volume: 15000, difficulty: "Medium", cpc: 2.5, intent: "Commercial" },
    { keyword: `best ${seedKeyword}`, volume: 12000, difficulty: "High", cpc: 3.0, intent: "Commercial" },
    { keyword: `${seedKeyword} tips`, volume: 8000, difficulty: "Low", cpc: 1.2, intent: "Informational" },
    { keyword: `${seedKeyword} guide`, volume: 6500, difficulty: "Low", cpc: 1.5, intent: "Informational" },
    { keyword: `${seedKeyword} company`, volume: 9000, difficulty: "High", cpc: 3.8, intent: "Commercial" },
  ]

  const keywords = relatedKeywords[seedKeyword.toLowerCase() as keyof typeof relatedKeywords] || defaultKeywords

  return keywords.map((kw) => ({
    ...kw,
    trend: Math.random() > 0.5 ? "up" : "down",
    competition: Math.random(),
    seasonality: Math.random() > 0.7,
  }))
}

export async function POST(request: NextRequest) {
  try {
    const { seedKeyword, location, intent } = await request.json()

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 800))

    const keywords = generateKeywords(seedKeyword, location)

    // Filter by intent if specified
    const filteredKeywords = intent && intent !== "All" ? keywords.filter((kw) => kw.intent === intent) : keywords

    return NextResponse.json({
      keywords: filteredKeywords,
      seedKeyword,
      location,
      totalResults: filteredKeywords.length,
    })
  } catch (error) {
    console.error("Keyword research error:", error)
    return NextResponse.json({ error: "Failed to fetch keywords" }, { status: 500 })
  }
}
