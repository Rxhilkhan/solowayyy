import { type NextRequest, NextResponse } from "next/server"
import { authService } from "@/lib/auth"
import { paywallService } from "@/lib/paywall"

export async function POST(request: NextRequest) {
  try {
    const user = await authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { featureId } = await request.json()

    if (!featureId) {
      return NextResponse.json({ error: "Feature ID is required" }, { status: 400 })
    }

    const hasAccess = await paywallService.canAccessFeature(user.id, featureId)
    const availableFeatures = await paywallService.getAvailableFeatures(user.id)
    const blockedFeatures = await paywallService.getBlockedFeatures(user.id)

    return NextResponse.json({
      hasAccess,
      featureId,
      availableFeatures,
      blockedFeatures,
    })
  } catch (error: any) {
    console.error("Paywall check error:", error)
    return NextResponse.json({ error: error.message || "Failed to check feature access" }, { status: 500 })
  }
}
