import { type NextRequest, NextResponse } from "next/server"
import { enhancedAuthService } from "@/lib/auth-enhanced"
import { securityHeaders } from "@/lib/security"

export async function POST(request: NextRequest) {
  try {
    const headers = new Headers()
    Object.entries(securityHeaders).forEach(([key, value]) => {
      headers.set(key, value)
    })

    const user = await enhancedAuthService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401, headers })
    }

    const mfaSetup = await enhancedAuthService.setupMFA(user.id)

    return NextResponse.json(
      {
        secret: mfaSetup.secret,
        qrCode: mfaSetup.qrCode,
        backupCodes: mfaSetup.backupCodes,
      },
      { headers },
    )
  } catch (error: any) {
    console.error("MFA setup error:", error)
    return NextResponse.json(
      { error: "Failed to setup MFA" },
      { status: 500, headers: new Headers(Object.entries(securityHeaders)) },
    )
  }
}
