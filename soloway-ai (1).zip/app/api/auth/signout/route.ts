import { type NextRequest, NextResponse } from "next/server"
import { authService } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    await authService.signOut()

    return NextResponse.json({
      message: "Signed out successfully",
    })
  } catch (error: any) {
    console.error("Signout error:", error)
    return NextResponse.json({ error: error.message || "Failed to sign out" }, { status: 500 })
  }
}
