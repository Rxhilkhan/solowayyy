import { type NextRequest, NextResponse } from "next/server"
import { enhancedAuthService } from "@/lib/auth-enhanced"
import { validators, securityHeaders, createRateLimit } from "@/lib/security"

// Rate limiting: 5 attempts per 15 minutes
const limiter = createRateLimit(15 * 60 * 1000, 5)

export async function POST(request: NextRequest) {
  try {
    // Apply security headers
    const headers = new Headers()
    Object.entries(securityHeaders).forEach(([key, value]) => {
      headers.set(key, value)
    })

    const { email, password, mfaToken } = await request.json()

    // Validate inputs
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password are required" }, { status: 400, headers })
    }

    if (!validators.email(email)) {
      return NextResponse.json({ error: "Invalid email format" }, { status: 400, headers })
    }

    // Check for suspicious activity
    const isSuspicious = await enhancedAuthService.checkSuspiciousActivity(email)
    if (isSuspicious) {
      return NextResponse.json(
        { error: "Account temporarily locked due to suspicious activity" },
        { status: 429, headers },
      )
    }

    const data = await enhancedAuthService.signIn(email, password, mfaToken, request)

    return NextResponse.json(
      {
        message: "Signed in successfully",
        user: data.user,
        session: data.session,
      },
      { headers },
    )
  } catch (error: any) {
    console.error("Signin error:", error)

    if (error.message === "MFA_REQUIRED") {
      return NextResponse.json(
        { error: "MFA_REQUIRED", message: "Multi-factor authentication required" },
        { status: 200, headers: new Headers(Object.entries(securityHeaders)) },
      )
    }

    return NextResponse.json(
      { error: error.message || "Authentication failed" },
      { status: 401, headers: new Headers(Object.entries(securityHeaders)) },
    )
  }
}
