import { type NextRequest, NextResponse } from "next/server"
import { authService } from "@/lib/auth"
import { paywallService } from "@/lib/paywall"
import { supabase } from "@/lib/supabase"

export async function GET(request: NextRequest) {
  try {
    const user = await authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { data: websites, error } = await supabase
      .from("websites")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })

    if (error) throw error

    return NextResponse.json({ websites })
  } catch (error: any) {
    console.error("Get websites error:", error)
    return NextResponse.json({ error: error.message || "Failed to get websites" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = await authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { name, template, subdomain } = await request.json()

    // Check if user can create more websites
    const { data: existingWebsites } = await supabase.from("websites").select("id").eq("user_id", user.id)

    const profile = await authService.getUserProfile(user.id)
    const maxWebsites = profile?.plan === "free" ? 3 : 999

    if (existingWebsites && existingWebsites.length >= maxWebsites) {
      const canCreateUnlimited = await paywallService.canAccessFeature(user.id, "unlimited_websites")
      if (!canCreateUnlimited) {
        return NextResponse.json(
          { error: "Website limit reached. Upgrade to Pro for unlimited websites." },
          { status: 403 },
        )
      }
    }

    const { data: website, error } = await supabase
      .from("websites")
      .insert({
        user_id: user.id,
        name,
        template: template || "blank",
        subdomain: subdomain || name.toLowerCase().replace(/[^a-z0-9]/g, ""),
        status: "draft",
        content: {},
        settings: {},
      })
      .select()
      .single()

    if (error) throw error

    return NextResponse.json({ website })
  } catch (error: any) {
    console.error("Create website error:", error)
    return NextResponse.json({ error: error.message || "Failed to create website" }, { status: 500 })
  }
}
