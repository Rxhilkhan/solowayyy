import { type NextRequest, NextResponse } from "next/server"
import { authService } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const user = await authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const profile = await authService.getUserProfile(user.id)
    return NextResponse.json({ profile })
  } catch (error: any) {
    console.error("Get profile error:", error)
    return NextResponse.json({ error: error.message || "Failed to get profile" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const user = await authService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const updates = await request.json()
    const profile = await authService.updateUserProfile(user.id, updates)

    return NextResponse.json({ profile })
  } catch (error: any) {
    console.error("Update profile error:", error)
    return NextResponse.json({ error: error.message || "Failed to update profile" }, { status: 500 })
  }
}
