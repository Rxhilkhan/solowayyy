import { type NextRequest, NextResponse } from "next/server"

// Mock name generation - replace with actual AI API
const generateNames = (industry: string, keywords: string[], description: string) => {
  const prefixes = ["Pro", "Smart", "Digital", "Next", "Bright", "Swift", "Prime", "Elite"]
  const suffixes = ["Lab", "Hub", "Works", "Solutions", "Craft", "Flow", "Tech", "Studio"]
  const industryWords = {
    technology: ["Tech", "Digital", "Cyber", "Data", "Cloud", "AI"],
    consulting: ["Consult", "Advisory", "Strategy", "Expert", "Pro"],
    design: ["Design", "Creative", "Visual", "Art", "Studio"],
    marketing: ["Market", "Brand", "Growth", "Boost", "Reach"],
  }

  const names = []
  const industryKey = industry.toLowerCase() as keyof typeof industryWords
  const relevantWords = industryWords[industryKey] || industryWords.technology

  // Generate combination names
  for (let i = 0; i < 4; i++) {
    const prefix = prefixes[Math.floor(Math.random() * prefixes.length)]
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)]
    names.push(`${prefix}${suffix}`)
  }

  // Generate industry-specific names
  for (let i = 0; i < 4; i++) {
    const word = relevantWords[Math.floor(Math.random() * relevantWords.length)]
    const suffix = suffixes[Math.floor(Math.random() * suffixes.length)]
    names.push(`${word}${suffix}`)
  }

  return names.map((name) => ({
    name,
    available: Math.random() > 0.3, // 70% chance of being available
    domain: `${name.toLowerCase().replace(/\s+/g, "")}.com`,
    score: Math.floor(Math.random() * 40) + 60, // Score between 60-100
  }))
}

export async function POST(request: NextRequest) {
  try {
    const { industry, keywords, description, style } = await request.json()

    // Simulate API delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    const keywordArray = keywords.split(",").map((k: string) => k.trim())
    const suggestions = generateNames(industry, keywordArray, description)

    return NextResponse.json({
      suggestions,
      count: suggestions.length,
    })
  } catch (error) {
    console.error("Name generation error:", error)
    return NextResponse.json({ error: "Failed to generate names" }, { status: 500 })
  }
}
