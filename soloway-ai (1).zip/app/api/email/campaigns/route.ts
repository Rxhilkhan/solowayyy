import { type NextRequest, NextResponse } from "next/server"

// Mock email campaigns - replace with actual email service API
const campaigns = [
  {
    id: "1",
    name: "Welcome Series",
    status: "active",
    subject: "Welcome to SoloWay AI!",
    sent: 156,
    opened: 89,
    clicked: 23,
    bounced: 2,
    unsubscribed: 1,
    createdAt: "2024-12-20T10:00:00Z",
    scheduledAt: null,
    content: "Welcome to our platform! We're excited to have you on board.",
  },
  {
    id: "2",
    name: "Product Launch",
    status: "draft",
    subject: "Exciting New Features Available Now!",
    sent: 0,
    opened: 0,
    clicked: 0,
    bounced: 0,
    unsubscribed: 0,
    createdAt: "2024-12-25T14:30:00Z",
    scheduledAt: null,
    content: "Check out our latest features designed to help you grow your business.",
  },
]

export async function GET() {
  try {
    return NextResponse.json({
      campaigns,
      total: campaigns.length,
    })
  } catch (error) {
    console.error("Get campaigns error:", error)
    return NextResponse.json({ error: "Failed to fetch campaigns" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const { name, subject, content, scheduledAt, recipientList } = await request.json()

    const newCampaign = {
      id: Date.now().toString(),
      name,
      subject,
      content,
      status: scheduledAt ? "scheduled" : "draft",
      sent: 0,
      opened: 0,
      clicked: 0,
      bounced: 0,
      unsubscribed: 0,
      createdAt: new Date().toISOString(),
      scheduledAt,
      recipientList: recipientList || "all",
    }

    campaigns.push(newCampaign)

    return NextResponse.json(newCampaign)
  } catch (error) {
    console.error("Create campaign error:", error)
    return NextResponse.json({ error: "Failed to create campaign" }, { status: 500 })
  }
}
