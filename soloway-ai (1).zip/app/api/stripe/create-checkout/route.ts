import { type NextRequest, NextResponse } from "next/server"
import { createCheckoutSession, STRIPE_PLANS } from "@/lib/stripe"
import { enhancedAuthService } from "@/lib/auth-enhanced"
import { securityHeaders } from "@/lib/security"

export async function POST(request: NextRequest) {
  try {
    // Apply security headers
    const headers = new Headers()
    Object.entries(securityHeaders).forEach(([key, value]) => {
      headers.set(key, value)
    })

    const user = await enhancedAuthService.getCurrentUser()
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401, headers })
    }

    const { planType } = await request.json()

    if (!planType || !STRIPE_PLANS[planType as keyof typeof STRIPE_PLANS]) {
      return NextResponse.json({ error: "Invalid plan type" }, { status: 400, headers })
    }

    const plan = STRIPE_PLANS[planType as keyof typeof STRIPE_PLANS]

    if (!plan.priceId) {
      return NextResponse.json({ error: "Plan not available for purchase" }, { status: 400, headers })
    }

    const successUrl = `${process.env.NEXT_PUBLIC_SITE_URL}/dashboard?success=true`
    const cancelUrl = `${process.env.NEXT_PUBLIC_SITE_URL}/pricing?canceled=true`

    const session = await createCheckoutSession(user.id, plan.priceId, successUrl, cancelUrl)

    return NextResponse.json({ sessionId: session.id }, { headers })
  } catch (error: any) {
    console.error("Stripe checkout error:", error)
    return NextResponse.json({ error: "Failed to create checkout session" }, { status: 500 })
  }
}
