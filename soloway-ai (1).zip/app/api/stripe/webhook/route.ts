import { type NextRequest, NextResponse } from "next/server"
import { stripe } from "@/lib/stripe"
import { createServerClient } from "@/lib/supabase"
import { headers } from "next/headers"

const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET!

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const headersList = await headers()
    const signature = headersList.get("stripe-signature")!

    let event
    try {
      event = stripe.webhooks.constructEvent(body, signature, webhookSecret)
    } catch (err: any) {
      console.error("Webhook signature verification failed:", err.message)
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    const supabase = createServerClient()

    switch (event.type) {
      case "checkout.session.completed": {
        const session = event.data.object
        const userId = session.metadata?.userId

        if (userId) {
          // Update user subscription status
          await supabase
            .from("user_profiles")
            .update({
              plan: "pro",
              subscription_status: "active",
              subscription_id: session.subscription,
              stripe_customer_id: session.customer,
            })
            .eq("id", userId)
        }
        break
      }

      case "customer.subscription.updated": {
        const subscription = event.data.object

        await supabase
          .from("user_profiles")
          .update({
            subscription_status: subscription.status,
          })
          .eq("subscription_id", subscription.id)
        break
      }

      case "customer.subscription.deleted": {
        const subscription = event.data.object

        await supabase
          .from("user_profiles")
          .update({
            plan: "free",
            subscription_status: "canceled",
            subscription_id: null,
          })
          .eq("subscription_id", subscription.id)
        break
      }

      case "invoice.payment_failed": {
        const invoice = event.data.object

        await supabase
          .from("user_profiles")
          .update({
            subscription_status: "past_due",
          })
          .eq("stripe_customer_id", invoice.customer)
        break
      }
    }

    return NextResponse.json({ received: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook handler failed" }, { status: 500 })
  }
}
