import { type NextRequest, NextResponse } from "next/server"
import { verifyWebhookSignature } from "@/lib/razorpay"
import { createClient } from "@/lib/supabase"

export async function POST(request: NextRequest) {
  try {
    const body = await request.text()
    const signature = request.headers.get("x-razorpay-signature")

    if (!signature) {
      return NextResponse.json({ error: "Missing signature" }, { status: 400 })
    }

    // Verify webhook signature
    const isValidSignature = verifyWebhookSignature(body, signature)

    if (!isValidSignature) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 400 })
    }

    const event = JSON.parse(body)
    const supabase = createClient()

    switch (event.event) {
      case "payment.captured":
        await handlePaymentCaptured(event.payload.payment.entity, supabase)
        break

      case "payment.failed":
        await handlePaymentFailed(event.payload.payment.entity, supabase)
        break

      case "subscription.cancelled":
        await handleSubscriptionCancelled(event.payload.subscription.entity, supabase)
        break

      case "subscription.charged":
        await handleSubscriptionCharged(event.payload.payment.entity, supabase)
        break

      default:
        console.log("Unhandled webhook event:", event.event)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}

async function handlePaymentCaptured(payment: any, supabase: any) {
  try {
    // Update payment status
    await supabase
      .from("payment_orders")
      .update({
        status: "captured",
        updated_at: new Date().toISOString(),
      })
      .eq("payment_id", payment.id)

    console.log("Payment captured:", payment.id)
  } catch (error) {
    console.error("Error handling payment captured:", error)
  }
}

async function handlePaymentFailed(payment: any, supabase: any) {
  try {
    // Update payment status
    await supabase
      .from("payment_orders")
      .update({
        status: "failed",
        failure_reason: payment.error_description,
        updated_at: new Date().toISOString(),
      })
      .eq("payment_id", payment.id)

    console.log("Payment failed:", payment.id)
  } catch (error) {
    console.error("Error handling payment failed:", error)
  }
}

async function handleSubscriptionCancelled(subscription: any, supabase: any) {
  try {
    // Update subscription status
    await supabase
      .from("user_subscriptions")
      .update({
        status: "cancelled",
        cancelled_at: new Date().toISOString(),
      })
      .eq("razorpay_subscription_id", subscription.id)

    console.log("Subscription cancelled:", subscription.id)
  } catch (error) {
    console.error("Error handling subscription cancelled:", error)
  }
}

async function handleSubscriptionCharged(payment: any, supabase: any) {
  try {
    // Extend subscription period
    const { data: subscription } = await supabase
      .from("user_subscriptions")
      .select("*")
      .eq("razorpay_subscription_id", payment.subscription_id)
      .single()

    if (subscription) {
      const newExpiryDate = new Date(subscription.expires_at)
      newExpiryDate.setMonth(newExpiryDate.getMonth() + 1)

      await supabase
        .from("user_subscriptions")
        .update({
          expires_at: newExpiryDate.toISOString(),
          last_payment_at: new Date().toISOString(),
        })
        .eq("id", subscription.id)
    }

    console.log("Subscription charged:", payment.id)
  } catch (error) {
    console.error("Error handling subscription charged:", error)
  }
}
