import { type NextRequest, NextResponse } from "next/server"
import { verifyRazorpaySignature, getPaymentDetails } from "@/lib/razorpay"
import { createClient } from "@/lib/supabase"
import { cookies } from "next/headers"

export async function POST(request: NextRequest) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = await request.json()

    // Verify signature
    const isValidSignature = verifyRazorpaySignature(razorpay_order_id, razorpay_payment_id, razorpay_signature)

    if (!isValidSignature) {
      return NextResponse.json({ error: "Invalid payment signature" }, { status: 400 })
    }

    // Get user from session
    const cookieStore = cookies()
    const supabase = createClient(cookieStore)
    const {
      data: { user },
      error: authError,
    } = await supabase.auth.getUser()

    if (authError || !user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    // Get payment details from Razorpay
    const paymentDetails = await getPaymentDetails(razorpay_payment_id)

    // Update order status in database
    const { error: updateError } = await supabase
      .from("payment_orders")
      .update({
        payment_id: razorpay_payment_id,
        status: "completed",
        payment_method: paymentDetails.method,
        updated_at: new Date().toISOString(),
      })
      .eq("id", razorpay_order_id)
      .eq("user_id", user.id)

    if (updateError) {
      console.error("Database update error:", updateError)
      return NextResponse.json({ error: "Failed to update payment status" }, { status: 500 })
    }

    // Update user subscription status
    const { error: subscriptionError } = await supabase.from("user_subscriptions").upsert({
      user_id: user.id,
      plan_type: "pro",
      status: "active",
      started_at: new Date().toISOString(),
      expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days
      payment_id: razorpay_payment_id,
    })

    if (subscriptionError) {
      console.error("Subscription update error:", subscriptionError)
    }

    // Log successful payment
    await supabase.from("audit_logs").insert({
      user_id: user.id,
      action: "payment_completed",
      details: {
        payment_id: razorpay_payment_id,
        order_id: razorpay_order_id,
        amount: paymentDetails.amount / 100,
      },
      ip_address: request.headers.get("x-forwarded-for") || "unknown",
      user_agent: request.headers.get("user-agent") || "unknown",
    })

    return NextResponse.json({
      success: true,
      message: "Payment verified successfully",
      paymentId: razorpay_payment_id,
    })
  } catch (error) {
    console.error("Error verifying payment:", error)
    return NextResponse.json({ error: "Failed to verify payment" }, { status: 500 })
  }
}
