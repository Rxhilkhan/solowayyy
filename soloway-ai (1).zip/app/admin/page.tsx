import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Users,
  Globe,
  DollarSign,
  BarChart3,
  Settings,
  Shield,
  Database,
  Activity,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
} from "lucide-react"
import Link from "next/link"

export default function AdminDashboard() {
  // Mock data - replace with real data from Supabase
  const stats = {
    totalUsers: 12543,
    activeUsers: 8921,
    totalWebsites: 25678,
    revenue: 45230,
    conversionRate: 3.2,
    churnRate: 2.1,
  }

  const recentUsers = [
    { id: 1, name: "John Doe", email: "john@example.com", plan: "pro", status: "active", joinedAt: "2024-01-15" },
    { id: 2, name: "Jane Smith", email: "jane@example.com", plan: "free", status: "active", joinedAt: "2024-01-14" },
    { id: 3, name: "Bob Johnson", email: "bob@example.com", plan: "pro", status: "canceled", joinedAt: "2024-01-13" },
  ]

  const systemHealth = {
    database: "healthy",
    api: "healthy",
    storage: "warning",
    auth: "healthy",
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">SoloWay AI Admin</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm" asChild>
              <Link href="/dashboard">Back to App</Link>
            </Button>
            <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
              <span className="text-sm font-medium text-purple-600">AD</span>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Users</p>
                  <p className="text-2xl font-bold">{stats.totalUsers.toLocaleString()}</p>
                  <p className="text-xs text-green-600">+12% from last month</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Active Users</p>
                  <p className="text-2xl font-bold">{stats.activeUsers.toLocaleString()}</p>
                  <p className="text-xs text-green-600">+8% from last month</p>
                </div>
                <Activity className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Websites</p>
                  <p className="text-2xl font-bold">{stats.totalWebsites.toLocaleString()}</p>
                  <p className="text-xs text-green-600">+15% from last month</p>
                </div>
                <Globe className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Monthly Revenue</p>
                  <p className="text-2xl font-bold">${stats.revenue.toLocaleString()}</p>
                  <p className="text-xs text-green-600">+22% from last month</p>
                </div>
                <DollarSign className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="websites">Websites</TabsTrigger>
            <TabsTrigger value="revenue">Revenue</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    Key Metrics
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Conversion Rate</span>
                      <span className="text-sm font-bold text-green-600">{stats.conversionRate}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Churn Rate</span>
                      <span className="text-sm font-bold text-red-600">{stats.churnRate}%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Free to Pro Conversion</span>
                      <span className="text-sm font-bold text-blue-600">18.5%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Avg. Revenue Per User</span>
                      <span className="text-sm font-bold text-purple-600">$12.45</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Shield className="w-5 h-5 mr-2" />
                    System Health
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {Object.entries(systemHealth).map(([service, status]) => (
                      <div key={service} className="flex justify-between items-center">
                        <span className="text-sm font-medium capitalize">{service}</span>
                        <Badge
                          variant={
                            status === "healthy" ? "default" : status === "warning" ? "secondary" : "destructive"
                          }
                          className={
                            status === "healthy"
                              ? "bg-green-100 text-green-700"
                              : status === "warning"
                                ? "bg-yellow-100 text-yellow-700"
                                : "bg-red-100 text-red-700"
                          }
                        >
                          {status === "healthy" && <CheckCircle className="w-3 h-3 mr-1" />}
                          {status === "warning" && <AlertTriangle className="w-3 h-3 mr-1" />}
                          {status.charAt(0).toUpperCase() + status.slice(1)}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Users Tab */}
          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Users</CardTitle>
                <CardDescription>Latest user registrations and activity</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentUsers.map((user) => (
                    <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                          <span className="text-sm font-medium text-purple-600">
                            {user.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </span>
                        </div>
                        <div>
                          <h3 className="font-medium">{user.name}</h3>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          <p className="text-xs text-gray-500">Joined: {user.joinedAt}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge variant={user.plan === "pro" ? "default" : "secondary"}>{user.plan.toUpperCase()}</Badge>
                        <Badge variant={user.status === "active" ? "default" : "destructive"}>{user.status}</Badge>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Websites Tab */}
          <TabsContent value="websites" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Website Analytics</CardTitle>
                <CardDescription>Overview of created websites and templates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-3 gap-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">25,678</div>
                    <div className="text-sm text-gray-600">Total Websites</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">18,432</div>
                    <div className="text-sm text-gray-600">Published</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-orange-600">7,246</div>
                    <div className="text-sm text-gray-600">Drafts</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Revenue Tab */}
          <TabsContent value="revenue" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Revenue Analytics</CardTitle>
                <CardDescription>Financial performance and subscription metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <h3 className="font-semibold mb-4">Monthly Recurring Revenue</h3>
                    <div className="text-3xl font-bold text-green-600 mb-2">$45,230</div>
                    <p className="text-sm text-gray-600">+22% from last month</p>
                  </div>
                  <div>
                    <h3 className="font-semibold mb-4">Subscription Breakdown</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Free Plan</span>
                        <span className="font-medium">8,921 users</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Pro Plan</span>
                        <span className="font-medium">3,622 users</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* System Tab */}
          <TabsContent value="system" className="space-y-6">
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Database className="w-5 h-5 mr-2" />
                    Database Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Connection Pool</span>
                      <Badge className="bg-green-100 text-green-700">Healthy</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Query Performance</span>
                      <Badge className="bg-green-100 text-green-700">Optimal</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Storage Usage</span>
                      <Badge className="bg-yellow-100 text-yellow-700">75% Used</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    API Performance
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span>Response Time</span>
                      <span className="font-medium text-green-600">145ms avg</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Success Rate</span>
                      <span className="font-medium text-green-600">99.8%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Requests/min</span>
                      <span className="font-medium">2,341</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="w-5 h-5 mr-2" />
                  System Configuration
                </CardTitle>
                <CardDescription>Manage system-wide settings and configurations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="font-semibold mb-4">Feature Flags</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span>AI Name Generator</span>
                        <Badge className="bg-green-100 text-green-700">Enabled</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Custom Domains</span>
                        <Badge className="bg-green-100 text-green-700">Enabled</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Email Marketing</span>
                        <Badge className="bg-yellow-100 text-yellow-700">Beta</Badge>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold mb-4">Rate Limits</h3>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span>API Requests (Free)</span>
                        <span className="font-medium">1000/hour</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>API Requests (Pro)</span>
                        <span className="font-medium">10000/hour</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Website Builds</span>
                        <span className="font-medium">50/day</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
