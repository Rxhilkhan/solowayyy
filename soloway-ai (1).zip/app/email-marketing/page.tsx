"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Users, Send, Plus, Eye, Edit, Trash2, Target, TrendingUp } from "lucide-react"

export default function EmailMarketingPage() {
  const [selectedTemplate, setSelectedTemplate] = useState("")
  const [emailSubject, setEmailSubject] = useState("")
  const [emailContent, setEmailContent] = useState("")
  const [selectedList, setSelectedList] = useState("")

  const emailTemplates = [
    { id: "welcome", name: "Welcome Email", category: "Onboarding", opens: "45%" },
    { id: "newsletter", name: "Newsletter", category: "Content", opens: "38%" },
    { id: "promotion", name: "Promotional", category: "Sales", opens: "52%" },
    { id: "abandoned", name: "Abandoned Cart", category: "E-commerce", opens: "65%" },
  ]

  const subscriberLists = [
    { id: "all", name: "All Subscribers", count: 2847 },
    { id: "customers", name: "Customers", count: 1234 },
    { id: "leads", name: "Leads", count: 1613 },
    { id: "vip", name: "VIP Members", count: 156 },
  ]

  const campaigns = [
    {
      id: 1,
      name: "Welcome Series",
      status: "Active",
      sent: 1250,
      opens: 875,
      clicks: 156,
      date: "2024-01-15",
    },
    {
      id: 2,
      name: "Monthly Newsletter",
      status: "Sent",
      sent: 2847,
      opens: 1920,
      clicks: 384,
      date: "2024-01-10",
    },
    {
      id: 3,
      name: "Product Launch",
      status: "Draft",
      sent: 0,
      opens: 0,
      clicks: 0,
      date: "2024-01-20",
    },
  ]

  const handleSendCampaign = () => {
    if (!emailSubject || !emailContent || !selectedList) {
      alert("Please fill in all required fields")
      return
    }
    alert("Campaign sent successfully!")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Email Marketing</h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Create, send, and track email campaigns that engage your audience and drive conversions.
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Subscribers</p>
                  <p className="text-2xl font-bold text-gray-900">2,847</p>
                </div>
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <div className="mt-2">
                <span className="text-green-600 text-sm font-medium">+12.5%</span>
                <span className="text-gray-500 text-sm ml-1">from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Open Rate</p>
                  <p className="text-2xl font-bold text-gray-900">42.3%</p>
                </div>
                <Eye className="h-8 w-8 text-green-600" />
              </div>
              <div className="mt-2">
                <span className="text-green-600 text-sm font-medium">+2.1%</span>
                <span className="text-gray-500 text-sm ml-1">from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Click Rate</p>
                  <p className="text-2xl font-bold text-gray-900">9.7%</p>
                </div>
                <Target className="h-8 w-8 text-purple-600" />
              </div>
              <div className="mt-2">
                <span className="text-green-600 text-sm font-medium">+0.8%</span>
                <span className="text-gray-500 text-sm ml-1">from last month</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Revenue</p>
                  <p className="text-2xl font-bold text-gray-900">₹45,230</p>
                </div>
                <TrendingUp className="h-8 w-8 text-orange-600" />
              </div>
              <div className="mt-2">
                <span className="text-green-600 text-sm font-medium">+18.2%</span>
                <span className="text-gray-500 text-sm ml-1">from last month</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="campaigns" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
            <TabsTrigger value="create">Create</TabsTrigger>
            <TabsTrigger value="lists">Lists</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Campaigns Tab */}
          <TabsContent value="campaigns" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Email Campaigns</h2>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                New Campaign
              </Button>
            </div>

            <div className="space-y-4">
              {campaigns.map((campaign) => (
                <Card key={campaign.id}>
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-2">{campaign.name}</h3>
                        <Badge
                          variant={
                            campaign.status === "Active"
                              ? "default"
                              : campaign.status === "Sent"
                                ? "secondary"
                                : "outline"
                          }
                        >
                          {campaign.status}
                        </Badge>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-2" />
                          View
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </Button>
                        <Button variant="outline" size="sm">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Sent</p>
                        <p className="text-lg font-semibold text-gray-900">{campaign.sent.toLocaleString()}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Opens</p>
                        <p className="text-lg font-semibold text-gray-900">{campaign.opens.toLocaleString()}</p>
                        <p className="text-xs text-green-600">
                          {campaign.sent > 0 ? ((campaign.opens / campaign.sent) * 100).toFixed(1) : 0}%
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Clicks</p>
                        <p className="text-lg font-semibold text-gray-900">{campaign.clicks.toLocaleString()}</p>
                        <p className="text-xs text-blue-600">
                          {campaign.sent > 0 ? ((campaign.clicks / campaign.sent) * 100).toFixed(1) : 0}%
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Date</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {new Date(campaign.date).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Create Campaign Tab */}
          <TabsContent value="create" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Create New Campaign</CardTitle>
                <CardDescription>Design and send your email campaign</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="subject">Email Subject</Label>
                      <Input
                        id="subject"
                        placeholder="Enter email subject"
                        value={emailSubject}
                        onChange={(e) => setEmailSubject(e.target.value)}
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="template">Email Template</Label>
                      <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a template" />
                        </SelectTrigger>
                        <SelectContent>
                          {emailTemplates.map((template) => (
                            <SelectItem key={template.id} value={template.id}>
                              {template.name} - {template.category}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="list">Subscriber List</Label>
                      <Select value={selectedList} onValueChange={setSelectedList}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select subscriber list" />
                        </SelectTrigger>
                        <SelectContent>
                          {subscriberLists.map((list) => (
                            <SelectItem key={list.id} value={list.id}>
                              {list.name} ({list.count.toLocaleString()} subscribers)
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="content">Email Content</Label>
                      <Textarea
                        id="content"
                        placeholder="Write your email content here..."
                        value={emailContent}
                        onChange={(e) => setEmailContent(e.target.value)}
                        rows={10}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <Button onClick={handleSendCampaign} className="bg-blue-600 hover:bg-blue-700">
                    <Send className="h-4 w-4 mr-2" />
                    Send Campaign
                  </Button>
                  <Button variant="outline">Save Draft</Button>
                  <Button variant="outline">
                    <Eye className="h-4 w-4 mr-2" />
                    Preview
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Lists Tab */}
          <TabsContent value="lists" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-gray-900">Subscriber Lists</h2>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Create List
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {subscriberLists.map((list) => (
                <Card key={list.id}>
                  <CardContent className="p-6">
                    <div className="text-center">
                      <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{list.name}</h3>
                      <p className="text-2xl font-bold text-blue-600 mb-2">{list.count.toLocaleString()}</p>
                      <p className="text-sm text-gray-600 mb-4">subscribers</p>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1 bg-transparent">
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Campaign Performance</CardTitle>
                  <CardDescription>Overview of your email campaign metrics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Total Campaigns</span>
                      <span className="font-semibold">24</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Average Open Rate</span>
                      <span className="font-semibold text-green-600">42.3%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Average Click Rate</span>
                      <span className="font-semibold text-blue-600">9.7%</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Total Revenue</span>
                      <span className="font-semibold text-orange-600">₹45,230</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Latest email marketing activities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                      <div>
                        <p className="text-sm font-medium">Campaign sent</p>
                        <p className="text-xs text-gray-500">Monthly Newsletter • 2 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                      <div>
                        <p className="text-sm font-medium">New subscribers</p>
                        <p className="text-xs text-gray-500">47 new subscribers • 5 hours ago</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full mt-2"></div>
                      <div>
                        <p className="text-sm font-medium">Campaign created</p>
                        <p className="text-xs text-gray-500">Product Launch • 1 day ago</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
