import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Smartphone,
  Monitor,
  Tablet,
  Save,
  Eye,
  Layers,
  Type,
  ImageIcon,
  Square,
  ArrowLeft,
  Undo,
  Redo,
  Zap,
} from "lucide-react"
import Link from "next/link"
import { DragDropBuilder } from "@/components/drag-drop-builder"
import { ThemeToggle } from "@/components/theme-toggle"
import { AnimatedButton } from "@/components/animated-button"

export default function WebsiteBuilderPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <AnimatedButton variant="ghost" size="sm" asChild animation="bounce">
              <Link href="/dashboard">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Link>
            </AnimatedButton>
            <div className="flex items-center space-x-2">
              <div className="w-6 h-6 bg-gradient-to-r from-purple-600 to-blue-600 rounded flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold">Website Builder</span>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-4">
              <ThemeToggle />
              <div className="flex items-center space-x-2">
                <AnimatedButton variant="ghost" size="sm" animation="bounce">
                  <Undo className="w-4 h-4" />
                </AnimatedButton>
                <AnimatedButton variant="ghost" size="sm" animation="bounce">
                  <Redo className="w-4 h-4" />
                </AnimatedButton>
              </div>
              <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
                <AnimatedButton variant="ghost" size="sm" className="bg-white shadow-sm" animation="bounce">
                  <Monitor className="w-4 h-4" />
                </AnimatedButton>
                <AnimatedButton variant="ghost" size="sm" animation="bounce">
                  <Tablet className="w-4 h-4" />
                </AnimatedButton>
                <AnimatedButton variant="ghost" size="sm" animation="bounce">
                  <Smartphone className="w-4 h-4" />
                </AnimatedButton>
              </div>
              <AnimatedButton variant="outline" size="sm" animation="bounce">
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </AnimatedButton>
              <AnimatedButton size="sm" className="bg-purple-600 hover:bg-purple-700" animation="bounce">
                <Save className="w-4 h-4 mr-2" />
                Save
              </AnimatedButton>
            </div>
          </div>
        </div>
      </header>

      <div className="flex h-[calc(100vh-73px)]">
        {/* Left Sidebar - Elements */}
        <div className="w-64 bg-white border-r overflow-y-auto">
          <div className="p-4">
            <h3 className="font-semibold mb-4">Elements</h3>
            <Tabs defaultValue="basic" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="basic">Basic</TabsTrigger>
                <TabsTrigger value="advanced">Advanced</TabsTrigger>
              </TabsList>
              <TabsContent value="basic" className="space-y-2 mt-4">
                <div className="grid grid-cols-2 gap-2">
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <Type className="w-4 h-4" />
                    <span className="text-xs">Text</span>
                  </AnimatedButton>
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <ImageIcon className="w-4 h-4" />
                    <span className="text-xs">Image</span>
                  </AnimatedButton>
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <Square className="w-4 h-4" />
                    <span className="text-xs">Button</span>
                  </AnimatedButton>
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <Layers className="w-4 h-4" />
                    <span className="text-xs">Section</span>
                  </AnimatedButton>
                </div>
              </TabsContent>
              <TabsContent value="advanced" className="space-y-2 mt-4">
                <div className="grid grid-cols-2 gap-2">
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <Square className="w-4 h-4" />
                    <span className="text-xs">Form</span>
                  </AnimatedButton>
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <Layers className="w-4 h-4" />
                    <span className="text-xs">Gallery</span>
                  </AnimatedButton>
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <Type className="w-4 h-4" />
                    <span className="text-xs">Video</span>
                  </AnimatedButton>
                  <AnimatedButton variant="outline" className="h-16 flex-col space-y-1" size="sm" animation="bounce">
                    <ImageIcon className="w-4 h-4" />
                    <span className="text-xs">Map</span>
                  </AnimatedButton>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>

        {/* Main Canvas */}
        <div className="flex-1 bg-gray-100 dark:bg-gray-800 overflow-auto">
          <DragDropBuilder />
        </div>

        {/* Right Sidebar - Properties */}
        <div className="w-64 bg-white border-l overflow-y-auto">
          <div className="p-4">
            <h3 className="font-semibold mb-4">Properties</h3>
            <div className="space-y-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Page Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-xs font-medium text-gray-600">Page Title</label>
                    <input
                      type="text"
                      className="w-full mt-1 px-2 py-1 text-sm border rounded"
                      defaultValue="My Business"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-medium text-gray-600">Meta Description</label>
                    <textarea
                      className="w-full mt-1 px-2 py-1 text-sm border rounded h-16 resize-none"
                      defaultValue="Professional services that deliver results"
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">Style</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <label className="text-xs font-medium text-gray-600">Background</label>
                    <div className="flex space-x-2 mt-1">
                      <div className="w-6 h-6 bg-purple-600 rounded border cursor-pointer"></div>
                      <div className="w-6 h-6 bg-blue-600 rounded border cursor-pointer"></div>
                      <div className="w-6 h-6 bg-green-600 rounded border cursor-pointer"></div>
                      <div className="w-6 h-6 bg-red-600 rounded border cursor-pointer"></div>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-medium text-gray-600">Font</label>
                    <select className="w-full mt-1 px-2 py-1 text-sm border rounded">
                      <option>Inter</option>
                      <option>Roboto</option>
                      <option>Open Sans</option>
                    </select>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm">AI Assistant</CardTitle>
                </CardHeader>
                <CardContent>
                  <AnimatedButton className="w-full" size="sm" variant="outline" animation="bounce">
                    <Zap className="w-4 h-4 mr-2" />
                    Generate Content
                  </AnimatedButton>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
